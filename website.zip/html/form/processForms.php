<?php

include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
include_once 'includes/all_fields.php';

sec_session_start();

try 
{
	/*Connect to the database*/
	$dc = new PDO("mysql:host=localhost;dbname=secure_login", 'sec_user', 'eKcGZr59zAa2BEWUXP');
	
	// Get the current user id from php sessions
	$user_id = $_SESSION['user_id'];
	
    if (isset($user_id)) 
	{
		$stack = array();
		foreach (getFullListOfFieldsExpandedByYear() as $field_name)
		{
			${$field_name} =& $_POST[$field_name];
			$stack[$field_name] = ${$field_name};
		}
		reset($stack);
		 
		$rowWasAdded = addMissingCompanyRows($dc, $user_id);

		if(!$rowWasAdded)
		{     
			foreach ($stack as $key => $value) 
			{
	            if( (((strcmp($key, 'company_name')) == 0) && isset($company_name)) || (((strcmp($key, 'city_state')) == 0) && isset($city_state)) || (((strcmp($key, 'cost_other_ex')) == 0) && isset($cost_other_ex)) || (((strcmp($key, 'fte_other_ex')) == 0) && isset($fte_other_ex)) ) {
					$update_qry = $dc->prepare("UPDATE Company SET {$key}='$value' WHERE id='$user_id'");
					$update_qry->execute();
				}
				elseif( (((strcmp($key, 'company_location')) == 0) && isset($company_location)) || (((strcmp($key, 'opt_comp_bargain_employee')) == 0) && isset($opt_comp_bargain_employee)) || (((strcmp($key, 'opt_proj_manag_peson')) == 0) && isset($opt_proj_manag_peson)) || (((strcmp($key, 'opt_supp_employee')) == 0) && isset($opt_supp_employee)) || (((strcmp($key, 'onw_dedc_prefab_shop')) == 0) && isset($onw_dedc_prefab_shop)) || (((strcmp($key, 'prect_hours_spent_prefabr')) == 0) && isset($prect_hours_spent_prefabr)) || (((strcmp($key, 'bim_yes_no')) == 0) && isset($bim_yes_no)) || (((strcmp($key, 'prect_tot_peop_hours_det_CAD')) == 0) && isset($prect_tot_peop_hours_det_CAD))) {
					$inputValue1 = "NA";
					if ((strcmp($value, "USA")) == 0) { $inputValue1 = "USA"; }
					elseif ((strcmp($value, "Canada")) == 0) { $inputValue1 = "Canada"; }
					elseif ((strcmp($value, "Other")) == 0) { $inputValue1 = "Other"; }

					if ((strcmp($value, "yes")) == 0) { $inputValue1 = "yes"; }
					elseif ((strcmp($value, "no")) == 0) { $inputValue1 = "no"; }

					if ((strcmp($value, "0")) == 0) { $inputValue1 = "0"; }
					elseif ((strcmp($value, "1-3")) == 0) { $inputValue1 = "1-3"; }
					elseif ((strcmp($value, "3-5")) == 0) { $inputValue1 = "3-5"; }
					elseif ((strcmp($value, "5-10")) == 0) { $inputValue1 = "5-10"; }
					elseif ((strcmp($value, "10-25")) == 0) { $inputValue1 = "10-25"; }
					elseif ((strcmp($value, ">25")) == 0) { $inputValue1 = ">25"; }
					$update_qry = $dc->prepare("UPDATE Company SET {$key}='$inputValue1' WHERE id='$user_id'");
					$update_qry->execute();
				}
				elseif (isset($value))
				{
					//Determine which table this field should land in and its name
					$tableNumber = getTableForExpandedFieldName($key);
					if ($tableNumber == -1)
					{
						continue;
					}
					else if ($tableNumber == 0)
					{
						$tableName = "Company";
						$fieldName = $key;
						$whereStatement = "WHERE id='$user_id'";
					}
					else
					{
						$tableName = "Year";
						$fieldName = removeYearTerminationFromField($key);
						$whereStatement = "WHERE company_id='$user_id' AND year='$tableNumber'";
					}

					if ((strcmp($value, "NULL")) == 0)
						$update_qry = $dc->prepare("UPDATE {$tableName} SET {$fieldName}=NULL {$whereStatement}");
					else
						$update_qry = $dc->prepare("UPDATE {$tableName} SET {$fieldName}='$value' {$whereStatement}");

					$update_qry->execute();
				}
			}
			
            // Retrieve all fields from database and save in array.
			/*Get saved data from database*/
			$quicksave_array = array();
			
			//Get saved company data
			$get_company_autosave = $dc->prepare("SELECT * FROM Company WHERE id='$user_id'");
			$get_company_autosave->execute();
			while ($company_gt_v = $get_company_autosave->fetch(PDO::FETCH_ASSOC))
			{
				foreach ($company_field_names as $companyField)
				{
					${$companyField} = $company_gt_v[$companyField];
					$quicksave_array[$companyField] = ${$companyField};
				}
			}
			//Get saved year data
			for ($year = 2011; $year <= 2018; $year++)
			{
				$get_years_autosave = $dc->prepare("SELECT * FROM Year WHERE company_id='$user_id' AND year='$year'");
				$get_years_autosave->execute();
				while ($years_gt_v = $get_years_autosave->fetch(PDO::FETCH_ASSOC))
				{
					foreach ($year_field_names as $yearField)
					{
						${$yearField} = $years_gt_v[$yearField];
						$yearFieldExpanded = "{$yearField}_{$year}";
						$quicksave_array[$yearFieldExpanded] = ${$yearField};
					}
				}
			}
			echo json_encode($quicksave_array);

		}		
	}
	else
	{
		header("location: includes/logout.php");
	}
} catch(PDOException $e) {
    echo $e->getMessage();
	}
	

function addMissingCompanyRows($dc, $user_id)
{
	$addedARow = false;
	//Add company row, if missing
	$companyStatement = $dc->query("SELECT * FROM Company WHERE id='$user_id'");
	if ($companyStatement->rowCount() == 0)
	{
		$dc->query("INSERT INTO Company (id) VALUES ('$user_id')");
		$addedARow = true;
	}
	//Add row for each year, if missing
	for ($year = 2011; $year <= 2018; $year++)
	{
		$yearStatement = $dc->query("SELECT * FROM Year WHERE company_id='$user_id' AND year='$year'");
		if ($yearStatement->rowCount() == 0)
		{
			$dc->query("INSERT INTO Year (company_id, year) VALUES ('$user_id', '$year')");
			$addedARow = true;
		}
	}
	return $addedARow;
}

?>
