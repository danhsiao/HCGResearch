<?php

include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
include_once 'includes/table_generator.php';

sec_session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Electrical Contractors Productivity and Profitability</title>
        <link rel="stylesheet" href="styles/main.css" />
		
		<link href="styles/style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	    <!-- jQuery (external-->
		<script src="http://thecodeplayer.com/uploads/js/jquery-1.9.1.min.js" type="text/javascript"></script>
		<!-- jQuery easing plugin (external) -->
		<script src="http://thecodeplayer.com/uploads/js/jquery.easing.min.js" type="text/javascript"></script>
		
    </head>
    <body class="landingPageBody">
	
	<!-- Checks if you are authorized to view the current page -->
    <?php if (login_check($mysqli) == true) : ?>
		<!-- Multistep form -->
		<!-- Top gradient header-->
			<div id="bottomGradientLanding">
			<label class="viewPageHeader">Electrical Contractors Productivity and Profitability</label>

					<!--Form -->
					<form id="msform" >

						<!-- Progressbar (Sections headers) -->
						<ul id="progressbar">
							<li name="fieldset0" class="active section"><span class="hiddenSpan">Sample Report </span></li>
							<li name="fieldset1" class="section"><span class="hiddenSpan">Company info</span></li>
							<li name="fieldset2" class="section"><span class="hiddenSpan">Company's Revenue</span></li>
							<li name="fieldset3" class="section"><span class="hiddenSpan">Company's People</span></li>
							<li name="fieldset4" class="section"><span class="hiddenSpan">New Questions</span></li>
						</ul>
						<!-- End Progressbar (Sections headers) -->
						
						<!-- Fieldsets (Sections) -->
						<fieldset id="fieldset0">
						
							<br>
							<label class="viewHeader">This is a sample report that contains a selection of the slides from the final comprehesive report. <br><br>To receive a personalized report for your Company, please complete and submit the questionnaire in the following sections.</label>
						
							 <!-- pdf link -->
							<iframe src="img/Company_A_Report.pdf" style="width:900px; height:750px;" frameborder="0"></iframe>
							<br><br><br>
							<br><br>

							<!--Bottom buttons-->
							<a href="includes/logout.php" class="buttonClass">Sign Out</a>
							<input type="button" name="next" class="firstNext next action-button" value=" Continue to Questionnaire "/>

						</fieldset>

						<!--Section 1-->
						<fieldset id="fieldset1">

							<!-- Input text -->
							<label class="viewHeader">Please tell us your Company's name</label>
							<input class="form-control" required type="text" name="company_name" autofocus/>

							<br><br>

							<!-- Radio Button -->
							<div>
								<label class="viewHeader">Please tell us your Company's location</label>
								<ul id="list1">
									<div class="radioContainer">
										<input type="radio" name="company_location" value="USA" id="box1"
											   class="radioButton"><label class="big" for="box1">United States of
											America</label>
									</div>
									<br>
									<div class="radioContainer">
										<input type="radio" name="company_location" value="Canada" id="box2"
											   class="radioButton"><label class="big" for="box2">Canada</label>
									</div>
									<br>
									<div class="radioContainer">
										<input type="radio" name="company_location" value="Other" id="box3" class="radioButton"><label
												class="big" for="box3">Other</label>
									</div>
								</ul>
							</div>

							<br><br>

							<!-- A more exactly location of the business appears when one of the previous option is selected -->
							<div id="location_box" style="display:none">
								<label class="viewHeader" id="label_location"></label>
								<input required type="text" class="form-control" name="city_state" autofocus/>
							</div>

							<br><br>

							<!--Bottom buttons-->
							<a href="includes/logout.php" class="buttonClass">Sign Out</a>
							<input type="button" name="save" class="save action-button" value=" Save progress " />
							<input type="button" name="next" class="next action-button" value=" >> "/>
							
						</fieldset>
						<!--End Section 1 -->						
					
						<!--Section 2-->
						<fieldset id="fieldset2">

						<!-- Title -->
						<h2 class="viewHeader">

						Please fill out the following table with company data for each applicable fiscal year. If you do not have or do not wish to submit data for a particular year, click the ‘N/A’ button to void that column/cell. <br><br>For help, hover over the blue question marks for additional information.

						</h2>

						<!-- Table -->
						<table class="hoverTable">
							<?php
							createYearTableHeader("FY ", " (\$M)", 1, "");
							?>
							<tbody>
							<?php
							createYearTableRow("Revenue from construction projects", "Revenue achieved by the company from Construction Projects.", "revenue");
							createYearTableRow("Total expenses of the company", "All expenses of the company.", "total_expenses");
							createYearTableRow("Cost of Materials purchased by your organization", "Cost of Materials purchased by your organization for Construction Projects.", "cost_materials");
							createYearTableRow("Payments disbursed to subcontractors", "subcontractors: a business, person or group of people that carries out work for a company as part of a larger project", "pay_disbursed_subcontr");
							createYearTableRow("Payments for Company's people", "Company's People includes: Bargaining Unit Employees, Project Management Personnel, and non-project management non bargaining unit employees.", "pay_compny_people");
							createYearTableRow("Fixed Overhead", "Set of costs that do not vary as a result of change in workload. These costs are needed in order to operate the business. Some examples of fixed overheads are administrative-personnel salaries, accounting personnel salaries, office personnel salaries, office expenses, company insurance, real estate expenses, etc. (including project manager costs).", "fixed_overhead");
							createYearTableRow("Variable Overhead", "Set of costs that are not discretely charged to a specific project and tend to vary depending on the company revenue.", "variable_overhead");
							createYearTableRow("Gross profit", "Gross profit achieved by the company from construction projects before tax deductions and excluding project manager costs.", "gross_profit");
							createYearTableRow("Net profit (or net loss)", "Net profit achieved by the company from construction projects before tax deductions.", "net_profit");
							?>
							</tbody>
						</table>

						<br>
						<hr>

						<!--Bottom buttons-->
						<a href="includes/logout.php" class="buttonClass">Sign Out</a>
						<input type="button" name="previous" class="previous action-button" value=" << "/>
						<input type="button" name="saveCheck" class="save action-button" value=" Save progress " />
						<input type="button" name="next" class="next action-button" value=" >> "/>
						</fieldset>
						<!--End Section 2-->

						<!--Section 3-->
						<fieldset id="fieldset3">

							<!-- Explanation -->
							<h2 class="viewHeader">
							
								Please complete the following table regarding the hours and cost of your company’s employees. <br>If you do not have or do not wish to submit data for a particular year, click the ‘N/A’ button to void that column/cell. Please refer to each row header to find appropriate units for that entire row of data.
								<br><br>For help, hover over the blue question marks for additional information.
								
								</h2>
							<!-- Table -->
							<table class="hoverTable">
							<?php
							createYearTableHeader("FY ", " (\$M)", 2, "Please refer to each row header to find appropriate units for that entire row of data.");
							?>
							<tbody>
							<?php
							createYearTableRow("Cost of bargaining unit employees", "Bargaining unit employees: Craft Workers including apprentices, journeymen, foremen, pre-fab shop workers (if-any), material handlers (if-any), construction wiremen (if-any), etc.", "cost_bargain_employee");
							createYearTableRow("Average FTE of bargaining unit employees (FTE)", "Bargaining unit employees: Craft Workers including apprentices, journeymen, foremen, pre-fab shop workers (if-any), material handlers (if-any), construction wiremen (if-any), etc. FTE: Full Time Equivalent", "fte_bargain_employee");
							createYearTableRow("Expended hours of bargaining unit employees (Hours)", "Bargaining unit employees: Craft Workers including apprentices, journeymen, foremen, pre-fab shop workers (if-any), material handlers (if-any), construction wiremen (if-any), etc.", "hours_bargain_employee");
							createYearTableRow("Sub-journeymen to journeymen ratio", "", "sub_to_journey_ratio");
							createYearTableRow("Journeymen to (foremen or general foremen or superintendent) ratio", "", "journey_to_foremen_ratio");
							createYearTableRow("Paid overtime premium", "", "overtime_premium");
							createYearTableRow("Paid second shift premium", "", "second_shift_premium");
							createYearTableRow("Paid double time premium", "", "double_time_premium");
							$absenteeismOptions = array("<5", "5-10", ">10");
							createYearTableDropdownRow("Absenteeism (%)", "Percentage of days bargaining unit employees were absent annually.", "absenteeism_perc", $absenteeismOptions);
							createYearTableRow("Actual/Approximate Turnover Rate of bargaining unit employees (%)", "Total number of separations of bargaining unit employees that occurred during the year as a percentage of the average number of bargaining unit employees during that year.", "turnover_rate_bargaining_perc");
							
							createSectionBreakTableRow();
							
							createYearTableRow("Cost of project management personnel", "Project management personnel: Personnel primarily responsible for managing construction projects. These personnel are project managers/executives, project engineers/project manager assistants, and superintendents serving as project managers", "cost_proj_manag_peson");
							createYearTableRow("FTE of project management personnel (FTE)", "Project management personnel: Personnel primarily responsible for managing construction projects. These personnel are project managers/executives, project engineers/project manager assistants, and superintendents serving as project managers", "fte_proj_manag_peson");
							createYearTableRow("Hours of project management personnel (Hours)", "Project management personnel: Personnel primarily responsible for managing construction projects. These personnel are project managers/executives, project engineers/project manager assistants, and superintendents serving as project managers", "hours_proj_manag_peson");
							
							createSectionBreakTableRow();
							
							createYearTableRow("Cost of supporting employees", "Supporting employees: Personnel who are not bargaining unit employees, project managers, project executives, project engineers, or project managers’ assistants. Accordingly, such employees include accounting staff, estimators, executives, safety personnel, yard/warehouse personnel, engineering staff, administrative personnel, time keepers, BIM employees, AutoCAD employees, truck drivers, etc.", "cost_supp_employee");
							createYearTableRow("FTE of supporting employees (FTE)", "Supporting employees: Personnel who are not bargaining unit employees, project managers, project executives, project engineers, or project managers’ assistants. Accordingly, such employees include accounting staff, estimators, executives, safety personnel, yard/warehouse personnel, engineering staff, administrative personnel, time keepers, BIM employees, AutoCAD employees, truck drivers, etc.", "fte_supp_employee");
							createYearTableRow("Hours of supporting employees (Hours)", "Supporting employees: Personnel who are not bargaining unit employees, project managers, project executives, project engineers, or project managers’ assistants. Accordingly, such employees include accounting staff, estimators, executives, safety personnel, yard/warehouse personnel, engineering staff, administrative personnel, time keepers, BIM employees, AutoCAD employees, truck drivers, etc.", "hours_supp_employee");
							?>
							</tbody>
							</table>

							<br>

							<label class="viewHeader">Please indicate how many hours per year does FTE stands for in your company.</label>
								<div class="spin" style="color:black;">
								<input required type="text" name="fte_hours"/>
								<span style="color:black;">N/A</span></div>

							<br>

							<!--Bottom buttons-->
							<a href="includes/logout.php" class="buttonClass">Sign Out</a>
							<input type="button" name="previous" class="previous action-button" value=" << "/>
							<input type="button" name="save" class="save action-button" value=" Save progress " />
							<input type="button" name="next" class="next action-button" value=" >> "/>
						</fieldset>
						<!--End Section 3 -->


						<!--Section 4-->
						<fieldset id="fieldset4">

							<!-- Explanation -->
							<h2 class="viewHeader">
							
								Please complete the following table regarding your company. <br>If you do not have or do not wish to submit data for a particular year, click the ‘N/A’ button to void that column/cell. Please refer to each row header to find appropriate units for that entire row of data.
								<br><br>For help, hover over the blue question marks for additional information.
								
								</h2>
							<!-- Table -->
							<table class="hoverTable">
							<?php
							createYearTableHeader("FY ", "", 3, "Please refer to each row header to find appropriate units for that entire row of data.");
							?>
							<tbody>
							<?php
							$prefabOptions = array("<2", "2-5", "5-10", ">10");
							createYearTableDropdownRow("Prefabrication (%)", "Total hours spent in prefabrication work as a percentage of total hours utilized by the company (if not tracked, please provide an estimate).", "prefabrication_perc", $prefabOptions);
							createYearTableRow("Repeat business customers (%)", "Percentage of customers who come back for a repeat business with the firm (regarding non-competitive bid work only).", "repeat_customer_perc");
							createYearTableRow("Actual/approximate hit rate", "Dollars awarded divided by dollars bided for (regarding construction projects only).", "hit_rate");
							$emrOptions = array("<0.75", "0.75-1", ">1");
							createYearTableDropdownRow("Experience modification rate (EMR)", "", "emr", $emrOptions);
							createYearTableRow("OSHA recordable incident rate", "Number of OSHA recordable cases multiplied by 200,000, and then divided by expended hours of bargaining unit employees.", "osha_incident_rate");
							?>
							</tbody>
							</table>

							<br>

							<!--Bottom buttons-->
							<a href="includes/logout.php" class="buttonClass">Sign Out</a>
							<input type="button" name="previous" class="previous action-button" value=" << "/>
							<input type="button" name="save" class="save action-button" value=" Save progress " />
							<form action="" method="post">
								<input type="submit" name="submit" class="submit action-button" data-popup-open="popup-2" value=" Submit " href="#" />
							</form>
						</fieldset>
						<!--End Section 4 -->

						<!--End fieldsets (Sections) -->

					</form>
					<!-- End form-->

			</div>
		<!-- Closing div of gradient-->

		<!-- The Modal to show for fill all inputs -->
		<div id="myModal" class="modal">
			<!-- Modal content -->
			<div class="modal-content">
				<span id="myClose" class="close"></span>
				<p><h3>Please enter the items marked in RED and try again!</h3></p>
			</div>
		</div>
		
		
		<!-- The Modal to show that form has been submitted successfully -->
		<div id="myModal2" class="modal">
			<!-- Modal content -->
			<div class="modal-content">
				<span id="myClose2" class="close"></span>
				<p><h3>Form submitted successfully!<br>You will receive an email with your PDF report in 24hrs. <br>You can logout!</h3></p> <br>
				<a href="includes/logout.php" class="buttonClass">Sign Out</a>
			</div>
		</div>
	
	
		<!-- The Modal to show that form has been saved successfully! -->
		<div id="myModal3" class="modal">

			<!-- Modal content -->
			<div class="modal-content">
				<span id="myClose3" class="close"></span>
				<p><h3>Page saved successfully!</h3></p>
			</div>
		</div>

		
		<!-- The Modal to show that form has been saved successfully! -->
		<div id="myModal4" class="modal">

			<!-- Modal content -->
			<div class="modal-content">
				<span id="myClose4" class="close"></span>
				<p><h3>Are you sure you want <br>(Revenue from Construction Projects) < (Cost of Materials + <br>Payments disbursed to subcontractos + <br>Payments to Company's People + <br>Other Expenses) for the year <b>2011</b>? </h3></p>
				<input type="button" name="yesVal1" class="buttonClass" value=" Yes "/>
				<input type="button" name="noVal1" class="buttonClass" value=" No "/>
				
			</div>
		</div>
		
		<!-- The Modal to show that form has been saved successfully! -->
		<div id="myModal5" class="modal">

			<!-- Modal content -->
			<div class="modal-content">
				<span id="myClose5" class="close"></span>
				<p><h3>Are you sure you want <br>(Revenue from Construction Projects) < (Cost of Materials + <br>Payments disbursed to subcontractos + <br>Payments to Company's People + <br>Other Expenses) for the year <b>2012</b>? </h3></p>
				<input type="button" name="yesVal2" class="buttonClass" value=" Yes "/>
				<input type="button" name="noVal2" class="buttonClass" value=" No "/>
				
			</div>
		</div>
		
		<!-- The Modal to show that form has been saved successfully! -->
		<div id="myModal6" class="modal">

			<!-- Modal content -->
			<div class="modal-content">
				<span id="myClose6" class="close"></span>
				<p><h3>Are you sure you want <br>(Revenue from Construction Projects) < (Cost of Materials + <br>Payments disbursed to subcontractos + <br>Payments to Company's People + <br>Other Expenses) for the year <b>2013</b>? </h3></p>
				<input type="button" name="yesVal3" class="buttonClass" value=" Yes "/>
				<input type="button" name="noVal3" class="buttonClass" value=" No "/>
				
			</div>
		</div>
		
		<!-- The Modal to show that form has been saved successfully! -->
		<div id="myModal7" class="modal">

			<!-- Modal content -->
			<div class="modal-content">
				<span id="myClose7" class="close"></span>
				<p><h3>Are you sure you want <br>(Revenue from Construction Projects) < (Cost of Materials + <br>Payments disbursed to subcontractos + <br>Payments to Company's People + <br>Other Expenses) for the year <b>2014</b>? </h3></p>
				<input type="button" name="yesVal4" class="buttonClass" value=" Yes "/>
				<input type="button" name="noVal4" class="buttonClass" value=" No "/>
				
			</div>
		</div>
		
		<!-- The Modal to show that form has been saved successfully! -->
		<div id="myModal8" class="modal">

			<!-- Modal content -->
			<div class="modal-content">
				<span id="myClose8" class="close"></span>
				<p><h3>Are you sure you want <br>(Revenue from Construction Projects) < (Cost of Materials + <br>Payments disbursed to subcontractos + <br>Payments to Company's People + <br>Other Expenses) for the year <b>2015</b>? </h3></p>
				<input type="button" name="yesVal5" class="buttonClass" value=" Yes "/>
				<input type="button" name="noVal5" class="buttonClass" value=" No "/>
				
			</div>
		</div>
		
		<!-- The Modal to show that form has been saved successfully! -->
		<div id="myModal9" class="modal">

			<!-- Modal content -->
			<div class="modal-content">
				<span id="myClose9" class="close"></span>
				<p><h3>Are you sure you want <br>(Revenue from Construction Projects) < (Cost of Materials + <br>Payments disbursed to subcontractos + <br>Payments to Company's People + <br>Other Expenses) for the year <b>2016</b>? </h3></p>
				<input type="button" name="yesVal6" class="buttonClass" value=" Yes "/>
				<input type="button" name="noVal6" class="buttonClass" value=" No "/>
				
			</div>
		</div>
		
		

	<?php else : ?>
		<p>
			<span class="error">You are not authorized to access this page.</span> Please <a href="index.php">login</a>
		</p>
    <?php endif; ?>	
		
		
		
		
		
    </body>
</html>





<!-- Jquery scripts-->
<script type="text/javascript">

    //Variables
    var current_fs, next_fs, previous_fs; //fieldsets

    //Action to perform when next button clicked(to next section)
    $(".next").click(function () {

        //Set actual and next fieldsets
        current_fs = $(this).parent();
        next_fs = $(this).parent().next();


        //Activate next step on progressbar using the index of next_fs
        $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
        $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");


        //Show the next fieldset and hide current
        next_fs.show("slow");
        current_fs.hide("slow");
//    easing: 'easeInOutBack'

    });


    //Action to perform when previous button clicked (to previous section)
    $(".previous").click(function () {

        //Set actual and next fieldsets
        current_fs = $(this).parent();
        previous_fs = $(this).parent().prev();

        //De-activate current step on progressbar
        $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
        $("#progressbar li").eq($("fieldset").index(previous_fs)).addClass("active");

        //Show the previous fieldset and hide current
        previous_fs.show("slow");
        current_fs.hide("slow");
    });


    //Action to perform when section header number is clicked (to selected section)
    $(".section").click(function () {

        //Function calculates current fieldset based on opacity (current is the only visible)
        $.extend($.expr[':'], {
            opacity: function (elem, i, attr) {
                return ( $(elem).css("opacity") === attr[3] + '' );
            }
        });

        //Set actual and next fieldsets
        current_fs = $("fieldset:opacity(1)");
        new_fs = $("#" + jQuery(this).attr("name"));

        //Activate selected step and de-activate current step on progressbar
        $("#progressbar li").removeClass("active");
        $(this).addClass("active");

        //Show the selected fieldset and hide current
        current_fs.hide("slow");
        new_fs.show("slow");

    });


	
	
	

    //Action to perform when submit button is clicked(submit if all inputs are filled)
    $(".submit").click(function () 
	{
        //Check whether all inputs are filled or not
        if (validation()) {
			<?php
				$user_id = $_SESSION['user_id'];
				$sql99 = "UPDATE Company SET submit='yes' WHERE id='$user_id'";
				$result = mysqli_query($mysqli, $sql99);
			?>
			showModal2();
			
            return true;
        }else {
            //Show pop up asking for filling all inputs
            showModal();
			
            return false;
        }
    })
	


    //Validation function for all fields in the form
    function validation() {
        //Variable to get if any of the input is empty in which case validation function will return false
        var allCorrect = true;

        //Reset all inputs of checked radiobuttons
        $(".redTextInput").remove();

        //Foreach that apply validation for each fieldset
        $('#msform').find('fieldset').each(function () {

            //Variable with the current fieldset to check
            var fieldset_id = $(this).attr('id');

            //Check those fieldset with dynamic tables, for that, it look if there are any table with display none, that are those that will be show() or hide()
            var id_table = $("#" + fieldset_id + " div[style*=\"display: none\"]").attr('id');
            //If there is any non visible table, doesn't check for the inputs of the table
            if (id_table != null && $("#" + id_table + " div[style*=\"display: none\"]")) {

                //Get all the radiobuttons on the fieldset to check whether there is any non selected radio group
                var radio_buttons = true;
                $("#" + fieldset_id).find('ul:not(:has(:radio:checked))').each(function () {
                    radio_buttons = false;
                });

                //If there are any non selected radio group (so radiobutton is walse) mark that fieldset header as non completed
                if (!radio_buttons) {
                    allCorrect = false;
                    $("li[name=" + fieldset_id + "]").addClass("wrong");
                }
                //Else, mark the fieldset as completed
                else {
                    $("li[name=" + fieldset_id + "]").removeClass("wrong");
                }

            }

            //If it is a normal fieldset without dinamic tables, or if the table appears because yes was checked
            else {

                //Function to check if all input text are completed
                var $completedInputsText = $("#" + fieldset_id + "    input:text").filter(function () {
                    //return the ones witn empty values
                    return $.trim(this.value) == "";
                });

                //Function to check if all input number are completed
                var $completedInputsNumbers = $("#" + fieldset_id + "    :input[type=\"number\"]:not(:disabled) ").filter(function () {
                    //return the ones witn empty values
                    return $.trim(this.value) == "";
                });

                //Get all the radiobuttons on the fieldset to check whether there is any non selected radio group
                var radio_buttons = true;
                $("#" + fieldset_id).find('ul:not(:has(:radio:checked))').each(function () {
                    radio_buttons = false;
                });

                //If there are any non selected radio group (so radiobutton is false), or any input empty, mark that fieldset header as non completed
                if ($completedInputsText.length != 0 || $completedInputsNumbers.length != 0 || !radio_buttons) {
                    allCorrect = false;
                    $("li[name=" + fieldset_id + "]").addClass("wrong");
                }
                //Else, mark the fieldset as completed
                else {
                    $("li[name=" + fieldset_id + "]").removeClass("wrong");
                }

            }

            //Changing styles for all bad/correct inputs
            var current_fs = $('#' + fieldset_id);

            //Change red color empty fields or grey completed ones in text/number inputs
            current_fs.find(':input[type=\"number\"]:not(:disabled),:input[type=\"text\"],textarea').each(function () {
                //If empty, put red wrong style
                if ($(this).val().length == 0)
                    $(this).css({'border': "1px solid #f00"})
                //Else, put normal style
                else
                    $(this).css({'border': "1px solid #ccc"})
            });

            //Add red please, select option on non selected radiobuttons
            current_fs.find('ul:not(:has(:radio:checked))').each(function () {
                $(this).before("<p name=\"redTextInput\" class=\"redTextInput\">Please, select one option</p>");
            });

        });
        //Finish foreach

        //Return value of variable checking all inputs
        return allCorrect;
    }


    //Everytime an input lost focus, restore normal style (not wrong) if filled
    $(":input[type=\"text\"],:input[type=\"number\"],textarea").focusout(function () {
        if ($(this).val().length > 0)
            $(this).css({'border': "1px solid #ccc"});
    })

    //Everytime an radiogroup is selected, restore normal (delete text please, add input)
    $(".radioContainer").click(function () {
        $(this).parent().parent().find(".redTextInput").remove();
    })


    //For the location radio group in section 1, switch betweens posible options to field
    $('#list1').click(function () {

        switch ($('#msform').find('input[name=company_location]:checked').val()) {
            //Question for USA
            case 'USA' :
                $('#label_location').text("Please tell us the City and State");
                $("#location_box").show("slow");
                break;
            //Question for Canada
            case 'Canada':
                $('#label_location').text("Please tell us the City and Province");
                $("#location_box").show("slow");
                break;
            //Question for any other place
            case 'Other':
                $('#label_location').text("Please tell us the name of the country");
                $("#location_box").show("slow");
                break;
        }
    });


    //For each optimization question (radio group) shows or hidde table if question is yes or no
    $('#list4').click(function () {
        if ($('#msform').find('input[name=opt_comp_bargain_employee]:checked').val() == 'yes')
            $("#table4").show("slow");
        else
            $("#table4").hide("slow");
    });

    $('#list5').click(function () {
        if ($('#msform').find('input[name=opt_proj_manag_peson]:checked').val() == 'yes')
            $("#table5").show("slow");
        else
            $("#table5").hide("slow");
    });

    $('#list6').click(function () {
        if ($('#msform').find('input[name=opt_supp_employee]:checked').val() == 'yes')
            $("#table6").show("slow");
        else
            $("#table6").hide("slow");
    });
	
	$('#list8').click(function () {
        if ($('#msform').find('input[name=bim_yes_no]:checked').val() == 'yes')
            $("#table8").show("slow");
        else {
            $("#table8").hide("slow");
		}
    });
	
    //Finish optimiaztion question for table showing

    //Change number inputs into disabled when Non Applicable is clcked (and viceversa)
    $('span').click(function () {
        var inputBox = $(this).parent().find("input");
			inputBox.val('NULL');
            inputBox.css({'border': "1px solid #ccc"});
    })
	
	
	if($("#naColButtonP11").click(function() {makeNullP1(2011);}) )
	if($("#naColButtonP12").click(function() {makeNullP1(2012);}) )
	if($("#naColButtonP13").click(function() {makeNullP1(2013);}) )
	if($("#naColButtonP14").click(function() {makeNullP1(2014);}) )
	if($("#naColButtonP15").click(function() {makeNullP1(2015);}) )
	if($("#naColButtonP16").click(function() {makeNullP1(2016);}) )
	if($("#naColButtonP17").click(function() {makeNullP1(2017);}) )
	if($("#naColButtonP18").click(function() {makeNullP1(2018);}) )
		
	if($("#naColButtonP21").click(function() {makeNullP2(2011);}) )
	if($("#naColButtonP22").click(function() {makeNullP2(2012);}) )
	if($("#naColButtonP23").click(function() {makeNullP2(2013);}) )
	if($("#naColButtonP24").click(function() {makeNullP2(2014);}) )
	if($("#naColButtonP25").click(function() {makeNullP2(2015);}) )
	if($("#naColButtonP26").click(function() {makeNullP2(2016);}) )
	if($("#naColButtonP27").click(function() {makeNullP2(2017);}) )
	if($("#naColButtonP28").click(function() {makeNullP2(2018);}) )
		
	if($("#naColButtonP31").click(function() {makeNullP3(2011);}) )
	if($("#naColButtonP32").click(function() {makeNullP3(2012);}) )	
	if($("#naColButtonP33").click(function() {makeNullP3(2013);}) )
	if($("#naColButtonP34").click(function() {makeNullP3(2014);}) )
	if($("#naColButtonP35").click(function() {makeNullP3(2015);}) )
	if($("#naColButtonP36").click(function() {makeNullP3(2016);}) )
	if($("#naColButtonP37").click(function() {makeNullP3(2017);}) )
	if($("#naColButtonP38").click(function() {makeNullP3(2018);}) )

	
	function makeNull(arrayOfFieldNames, year)
	{
		for (var i = 0; i < arrayOfFieldNames.length; i++)
		{
			$("[name='"+arrayOfFieldNames[i]+"_"+year+"']").val('NULL');
		}
	}

	function makeNullP1(year)
	{
		var fields = ["revenue", "total_expenses", "cost_materials", "pay_disbursed_subcontr", "pay_compny_people", "fixed_overhead", "variable_overhead", "gross_profit", "net_profit"];
		makeNull(fields, year);
	}
	

	function makeNullP2(year)
	{
		var fields = ["cost_bargain_employee", "fte_bargain_employee", "hours_bargain_employee", "sub_to_journey_ratio", "journey_to_foremen_ratio", "overtime_premium", "second_shift_premium", "double_time_premium", "absenteeism_perc",
					  "turnover_rate_bargaining_perc", "cost_proj_manag_peson", "fte_proj_manag_peson", "hours_proj_manag_peson", "cost_supp_employee", "fte_supp_employee", "hours_supp_employee"];
		makeNull(fields, year);
	}
	
	
	function makeNullP3(year)
	{
		var fields = ["prefabrication_perc", "repeat_customer_perc", "hit_rate", "emr", "osha_incident_rate"];
		makeNull(fields, year);
	}

	
</script>

<!--Script to show modal for fill all inputs-->
<script>
    // Get the modal
    var modal = document.getElementById('myModal');
    // Get the <span> element that closes the modal
    var span = document.getElementById("myClose");

    // When the user clicks the button submits, it call this function that open the modal
    function showModal() {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
        if (event.target == modal2) {
            modal2.style.display = "none";
        }
        if (event.target == modal3) {
            modal3.style.display = "none";
        }
		if (event.target == modal4) {
            modal4.style.display = "none";
        }
		if (event.target == modal5) {
            modal5.style.display = "none";
        }
		if (event.target == modal6) {
            modal6.style.display = "none";
        }
		if (event.target == modal7) {
            modal7.style.display = "none";
        }
		if (event.target == modal8) {
            modal8.style.display = "none";
        }
		if (event.target == modal9) {
            modal9.style.display = "none";
        }
    }
</script>



<!--Script to show modal for form being submitted successfully!-->
<script>
    // Get the modal
    var modal2 = document.getElementById('myModal2');
    // Get the <span> element that closes the modal
    var span2 = document.getElementsByClassName("close")[0];

    // When the user clicks the button submits, it call this function that open the modal
    function showModal2() {
        modal2.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span2.onclick = function () {
        modal2.style.display = "none";
    }

</script>


<!--Script to show modal for form being submitted successfully!-->
<script>
    // Get the modal
    var modal3 = document.getElementById('myModal3');
    // Get the <span> element that closes the modal
    var span3 = document.getElementsByClassName("close")[0];

    // When the user clicks the button submits, it call this function that open the modal
    function showModal3() {
        modal3.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span3.onclick = function () {
        modal3.style.display = "none";
    }

</script>

<!--Script to show modal for Revenu check 2011-->
<script>
	var bool1 = false;
	var bool2 = false;
	var bool3 = false;
	var bool4 = false;
	var bool5 = false;
	var bool6 = false;
    // Get the modal
    var modal4 = document.getElementById('myModal4');
    // Get the <span> element that closes the modal
    var span4 = document.getElementsByClassName("close")[0];

    // When the user clicks the button submits, it call this function that open the modal
    function showModal4() {
        modal4.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span4.onclick = function () {
        modal4.style.display = "none";
    }
	
	$("[name='noVal1']").click(function () 
	{
		modal4.style.display = "none";
    });
	
	$("[name='yesVal1']").click(function () 
	{
		bool1 = true;
		modal4.style.display = "none";
    });
	
	

</script>

<!--Script to show modal for Revenu check 2012-->
<script>
    // Get the modal
    var modal5 = document.getElementById('myModal5');
    // Get the <span> element that closes the modal
    var span5 = document.getElementsByClassName("close")[0];

    // When the user clicks the button submits, it call this function that open the modal
    function showModal5() {
        modal5.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span5.onclick = function () {
        modal5.style.display = "none";
    }
	
	$("[name='noVal2']").click(function () 
	{
		modal5.style.display = "none";
    });
	
	$("[name='yesVal2']").click(function () 
	{
		bool2 = true;
		modal5.style.display = "none";
    });
	

</script>


<!--Script to show modal for Revenu check 2013-->
<script>
    // Get the modal
    var modal6 = document.getElementById('myModal6');
    // Get the <span> element that closes the modal
    var span6 = document.getElementsByClassName("close")[0];

    // When the user clicks the button submits, it call this function that open the modal
    function showModal6() {
        modal6.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span6.onclick = function () {
        modal6.style.display = "none";
    }
	
	$("[name='noVal3']").click(function () 
	{
		modal6.style.display = "none";
    });
	
	$("[name='yesVal3']").click(function () 
	{
		bool3 = true;
		modal6.style.display = "none";
    });
	

</script>

<!--Script to show modal for Revenu check 2013-->
<script>
    // Get the modal
    var modal7 = document.getElementById('myModal7');
    // Get the <span> element that closes the modal
    var span7 = document.getElementsByClassName("close")[0];

    // When the user clicks the button submits, it call this function that open the modal
    function showModal7() {
        modal7.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span7.onclick = function () {
        modal7.style.display = "none";
    }
	
	$("[name='noVal4']").click(function () 
	{
		modal7.style.display = "none";
    });
	
	$("[name='yesVal4']").click(function () 
	{
		bool4 = true;
		modal7.style.display = "none";
    });
	

</script>


<!--Script to show modal for Revenu check 2013-->
<script>
    // Get the modal
    var modal8 = document.getElementById('myModal8');
    // Get the <span> element that closes the modal
    var span8 = document.getElementsByClassName("close")[0];

    // When the user clicks the button submits, it call this function that open the modal
    function showModal8() {
        modal8.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span8.onclick = function () {
        modal8.style.display = "none";
    }
	
	$("[name='noVal5']").click(function () 
	{
		modal8.style.display = "none";
    });
	
	$("[name='yesVal5']").click(function () 
	{
		bool5 = true;
		modal8.style.display = "none";
    });
	

</script>


<!--Script to show modal for Revenu check 2013-->
<script>
    // Get the modal
    var modal9 = document.getElementById('myModal9');
    // Get the <span> element that closes the modal
    var span9 = document.getElementsByClassName("close")[0];

    // When the user clicks the button submits, it call this function that open the modal
    function showModal9() {
        modal9.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span9.onclick = function () {
        modal9.style.display = "none";
    }
	
	$("[name='noVal6']").click(function () 
	{
		modal9.style.display = "none";
    });
	
	$("[name='yesVal6']").click(function () 
	{
		bool6 = true;
		modal9.style.display = "none";
    });
	

</script>

<script>
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode != 46 &&(charCode < 45 || charCode > 57)))
        return false;
    return true;
}    
</script>


<script rel="text/javascript">
    $(function () {
        $.post("processForms.php", function (data) {

		
			$.each( data, function( index, value ){
				if(index == "company_name" || index == "city_state" || index == "cost_other_ex" || index == "fte_other_ex") {
					$("[name='"+index+"']").val(value);
				}
				if(index == "company_location" || index == "opt_comp_bargain_employee" || index == "opt_proj_manag_peson" || index == "opt_supp_employee" || index == "onw_dedc_prefab_shop" || index == "prect_hours_spent_prefabr" || index == "prect_tot_peop_hours_det_CAD" || index == "bim_yes_no") {
					if(value == "USA") {
						$("#box1").prop('checked', true);
						$('#label_location').text("Please tell us the City, State");
						$("#location_box").show("slow");
					}
					else if(value == "Canada") {
						$("#box2").prop('checked', true);
						$('#label_location').text("Please tell us the City, Province");
						$("#location_box").show("slow");	
					}
					else if(value == "Other") {
						$("#box3").prop('checked', true);
						$('#label_location').text("Please tell us the name of the country");
						$("#location_box").show("slow");
					}
					else if(index == "opt_comp_bargain_employee" && value == "yes") {
						$("#box4").prop('checked', true);
						$("#table4").show("slow");
					}
					else if(index == "opt_comp_bargain_employee" && value == "no") {
						$("#box5").prop('checked', true);
						$("#table4").hide("slow");
					}
					else if(index == "opt_proj_manag_peson" && value == "yes") {
						$("#box6").prop('checked', true);
						$("#table5").show("slow");
					}
					else if(index == "opt_proj_manag_peson" && value == "no") {
						$("#box7").prop('checked', true);
						$("#table5").hide("slow");
					}
					else if(index == "opt_supp_employee" && value == "yes") {
						$("#box8").prop('checked', true);
						$("#table6").show("slow");
					}
					else if(index == "opt_supp_employee" && value == "no") {
						$("#box9").prop('checked', true);
						$("#table6").hide("slow");
					}
					// Section 7
					else if(index == "onw_dedc_prefab_shop" && value == "yes") {
						$("#box10").prop('checked', true);
					}
					else if(index == "onw_dedc_prefab_shop" && value == "no") {
						$("#box11").prop('checked', true);
					}
					else if(index == "prect_hours_spent_prefabr" && value == "0") {
						$("#box12").prop('checked', true);
					}
					else if(index == "prect_hours_spent_prefabr" && value == "1-3") {
						$("#box13").prop('checked', true);
					}
					else if(index == "prect_hours_spent_prefabr" && value == "3-5") {
						$("#box14").prop('checked', true);
					}
					else if(index == "prect_hours_spent_prefabr" && value == "5-10") {
						$("#box15").prop('checked', true);
					}
					else if(index == "prect_hours_spent_prefabr" && value == "10-25") {
						$("#box20").prop('checked', true);
					}
					else if(index == "prect_hours_spent_prefabr" && value == ">25") {
						$("#box21").prop('checked', true);
					}

					else if(index == "prect_tot_peop_hours_det_CAD" && value == "0") {
						$("#box16").prop('checked', true);
					}
					else if(index == "prect_tot_peop_hours_det_CAD" && value == "1-3") {
						$("#box17").prop('checked', true);
					}
					else if(index == "prect_tot_peop_hours_det_CAD" && value == "3-5") {
						$("#box18").prop('checked', true);
					}
					else if(index == "prect_tot_peop_hours_det_CAD" && value == "5-10") {
						$("#box22").prop('checked', true);
					}
					else if(index == "prect_tot_peop_hours_det_CAD" && value == "10-25") {
						$("#box23").prop('checked', true);
					}
					else if(index == "prect_tot_peop_hours_det_CAD" && value == ">25") {
						$("#box24").prop('checked', true);
					}
					
					// Section 8
					else if(index == "bim_yes_no" && value == "yes") {
						$("#box30").prop('checked', true);
						$("#table8").show("slow");
					}
					else if(index == "bim_yes_no" && value == "no") {
						$("#box31").prop('checked', true);
						$("#table8").hide("slow");
					}
				}
				else {
					if(value == null) {$("[name='"+index+"']").val('NULL');}
					else {$("[name='"+index+"']").val(value);}
				}
			});
			
        }, "json");
        setInterval(function () {
            $.post("processForms.php", $("form").serialize());
        }, 20000);
    });

    //Save when save button is clicked
    $("[name='save']").click(function () 
	{
		$.post("processForms.php", $("form").serialize());
		showModal3();
    });
	

    //Save when save button is clicked
    $("[name='saveCheck']").click(function () 
	{
		
		if(revenueCostCheck(2011)  && !bool1)
		{
			showModal4();
		}
		if(revenueCostCheck(2012)  && !bool2)
		{
			showModal5();
		}
		if(revenueCostCheck(2013)  && !bool3)
		{
			showModal6();
		}
		if(revenueCostCheck(2014)  && !bool4)
		{
			showModal7();
		}
		if(revenueCostCheck(2015)  && !bool5)
		{
			showModal8();
		}
		if(revenueCostCheck(2016)  && !bool6)
		{
			showModal9();
		}
		if(bool1 && bool2 && bool3 && bool4 && bool5 && bool6)
		{
			$.post("processForms.php", $("form").serialize());
			showModal3();		
		}	
	});


	function revenueCostCheck(year)
	{
		var revenueVal = null;
		var costMaterials = null;
		var payDisbursed = null;
		var payCompany = null;
		var othExpenses = null;
		
			
		if($("[name='revenue_"+year+"']").val() == "NULL" || $("[name='revenue_"+year+"']").val() == "") {revenueVal = 0;} else {revenueVal = $("[name='revenue_"+year+"']").val();}
		if($("[name='cost_materials_"+year+"']").val() == "NULL" || $("[name='cost_materials_"+year+"']").val() == "") {costMaterials = 0;} else {costMaterials = $("[name='cost_materials_"+year+"']").val();}
		if($("[name='pay_disbursed_subcontr_"+year+"']").val() == "NULL" || $("[name='pay_disbursed_subcontr_"+year+"']").val() == "") {payDisbursed = 0;} else {payDisbursed = $("[name='pay_disbursed_subcontr_"+year+"']").val();}
		if($("[name='pay_compny_people_"+year+"']").val() == "NULL" || $("[name='pay_compny_people_"+year+"']").val() == "") {payCompany = 0;} else {payCompany = $("[name='pay_compny_people_"+year+"']").val();}
		
		var tot = (Number(costMaterials) + Number(payDisbursed) + Number(payCompany) + Number(othExpenses));
		if(tot > revenueVal)
		{
			return true;
		}
		else
		{
			if(subVal == 2011)
				bool1 = true;
			if(subVal == 2012)
				bool2 = true;
			if(subVal == 2013)
				bool3 = true;
			if(subVal == 2014)
				bool4 = true;
			if(subVal == 2015)
				bool5 = true;
			if(subVal == 2016)
				bool6 = true;
			return false;
		}

	}
</script>
