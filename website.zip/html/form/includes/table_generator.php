<?php
define("MIN_YEAR_NUM", 2011);
define("MAX_YEAR_NUM", 2018);

function createYearTableHeader($preYearText, $postYearText, $pageNumber, $tableHint)
{
    $newHtmlRow = "<thead><tr><th></th><th>";
    if ($tableHint != "")
    {
        $newHtmlRow .= "<div class=\"help-tip\"><p>{$tableHint}</p></div>";
    }
    $newHtmlRow .= "</th>";
    $counter = 1;
    for ($year = MIN_YEAR_NUM; $year <= MAX_YEAR_NUM; $year++)
    {
        $newHtmlRow .= "<th style=\"text-align: center\"><br>{$preYearText}{$year}{$postYearText}<br><div class=\"naDiv\"><button type=\"button\" id=\"naColButtonP{$pageNumber}{$counter}\" class=\"naStyle\">N/A</button></div><br></th>";
        $counter++;
    }

    $newHtmlRow .= "</tr></thead>";

    echo $newHtmlRow;
};

function createYearTableRow($rowTitle, $rowHint, $rowVariableBase)
{
    $newHtmlRow = "<tr><th>{$rowTitle}</th>";
    $newHtmlRow .= "<td><div class=\"help-tip\"><p>{$rowHint}</p></div></td>";
    for ($year = MIN_YEAR_NUM; $year <= MAX_YEAR_NUM; $year++)
    {
    	$newHtmlRow .= "<td><div class=\"spin\"><input required type=\"text\" name=\"{$rowVariableBase}_{$year}\" onkeypress='return isNumberKey(event)'/><span>N/A</span></div></td>";
    }
    $newHtmlRow .= "</tr>";
    echo $newHtmlRow;
};

function createYearTableDropdownRow($rowTitle, $rowHint, $rowVariableBase, $optionsList)
{
    $newHtmlRow = "<tr><th>{$rowTitle}</th>";
    $newHtmlRow .= "<td><div class=\"help-tip\"><p>{$rowHint}</p></div></td>";
    for ($year = MIN_YEAR_NUM; $year <= MAX_YEAR_NUM; $year++)
    {
        $newHtmlRow .= "<td><div class=\"spin\"><select name=\"{$rowVariableBase}_{$year}\">";
        $i = 1;
        foreach ($optionsList as $optionName)
        {
            $newHtmlRow .= "<option value={$i}>{$optionName}</option>";
            $i++;
        }
        $newHtmlRow .= "<option value=NULL>N/A</option></select></div></td>";
    }
    $newHtmlRow .= "</tr>";
    echo $newHtmlRow;
};

function createSectionBreakTableRow()
{
    $newHtmlRow = "<tr style=\"background-color: #404040;\"><td></td><td></td>";
    for ($year = MIN_YEAR_NUM; $year <= MAX_YEAR_NUM; $year++)
    {
    	$newHtmlRow .= "<td></td>";
    }
    $newHtmlRow .= "</tr>";
    echo $newHtmlRow;
}

?>