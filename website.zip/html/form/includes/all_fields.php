<?php
static $year_field_names = array(
    'revenue',
    'total_expenses',
    'cost_materials',
    'pay_disbursed_subcontr',
    'gross_profit',
    'net_profit',
    'cost_bargain_employee',
    'fte_bargain_employee',
    'hours_bargain_employee',
    'cost_proj_manag_peson',
    'fte_proj_manag_peson',
    'hours_proj_manag_peson',
    'cost_supp_employee',
    'fte_supp_employee',
    'hours_supp_employee',
    'cost_apprentices',
    'fte_apprentices',
    'cost_journeymen',
    'fte_journeymen',
    'cost_foremen',
    'fte_foremen',
    'cost_prefab_workers',
    'fte_prefab_workers',
    'cost_material_handlers',
    'fte_material_handlers',
    'cost_constr_wiremen',
    'fte_constr_wiremen',
    'cost_others',
    'fte_others',
    'pay_compny_people',
    'oth_expenses',
    'cost_proj_manag',
    'fte_proj_manag',
    'cost_proj_engin',
    'fte_proj_engin',
    'cost_superitend',
    'fte_superitend',
    'cost_proj_exec',
    'fte_proj_exec',
    'cost_others_pmp',
    'fte_others_pmp',
    'cost_account',
    'fte_account',
    'cost_estimat',
    'fte_estimat',
    'cost_execu',
    'fte_execu',
    'cost_BIM_AutoCAD_employ',
    'fte_BIM_AutoCAD_employ',
    'cost_others_se',
    'fte_others_se',
    'prefabrication_perc',
    'overtime_premium',
    'second_shift_premium',
    'double_time_premium',
    'absenteeism_perc',
    'turnover_rate_bargaining_perc',
    'sub_to_journey_ratio',
    'journey_to_foremen_ratio',
    'fixed_overhead',
    'variable_overhead',
    'emr',
    'osha_incident_rate',
    'hit_rate',
    'repeat_customer_perc'
);

static $company_field_names = array(
    'company_name',
    'company_location',
    'city_state',
    'year_started_BIM',
    'prect_tot_peop_hours_det_CAD',
    //'step_one',
    'cost_other_ex_pmp',
    'fte_other_ex_pmp',
    //'submit',
    'opt_proj_manag_peson',
    'prect_hours_spent_prefabr',
    'BIM_staff_memb',
    'items_other_expenses',
    'opt_comp_bargain_employee',
    'opt_supp_employee',
    'cost_other_ex',
    'fte_other_ex',
    'bim_yes_no',
    'onw_dedc_prefab_shop',
    'cost_other_ex_se',
    'fte_other_ex_se',
    'fte_hours'
);

function getListOfYearFieldsExpandedByYear($year)
{
    global $year_field_names;

    $yearList = array();
    foreach($year_field_names as &$name)
    {
        $newField = "{$name}_{$year}";
        $yearList[] = $newField;
    }
    return $yearList;
}

function getListOfAllYearFieldsExpanded()
{
    $fullList = array();
    for ($year = 2011; $year <= 2018; $year++)
    {
        $fullList = array_merge($fullList, getListOfYearFieldsExpandedByYear($year));
    }
    return $fullList;
}

function getFullListOfFieldsExpandedByYear()
{
    global $company_field_names;

    $fullList = array();
    $fullList = array_merge($fullList, $company_field_names);
    $fullList = array_merge($fullList, getListOfAllYearFieldsExpanded());

    return $fullList;
}

function endsWith($str, $endsWith)
{
    $length = strlen($endsWith);
    if ($length == 0) {
        return true;
    }

    return (substr($str, -$length) === $endsWith);
}

function getTableForExpandedFieldName($fieldName)
{
    global $company_field_names;

    for ($year = 2011; $year <= 2018; $year++)
    {
        if (endsWith($fieldName, "_{$year}"))
            return $year;
    }
    if (in_array($fieldName, $company_field_names))
        return 0;
    
    return -1;
}

function removeYearTerminationFromField($fieldName)
{
    return substr($fieldName, 0, -5);
}


?>
