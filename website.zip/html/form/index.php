<?php

include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

sec_session_start();

if (login_check($mysqli) == true) {
    $logged = 'in';
} else {
    $logged = 'out';
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Electrical Contractors Productivity and Profitability</title>
        <link rel="stylesheet" href="styles/main.css" />
        <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script> 
		<link href="styles/style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body class="landingPageBody">
	
		<div id="bottomGradientLanding">
			<label class="viewPageHeader"><a href="../landing/" style="color:white; text-decoration: none;" >Electrical Contractors Productivity and Profitability</a></label>
		</div>
		
		<br><br><br><br><br><br><br><br>
		
		
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-md-offset-4">
					<div class="login-panel panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title">Please Sign In</h3>
						</div>
						<div class="panel-body">
							<form action="includes/process_login.php" method="post" name="login_form">
									<div class="form-group">
										<input class="form-control" placeholder="E-mail" name="email" type="email" autofocus>
									</div>
									<div class="form-group">
										<input class="form-control" placeholder="Password" name="password" type="password" id="password" value="">
									</div>
									
									<!-- Add link to sign-up-->
									<div class="errorText">
									Don't have an account?
									<a href="register.php">Sign Up</a>
									</div>

									<input type="button" name="loginButton" class="buttonClass" value=" Login " onclick="formhash(this.form, this.form.password);"/>
									<br>
									<div class="errorText">
									<?php
										if (isset($_GET['error'])) {
											echo '<p class="error">Error Logging In!</p>';
										}
									?>
									</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
    </body>
</html>
