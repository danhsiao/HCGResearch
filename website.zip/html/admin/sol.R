oldw <- getOption("warn")
options(warn = -1)

# Get Arguments from web
args <- commandArgs(TRUE)
webCompanyId <- args[1]

# Downloading libraries that enable the analysis
library(ggplot2)
require(ggplot2)
library(scales)
library(RColorBrewer)
require(RColorBrewer)

#Accessing images
library(jpeg)
require(jpeg)


cols <- brewer.pal(8,"Set1")
cols <- c("tomato","olivedrab3","darkturquoise","mediumorchid2")

# Load RODBC package
library(RMySQL)
con = dbConnect(MySQL(fetch.default.rec = 10000), user='sec_user', password='eKcGZr59zAa2BEWUXP', dbname='secure_login', host='localhost')
comp <- dbGetQuery(con, "SELECT * FROM secure_login.adminresults");


# Get Cur Company Name
webCompanyNameStore <- dbGetQuery(con, paste ("SELECT company_name FROM secure_login.forms where id=", webCompanyId));
webCompanyName <- webCompanyNameStore$company_name

#1 Net Profit Percentage Query
netProfitPercentageList2011 <- dbGetQuery(con, "SELECT net_profit_percentage FROM secure_login.adminresults where year=2011 AND net_profit_percentage is not null");
netProfitPercentageList2012 <- dbGetQuery(con, "SELECT net_profit_percentage FROM secure_login.adminresults where year=2012 AND net_profit_percentage is not null");
netProfitPercentageList2013 <- dbGetQuery(con, "SELECT net_profit_percentage FROM secure_login.adminresults where year=2013 AND net_profit_percentage is not null");
netProfitPercentageList2014 <- dbGetQuery(con, "SELECT net_profit_percentage FROM secure_login.adminresults where year=2014 AND net_profit_percentage is not null");
netProfitPercentageList2015 <- dbGetQuery(con, "SELECT net_profit_percentage FROM secure_login.adminresults where year=2015 AND net_profit_percentage is not null");
netProfitPercentageList2016 <- dbGetQuery(con, "SELECT net_profit_percentage FROM secure_login.adminresults where year=2016 AND net_profit_percentage is not null");
netProfitPercentageCurCompany2011 <- dbGetQuery(con, paste ("SELECT net_profit_percentage FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND net_profit_percentage is not null"));
netProfitPercentageCurCompany2012 <- dbGetQuery(con, paste ("SELECT net_profit_percentage FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND net_profit_percentage is not null"));
netProfitPercentageCurCompany2013 <- dbGetQuery(con, paste ("SELECT net_profit_percentage FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND net_profit_percentage is not null"));
netProfitPercentageCurCompany2014 <- dbGetQuery(con, paste ("SELECT net_profit_percentage FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND net_profit_percentage is not null"));
netProfitPercentageCurCompany2015 <- dbGetQuery(con, paste ("SELECT net_profit_percentage FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND net_profit_percentage is not null"));
netProfitPercentageCurCompany2016 <- dbGetQuery(con, paste ("SELECT net_profit_percentage FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND net_profit_percentage is not null"));






#5 Cost of purchased materials by the company as a percentage of the revenue Query
costPurchasedMaterials2011 <- dbGetQuery(con, "SELECT cost_purchased_materials FROM secure_login.adminresults where year=2011 AND cost_purchased_materials is not null");
costPurchasedMaterials2012 <- dbGetQuery(con, "SELECT cost_purchased_materials FROM secure_login.adminresults where year=2012 AND cost_purchased_materials is not null");
costPurchasedMaterials2013 <- dbGetQuery(con, "SELECT cost_purchased_materials FROM secure_login.adminresults where year=2013 AND cost_purchased_materials is not null");
costPurchasedMaterials2014 <- dbGetQuery(con, "SELECT cost_purchased_materials FROM secure_login.adminresults where year=2014 AND cost_purchased_materials is not null");
costPurchasedMaterials2015 <- dbGetQuery(con, "SELECT cost_purchased_materials FROM secure_login.adminresults where year=2015 AND cost_purchased_materials is not null");
costPurchasedMaterials2016 <- dbGetQuery(con, "SELECT cost_purchased_materials FROM secure_login.adminresults where year=2016 AND cost_purchased_materials is not null");
costPurchasedMaterialsCurCompany2011 <- dbGetQuery(con, paste ("SELECT cost_purchased_materials FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND cost_purchased_materials is not null"));
costPurchasedMaterialsCurCompany2012 <- dbGetQuery(con, paste ("SELECT cost_purchased_materials FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND cost_purchased_materials is not null"));
costPurchasedMaterialsCurCompany2013 <- dbGetQuery(con, paste ("SELECT cost_purchased_materials FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND cost_purchased_materials is not null"));
costPurchasedMaterialsCurCompany2014 <- dbGetQuery(con, paste ("SELECT cost_purchased_materials FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND cost_purchased_materials is not null"));
costPurchasedMaterialsCurCompany2015 <- dbGetQuery(con, paste ("SELECT cost_purchased_materials FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND cost_purchased_materials is not null"));
costPurchasedMaterialsCurCompany2016 <- dbGetQuery(con, paste ("SELECT cost_purchased_materials FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND cost_purchased_materials is not null"));


#6 Payments Disbursed to Subcontractors as a percentage of the Revenue Query
payDisbursedSubContrList2011 <- dbGetQuery(con, "SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2011 AND pay_disbursed_subcontr is not null");
payDisbursedSubContrList2012 <- dbGetQuery(con, "SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2012 AND pay_disbursed_subcontr is not null");
payDisbursedSubContrList2013 <- dbGetQuery(con, "SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2013 AND pay_disbursed_subcontr is not null");
payDisbursedSubContrList2014 <- dbGetQuery(con, "SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2014 AND pay_disbursed_subcontr is not null");
payDisbursedSubContrList2015 <- dbGetQuery(con, "SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2015 AND pay_disbursed_subcontr is not null");
payDisbursedSubContrList2016 <- dbGetQuery(con, "SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2016 AND pay_disbursed_subcontr is not null");
payDisbursedSubContrCurCompany2011 <- dbGetQuery(con, paste ("SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND pay_disbursed_subcontr is not null"));
payDisbursedSubContrCurCompany2012 <- dbGetQuery(con, paste ("SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND pay_disbursed_subcontr is not null"));
payDisbursedSubContrCurCompany2013 <- dbGetQuery(con, paste ("SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND pay_disbursed_subcontr is not null"));
payDisbursedSubContrCurCompany2014 <- dbGetQuery(con, paste ("SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND pay_disbursed_subcontr is not null"));
payDisbursedSubContrCurCompany2015 <- dbGetQuery(con, paste ("SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND pay_disbursed_subcontr is not null"));
payDisbursedSubContrCurCompany2016 <- dbGetQuery(con, paste ("SELECT pay_disbursed_subcontr FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND pay_disbursed_subcontr is not null"));


#8 Overall Productivity Measurement – Dollar Revenue/Hours of Company’s People Query
overallProductivityMeasurementList2011 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2011 AND overall_productivity_measurement_dollar_revenue is not null");
overallProductivityMeasurementList2012 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2012 AND overall_productivity_measurement_dollar_revenue is not null");
overallProductivityMeasurementList2013 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2013 AND overall_productivity_measurement_dollar_revenue is not null");
overallProductivityMeasurementList2014 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2014 AND overall_productivity_measurement_dollar_revenue is not null");
overallProductivityMeasurementList2015 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2015 AND overall_productivity_measurement_dollar_revenue is not null");
overallProductivityMeasurementList2016 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2016 AND overall_productivity_measurement_dollar_revenue is not null");
overallProductivityMeasurementCurCompany2011 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_revenue is not null"));
overallProductivityMeasurementCurCompany2012 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_revenue is not null"));
overallProductivityMeasurementCurCompany2013 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_revenue is not null"));
overallProductivityMeasurementCurCompany2014 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_revenue is not null"));
overallProductivityMeasurementCurCompany2015 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_revenue is not null"));
overallProductivityMeasurementCurCompany2016 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_revenue FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_revenue is not null"));


#9 Overall Productivity Measurement – Dollar Value Added/Hours of Company’s People 
overallProductivityMeasurementDollarValueAddedList2011 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2011 AND overall_productivity_measurement_dollar_value_added is not null");
overallProductivityMeasurementDollarValueAddedList2012 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2012 AND overall_productivity_measurement_dollar_value_added is not null");
overallProductivityMeasurementDollarValueAddedList2013 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2013 AND overall_productivity_measurement_dollar_value_added is not null");
overallProductivityMeasurementDollarValueAddedList2014 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2014 AND overall_productivity_measurement_dollar_value_added is not null");
overallProductivityMeasurementDollarValueAddedList2015 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2015 AND overall_productivity_measurement_dollar_value_added is not null");
overallProductivityMeasurementDollarValueAddedList2016 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2016 AND overall_productivity_measurement_dollar_value_added is not null");
overallProductivityMeasurementDollarValueAddedCurCompany2011 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_value_added is not null"));
overallProductivityMeasurementDollarValueAddedCurCompany2012 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_value_added is not null"));
overallProductivityMeasurementDollarValueAddedCurCompany2013 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_value_added is not null"));
overallProductivityMeasurementDollarValueAddedCurCompany2014 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_value_added is not null"));
overallProductivityMeasurementDollarValueAddedCurCompany2015 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_value_added is not null"));
overallProductivityMeasurementDollarValueAddedCurCompany2016 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_value_added FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_value_added is not null"));


#10 Overall Profitability Measurement – Dollar Net Profit /Hours of Company’s People
overallProductivityMeasurementDollarNetProfitList2011 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2011 AND overall_productivity_measurement_dollar_net_profit is not null");
overallProductivityMeasurementDollarNetProfitList2012 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2012 AND overall_productivity_measurement_dollar_net_profit is not null");
overallProductivityMeasurementDollarNetProfitList2013 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2013 AND overall_productivity_measurement_dollar_net_profit is not null");
overallProductivityMeasurementDollarNetProfitList2014 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2014 AND overall_productivity_measurement_dollar_net_profit is not null");
overallProductivityMeasurementDollarNetProfitList2015 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2015 AND overall_productivity_measurement_dollar_net_profit is not null");
overallProductivityMeasurementDollarNetProfitList2016 <- dbGetQuery(con, "SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2016 AND overall_productivity_measurement_dollar_net_profit is not null");
overallProductivityMeasurementDollarNetProfitCurCompany2011 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_net_profit is not null"));
overallProductivityMeasurementDollarNetProfitCurCompany2012 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_net_profit is not null"));
overallProductivityMeasurementDollarNetProfitCurCompany2013 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_net_profit is not null"));
overallProductivityMeasurementDollarNetProfitCurCompany2014 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_net_profit is not null"));
overallProductivityMeasurementDollarNetProfitCurCompany2015 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_net_profit is not null"));
overallProductivityMeasurementDollarNetProfitCurCompany2016 <- dbGetQuery(con, paste ("SELECT overall_productivity_measurement_dollar_net_profit FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND overall_productivity_measurement_dollar_net_profit is not null"));


#11 Project Management Productivity Measurement: Dollar Revenue/Hours of Project Management Personnel 
projectManagementDollarRevenueList2011 <- dbGetQuery(con, "SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2011 AND project_management_dollar_revenue is not null");
projectManagementDollarRevenueList2012 <- dbGetQuery(con, "SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2012 AND project_management_dollar_revenue is not null");
projectManagementDollarRevenueList2013 <- dbGetQuery(con, "SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2013 AND project_management_dollar_revenue is not null");
projectManagementDollarRevenueList2014 <- dbGetQuery(con, "SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2014 AND project_management_dollar_revenue is not null");
projectManagementDollarRevenueList2015 <- dbGetQuery(con, "SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2015 AND project_management_dollar_revenue is not null");
projectManagementDollarRevenueList2016 <- dbGetQuery(con, "SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2016 AND project_management_dollar_revenue is not null");
projectManagementDollarRevenueCurCompany2011 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND project_management_dollar_revenue is not null"));
projectManagementDollarRevenueCurCompany2012 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND project_management_dollar_revenue is not null"));
projectManagementDollarRevenueCurCompany2013 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND project_management_dollar_revenue is not null"));
projectManagementDollarRevenueCurCompany2014 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND project_management_dollar_revenue is not null"));
projectManagementDollarRevenueCurCompany2015 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND project_management_dollar_revenue is not null"));
projectManagementDollarRevenueCurCompany2016 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND project_management_dollar_revenue is not null"));


#12 Project Management Productivity Measurement: Dollar Value Added/Hours of Project Management Personnel 
projectManagementDollarValueAddedList2011 <- dbGetQuery(con, "SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2011 AND project_management_dollar_value_added is not null");
projectManagementDollarValueAddedList2012 <- dbGetQuery(con, "SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2012 AND project_management_dollar_value_added is not null");
projectManagementDollarValueAddedList2013 <- dbGetQuery(con, "SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2013 AND project_management_dollar_value_added is not null");
projectManagementDollarValueAddedList2014 <- dbGetQuery(con, "SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2014 AND project_management_dollar_value_added is not null");
projectManagementDollarValueAddedList2015 <- dbGetQuery(con, "SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2015 AND project_management_dollar_value_added is not null");
projectManagementDollarValueAddedList2016 <- dbGetQuery(con, "SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2016 AND project_management_dollar_value_added is not null");
projectManagementDollarValueAddedCurCompany2011 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND project_management_dollar_value_added is not null"));
projectManagementDollarValueAddedCurCompany2012 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND project_management_dollar_value_added is not null"));
projectManagementDollarValueAddedCurCompany2013 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND project_management_dollar_value_added is not null"));
projectManagementDollarValueAddedCurCompany2014 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND project_management_dollar_value_added is not null"));
projectManagementDollarValueAddedCurCompany2015 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND project_management_dollar_value_added is not null"));
projectManagementDollarValueAddedCurCompany2016 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND project_management_dollar_value_added is not null"));


#13 Project Management Profitability Measurement: Dollar Net Profit /Hours of Project Management Personnel 
projectManagementDollarNetProfitList2011 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2011 AND project_management_dollar_net_profit is not null");
projectManagementDollarNetProfitList2012 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2012 AND project_management_dollar_net_profit is not null");
projectManagementDollarNetProfitList2013 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2013 AND project_management_dollar_net_profit is not null");
projectManagementDollarNetProfitList2014 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2014 AND project_management_dollar_net_profit is not null");
projectManagementDollarNetProfitList2015 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2015 AND project_management_dollar_net_profit is not null");
projectManagementDollarNetProfitList2016 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2016 AND project_management_dollar_net_profit is not null");
projectManagementDollarNetProfitCurCompany2011 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND project_management_dollar_net_profit is not null"));
projectManagementDollarNetProfitCurCompany2012 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND project_management_dollar_net_profit is not null"));
projectManagementDollarNetProfitCurCompany2013 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND project_management_dollar_net_profit is not null"));
projectManagementDollarNetProfitCurCompany2014 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND project_management_dollar_net_profit is not null"));
projectManagementDollarNetProfitCurCompany2015 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND project_management_dollar_net_profit is not null"));
projectManagementDollarNetProfitCurCompany2016 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND project_management_dollar_net_profit is not null"));


#14 Craft Worker Productivity Measurement: Dollar Revenue/ Hours of Bargaining Unit Employees 
craftWorkerDollarRevenueList2011 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2011 AND craft_worker_dollar_revenue is not null");
craftWorkerDollarRevenueList2012 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2012 AND craft_worker_dollar_revenue is not null");
craftWorkerDollarRevenueList2013 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2013 AND craft_worker_dollar_revenue is not null");
craftWorkerDollarRevenueList2014 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2014 AND craft_worker_dollar_revenue is not null");
craftWorkerDollarRevenueList2015 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2015 AND craft_worker_dollar_revenue is not null");
craftWorkerDollarRevenueList2016 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2016 AND craft_worker_dollar_revenue is not null");
craftWorkerDollarRevenueCurCompany2011 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND craft_worker_dollar_revenue is not null"));
craftWorkerDollarRevenueCurCompany2012 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND craft_worker_dollar_revenue is not null"));
craftWorkerDollarRevenueCurCompany2013 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND craft_worker_dollar_revenue is not null"));
craftWorkerDollarRevenueCurCompany2014 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND craft_worker_dollar_revenue is not null"));
craftWorkerDollarRevenueCurCompany2015 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND craft_worker_dollar_revenue is not null"));
craftWorkerDollarRevenueCurCompany2016 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND craft_worker_dollar_revenue is not null"));


#15 Craft Worker Productivity Measurement: Dollar Value Added/ Hours of Bargaining Unit 
craftWorkerDollarValueAddedList2011 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2011 AND craft_worker_dollar_value_added is not null");
craftWorkerDollarValueAddedList2012 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2012 AND craft_worker_dollar_value_added is not null");
craftWorkerDollarValueAddedList2013 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2013 AND craft_worker_dollar_value_added is not null");
craftWorkerDollarValueAddedList2014 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2014 AND craft_worker_dollar_value_added is not null");
craftWorkerDollarValueAddedList2015 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2015 AND craft_worker_dollar_value_added is not null");
craftWorkerDollarValueAddedList2016 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2016 AND craft_worker_dollar_value_added is not null");
craftWorkerDollarValueAddedCurCompany2011 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND craft_worker_dollar_value_added is not null"));
craftWorkerDollarValueAddedCurCompany2012 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND craft_worker_dollar_value_added is not null"));
craftWorkerDollarValueAddedCurCompany2013 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND craft_worker_dollar_value_added is not null"));
craftWorkerDollarValueAddedCurCompany2014 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND craft_worker_dollar_value_added is not null"));
craftWorkerDollarValueAddedCurCompany2015 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND craft_worker_dollar_value_added is not null"));
craftWorkerDollarValueAddedCurCompany2016 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND craft_worker_dollar_value_added is not null"));


#16 Craft Worker Profitability Measurement: Dollar Net Profit / Hours of Bargaining Unit Employees 
craftWorkerDollarNetProfitList2011 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2011 AND craft_worker_dollar_net_profit is not null");
craftWorkerDollarNetProfitList2012 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2012 AND craft_worker_dollar_net_profit is not null");
craftWorkerDollarNetProfitList2013 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2013 AND craft_worker_dollar_net_profit is not null");
craftWorkerDollarNetProfitList2014 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2014 AND craft_worker_dollar_net_profit is not null");
craftWorkerDollarNetProfitList2015 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2015 AND craft_worker_dollar_net_profit is not null");
craftWorkerDollarNetProfitList2016 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2016 AND craft_worker_dollar_net_profit is not null");
craftWorkerDollarNetProfitCurCompany2011 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit is not null"));
craftWorkerDollarNetProfitCurCompany2012 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit is not null"));
craftWorkerDollarNetProfitCurCompany2013 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit is not null"));
craftWorkerDollarNetProfitCurCompany2014 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit is not null"));
craftWorkerDollarNetProfitCurCompany2015 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit is not null"));
craftWorkerDollarNetProfitCurCompany2016 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit is not null"));


#17 Supporting Employees Productivity Measurement: Dollar Revenue/ Hours of Supporting Employees 
supportingEmployeeDollarRevenueList2011 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2011 AND supporting_employee_dollar_revenue is not null");
supportingEmployeeDollarRevenueList2012 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2012 AND supporting_employee_dollar_revenue is not null");
supportingEmployeeDollarRevenueList2013 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2013 AND supporting_employee_dollar_revenue is not null");
supportingEmployeeDollarRevenueList2014 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2014 AND supporting_employee_dollar_revenue is not null");
supportingEmployeeDollarRevenueList2015 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2015 AND supporting_employee_dollar_revenue is not null");
supportingEmployeeDollarRevenueList2016 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2016 AND supporting_employee_dollar_revenue is not null");
supportingEmployeeDollarRevenueCurCompany2011 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue is not null"));
supportingEmployeeDollarRevenueCurCompany2012 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue is not null"));
supportingEmployeeDollarRevenueCurCompany2013 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue is not null"));
supportingEmployeeDollarRevenueCurCompany2014 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue is not null"));
supportingEmployeeDollarRevenueCurCompany2015 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue is not null"));
supportingEmployeeDollarRevenueCurCompany2016 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue is not null"));


#18 Supporting Employees Productivity Measurement: Dollar Value Added/ Hours of Supporting Employees
supportingEmployeeDollarValueAddedList2011 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2011 AND supporting_employee_dollar_value_added is not null");
supportingEmployeeDollarValueAddedList2012 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2012 AND supporting_employee_dollar_value_added is not null");
supportingEmployeeDollarValueAddedList2013 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2013 AND supporting_employee_dollar_value_added is not null");
supportingEmployeeDollarValueAddedList2014 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2014 AND supporting_employee_dollar_value_added is not null");
supportingEmployeeDollarValueAddedList2015 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2015 AND supporting_employee_dollar_value_added is not null");
supportingEmployeeDollarValueAddedList2016 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2016 AND supporting_employee_dollar_value_added is not null");
supportingEmployeeDollarValueAddedCurCompany2011 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added is not null"));
supportingEmployeeDollarValueAddedCurCompany2012 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added is not null"));
supportingEmployeeDollarValueAddedCurCompany2013 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added is not null"));
supportingEmployeeDollarValueAddedCurCompany2014 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added is not null"));
supportingEmployeeDollarValueAddedCurCompany2015 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added is not null"));
supportingEmployeeDollarValueAddedCurCompany2016 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added is not null"));


#19 Supporting Employees Profitability Measurement: Dollar Net Profit / Hours of Supporting Employees
supportingEmployeeDollarNetProfitList2011 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2011 AND supporting_employee_dollar_net_profit is not null");
supportingEmployeeDollarNetProfitList2012 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2012 AND supporting_employee_dollar_net_profit is not null");
supportingEmployeeDollarNetProfitList2013 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2013 AND supporting_employee_dollar_net_profit is not null");
supportingEmployeeDollarNetProfitList2014 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2014 AND supporting_employee_dollar_net_profit is not null");
supportingEmployeeDollarNetProfitList2015 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2015 AND supporting_employee_dollar_net_profit is not null");
supportingEmployeeDollarNetProfitList2016 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2016 AND supporting_employee_dollar_net_profit is not null");
supportingEmployeeDollarNetProfitCurCompany2011 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit is not null"));
supportingEmployeeDollarNetProfitCurCompany2012 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit is not null"));
supportingEmployeeDollarNetProfitCurCompany2013 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit is not null"));
supportingEmployeeDollarNetProfitCurCompany2014 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit is not null"));
supportingEmployeeDollarNetProfitCurCompany2015 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit is not null"));
supportingEmployeeDollarNetProfitCurCompany2016 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit is not null"));



#20 Overall Productivity Measurement – Dollar Revenue/FTEs of Company’s People 
overallProductivityDollarRevenueFteList2011 <- dbGetQuery(con, "SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2011 AND overall_productivity_dollar_revenue_fte is not null");
overallProductivityDollarRevenueFteList2012 <- dbGetQuery(con, "SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2012 AND overall_productivity_dollar_revenue_fte is not null");
overallProductivityDollarRevenueFteList2013 <- dbGetQuery(con, "SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2013 AND overall_productivity_dollar_revenue_fte is not null");
overallProductivityDollarRevenueFteList2014 <- dbGetQuery(con, "SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2014 AND overall_productivity_dollar_revenue_fte is not null");
overallProductivityDollarRevenueFteList2015 <- dbGetQuery(con, "SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2015 AND overall_productivity_dollar_revenue_fte is not null");
overallProductivityDollarRevenueFteList2016 <- dbGetQuery(con, "SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2016 AND overall_productivity_dollar_revenue_fte is not null");
overallProductivityDollarRevenueFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND overall_productivity_dollar_revenue_fte is not null"));
overallProductivityDollarRevenueFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND overall_productivity_dollar_revenue_fte is not null"));
overallProductivityDollarRevenueFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND overall_productivity_dollar_revenue_fte is not null"));
overallProductivityDollarRevenueFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND overall_productivity_dollar_revenue_fte is not null"));
overallProductivityDollarRevenueFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND overall_productivity_dollar_revenue_fte is not null"));
overallProductivityDollarRevenueFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_revenue_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND overall_productivity_dollar_revenue_fte is not null"));


#21 - Overall Productivity Measurement – Dollar Value Added/FTEs of Company’s People 
overallProductivityDollarValueAddedFteList2011 <- dbGetQuery(con, "SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2011 AND overall_productivity_dollar_value_added_fte is not null");
overallProductivityDollarValueAddedFteList2012 <- dbGetQuery(con, "SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2012 AND overall_productivity_dollar_value_added_fte is not null");
overallProductivityDollarValueAddedFteList2013 <- dbGetQuery(con, "SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2013 AND overall_productivity_dollar_value_added_fte is not null");
overallProductivityDollarValueAddedFteList2014 <- dbGetQuery(con, "SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2014 AND overall_productivity_dollar_value_added_fte is not null");
overallProductivityDollarValueAddedFteList2015 <- dbGetQuery(con, "SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2015 AND overall_productivity_dollar_value_added_fte is not null");
overallProductivityDollarValueAddedFteList2016 <- dbGetQuery(con, "SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2016 AND overall_productivity_dollar_value_added_fte is not null");
overallProductivityDollarValueAddedFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND overall_productivity_dollar_value_added_fte is not null"));
overallProductivityDollarValueAddedFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND overall_productivity_dollar_value_added_fte is not null"));
overallProductivityDollarValueAddedFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND overall_productivity_dollar_value_added_fte is not null"));
overallProductivityDollarValueAddedFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND overall_productivity_dollar_value_added_fte is not null"));
overallProductivityDollarValueAddedFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND overall_productivity_dollar_value_added_fte is not null"));
overallProductivityDollarValueAddedFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_value_added_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND overall_productivity_dollar_value_added_fte is not null"));


#22 - Overall Profitability Measurement – Dollar Net Profit /FTEs of  Company’s People
overallProductivityDollarNetProfitFteList2011 <- dbGetQuery(con, "SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2011 AND overall_productivity_dollar_net_profit_fte is not null");
overallProductivityDollarNetProfitFteList2012 <- dbGetQuery(con, "SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2012 AND overall_productivity_dollar_net_profit_fte is not null");
overallProductivityDollarNetProfitFteList2013 <- dbGetQuery(con, "SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2013 AND overall_productivity_dollar_net_profit_fte is not null");
overallProductivityDollarNetProfitFteList2014 <- dbGetQuery(con, "SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2014 AND overall_productivity_dollar_net_profit_fte is not null");
overallProductivityDollarNetProfitFteList2015 <- dbGetQuery(con, "SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2015 AND overall_productivity_dollar_net_profit_fte is not null");
overallProductivityDollarNetProfitFteList2016 <- dbGetQuery(con, "SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2016 AND overall_productivity_dollar_net_profit_fte is not null");
overallProductivityDollarNetProfitFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND overall_productivity_dollar_net_profit_fte is not null"));
overallProductivityDollarNetProfitFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND overall_productivity_dollar_net_profit_fte is not null"));
overallProductivityDollarNetProfitFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND overall_productivity_dollar_net_profit_fte is not null"));
overallProductivityDollarNetProfitFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND overall_productivity_dollar_net_profit_fte is not null"));
overallProductivityDollarNetProfitFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND overall_productivity_dollar_net_profit_fte is not null"));
overallProductivityDollarNetProfitFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT overall_productivity_dollar_net_profit_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND overall_productivity_dollar_net_profit_fte is not null"));


#23 - Project Management Productivity Measurement: Dollar Revenue/FTEs of Project Management Personnel 
projectManagementDollarRevenuePersonnelFteList2011 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2011 AND project_management_dollar_revenue_fte is not null");
projectManagementDollarRevenuePersonnelFteList2012 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2012 AND project_management_dollar_revenue_fte is not null");
projectManagementDollarRevenuePersonnelFteList2013 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2013 AND project_management_dollar_revenue_fte is not null");
projectManagementDollarRevenuePersonnelFteList2014 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2014 AND project_management_dollar_revenue_fte is not null");
projectManagementDollarRevenuePersonnelFteList2015 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2015 AND project_management_dollar_revenue_fte is not null");
projectManagementDollarRevenuePersonnelFteList2016 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2016 AND project_management_dollar_revenue_fte is not null");
projectManagementDollarRevenuePersonnelFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND project_management_dollar_revenue_fte is not null"));
projectManagementDollarRevenuePersonnelFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND project_management_dollar_revenue_fte is not null"));
projectManagementDollarRevenuePersonnelFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND project_management_dollar_revenue_fte is not null"));
projectManagementDollarRevenuePersonnelFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND project_management_dollar_revenue_fte is not null"));
projectManagementDollarRevenuePersonnelFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND project_management_dollar_revenue_fte is not null"));
projectManagementDollarRevenuePersonnelFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND project_management_dollar_revenue_fte is not null"));


#24 - Project Management Productivity Measurement: Dollar Value Added/FTEs of Project Management 
projectManagementDollarValueAddedPersonnelFteList2011 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2011 AND project_management_dollar_value_added_fte is not null");
projectManagementDollarValueAddedPersonnelFteList2012 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2012 AND project_management_dollar_value_added_fte is not null");
projectManagementDollarValueAddedPersonnelFteList2013 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2013 AND project_management_dollar_value_added_fte is not null");
projectManagementDollarValueAddedPersonnelFteList2014 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2014 AND project_management_dollar_value_added_fte is not null");
projectManagementDollarValueAddedPersonnelFteList2015 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2015 AND project_management_dollar_value_added_fte is not null");
projectManagementDollarValueAddedPersonnelFteList2016 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2016 AND project_management_dollar_value_added_fte is not null");
projectManagementDollarValueAddedPersonnelFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND project_management_dollar_value_added_fte is not null"));
projectManagementDollarValueAddedPersonnelFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND project_management_dollar_value_added_fte is not null"));
projectManagementDollarValueAddedPersonnelFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND project_management_dollar_value_added_fte is not null"));
projectManagementDollarValueAddedPersonnelFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND project_management_dollar_value_added_fte is not null"));
projectManagementDollarValueAddedPersonnelFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND project_management_dollar_value_added_fte is not null"));
projectManagementDollarValueAddedPersonnelFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND project_management_dollar_value_added_fte is not null"));


#25 - Project Management Profitability Measurement: Dollar Net Profit /FTEs of Project Management Personnel 
projectManagementDollarNetProfitPersonnelFteList2011 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2011 AND project_management_dollar_net_profit_fte is not null");
projectManagementDollarNetProfitPersonnelFteList2012 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2012 AND project_management_dollar_net_profit_fte is not null");
projectManagementDollarNetProfitPersonnelFteList2013 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2013 AND project_management_dollar_net_profit_fte is not null");
projectManagementDollarNetProfitPersonnelFteList2014 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2014 AND project_management_dollar_net_profit_fte is not null");
projectManagementDollarNetProfitPersonnelFteList2015 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2015 AND project_management_dollar_net_profit_fte is not null");
projectManagementDollarNetProfitPersonnelFteList2016 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2016 AND project_management_dollar_net_profit_fte is not null");
projectManagementDollarNetProfitPersonnelFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND project_management_dollar_net_profit_fte is not null"));
projectManagementDollarNetProfitPersonnelFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND project_management_dollar_net_profit_fte is not null"));
projectManagementDollarNetProfitPersonnelFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND project_management_dollar_net_profit_fte is not null"));
projectManagementDollarNetProfitPersonnelFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND project_management_dollar_net_profit_fte is not null"));
projectManagementDollarNetProfitPersonnelFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND project_management_dollar_net_profit_fte is not null"));
projectManagementDollarNetProfitPersonnelFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND project_management_dollar_net_profit_fte is not null"));


#26 - Craft Worker Productivity Measurement: Dollar Revenue/ FTEs of Bargaining Unit Employees 
craftWorkerDollarRevenueFteList2011 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2011 AND craft_worker_dollar_revenue_fte is not null");
craftWorkerDollarRevenueFteList2012 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2012 AND craft_worker_dollar_revenue_fte is not null");
craftWorkerDollarRevenueFteList2013 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2013 AND craft_worker_dollar_revenue_fte is not null");
craftWorkerDollarRevenueFteList2014 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2014 AND craft_worker_dollar_revenue_fte is not null");
craftWorkerDollarRevenueFteList2015 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2015 AND craft_worker_dollar_revenue_fte is not null");
craftWorkerDollarRevenueFteList2016 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2016 AND craft_worker_dollar_revenue_fte is not null");
craftWorkerDollarRevenueFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_fte is not null"));
craftWorkerDollarRevenueFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_fte is not null"));
craftWorkerDollarRevenueFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_fte is not null"));
craftWorkerDollarRevenueFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_fte is not null"));
craftWorkerDollarRevenueFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_fte is not null"));
craftWorkerDollarRevenueFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_fte is not null"));


#27 - Craft Worker Productivity Measurement: Dollar Value Added/ FTEs of Bargaining Unit 
craftWorkerDollarValueAddedFteList2011 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2011 AND craft_worker_dollar_value_added_fte is not null");
craftWorkerDollarValueAddedFteList2012 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2012 AND craft_worker_dollar_value_added_fte is not null");
craftWorkerDollarValueAddedFteList2013 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2013 AND craft_worker_dollar_value_added_fte is not null");
craftWorkerDollarValueAddedFteList2014 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2014 AND craft_worker_dollar_value_added_fte is not null");
craftWorkerDollarValueAddedFteList2015 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2015 AND craft_worker_dollar_value_added_fte is not null");
craftWorkerDollarValueAddedFteList2016 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2016 AND craft_worker_dollar_value_added_fte is not null");
craftWorkerDollarValueAddedFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_fte is not null"));
craftWorkerDollarValueAddedFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_fte is not null"));
craftWorkerDollarValueAddedFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_fte is not null"));
craftWorkerDollarValueAddedFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_fte is not null"));
craftWorkerDollarValueAddedFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_fte is not null"));
craftWorkerDollarValueAddedFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_fte is not null"));


#28 - Craft Worker Profitability Measurement: Dollar Net Profit / FTEs of Bargaining Unit Employees 
craftWorkerDollarNetProfitFteList2011 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2011 AND craft_worker_dollar_net_profit_fte is not null");
craftWorkerDollarNetProfitFteList2012 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2012 AND craft_worker_dollar_net_profit_fte is not null");
craftWorkerDollarNetProfitFteList2013 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2013 AND craft_worker_dollar_net_profit_fte is not null");
craftWorkerDollarNetProfitFteList2014 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2014 AND craft_worker_dollar_net_profit_fte is not null");
craftWorkerDollarNetProfitFteList2015 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2015 AND craft_worker_dollar_net_profit_fte is not null");
craftWorkerDollarNetProfitFteList2016 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2016 AND craft_worker_dollar_net_profit_fte is not null");
craftWorkerDollarNetProfitFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_fte is not null"));
craftWorkerDollarNetProfitFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_fte is not null"));
craftWorkerDollarNetProfitFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_fte is not null"));
craftWorkerDollarNetProfitFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_fte is not null"));
craftWorkerDollarNetProfitFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_fte is not null"));
craftWorkerDollarNetProfitFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_fte is not null"));


#29 - Supporting Employees Productivity Measurement: Dollar Revenue/ FTEs of Supporting Employees 
supportingEmployeeDollarRevenueFteList2011 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2011 AND supporting_employee_dollar_revenue_fte is not null");
supportingEmployeeDollarRevenueFteList2012 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2012 AND supporting_employee_dollar_revenue_fte is not null");
supportingEmployeeDollarRevenueFteList2013 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2013 AND supporting_employee_dollar_revenue_fte is not null");
supportingEmployeeDollarRevenueFteList2014 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2014 AND supporting_employee_dollar_revenue_fte is not null");
supportingEmployeeDollarRevenueFteList2015 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2015 AND supporting_employee_dollar_revenue_fte is not null");
supportingEmployeeDollarRevenueFteList2016 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2016 AND supporting_employee_dollar_revenue_fte is not null");
supportingEmployeeDollarRevenueFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_fte is not null"));
supportingEmployeeDollarRevenueFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_fte is not null"));
supportingEmployeeDollarRevenueFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_fte is not null"));
supportingEmployeeDollarRevenueFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_fte is not null"));
supportingEmployeeDollarRevenueFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_fte is not null"));
supportingEmployeeDollarRevenueFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_fte is not null"));


#30 - Supporting Employees Productivity Measurement: Dollar Value Added/ FTEs of Supporting Employees
supportingEmployeeDollarValueAddedFteList2011 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2011 AND supporting_employee_dollar_value_added_fte is not null");
supportingEmployeeDollarValueAddedFteList2012 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2012 AND supporting_employee_dollar_value_added_fte is not null");
supportingEmployeeDollarValueAddedFteList2013 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2013 AND supporting_employee_dollar_value_added_fte is not null");
supportingEmployeeDollarValueAddedFteList2014 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2014 AND supporting_employee_dollar_value_added_fte is not null");
supportingEmployeeDollarValueAddedFteList2015 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2015 AND supporting_employee_dollar_value_added_fte is not null");
supportingEmployeeDollarValueAddedFteList2016 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2016 AND supporting_employee_dollar_value_added_fte is not null");
supportingEmployeeDollarValueAddedFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_fte is not null"));
supportingEmployeeDollarValueAddedFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_fte is not null"));
supportingEmployeeDollarValueAddedFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_fte is not null"));
supportingEmployeeDollarValueAddedFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_fte is not null"));
supportingEmployeeDollarValueAddedFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_fte is not null"));
supportingEmployeeDollarValueAddedFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_fte is not null"));


#31 - Supporting Employees Profitability Measurement: Dollar Net Profit / FTEs of Supporting Employees
supportingEmployeeDollarNetProfitFteList2011 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2011 AND supporting_employee_dollar_net_profit_added_fte is not null");
supportingEmployeeDollarNetProfitFteList2012 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2012 AND supporting_employee_dollar_net_profit_added_fte is not null");
supportingEmployeeDollarNetProfitFteList2013 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2013 AND supporting_employee_dollar_net_profit_added_fte is not null");
supportingEmployeeDollarNetProfitFteList2014 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2014 AND supporting_employee_dollar_net_profit_added_fte is not null");
supportingEmployeeDollarNetProfitFteList2015 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2015 AND supporting_employee_dollar_net_profit_added_fte is not null");
supportingEmployeeDollarNetProfitFteList2016 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2016 AND supporting_employee_dollar_net_profit_added_fte is not null");
supportingEmployeeDollarNetProfitFteCurCompany2011 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_added_fte is not null"));
supportingEmployeeDollarNetProfitFteCurCompany2012 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_added_fte is not null"));
supportingEmployeeDollarNetProfitFteCurCompany2013 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_added_fte is not null"));
supportingEmployeeDollarNetProfitFteCurCompany2014 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_added_fte is not null"));
supportingEmployeeDollarNetProfitFteCurCompany2015 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_added_fte is not null"));
supportingEmployeeDollarNetProfitFteCurCompany2016 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_added_fte FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_added_fte is not null"));


#32 - Overall Cost Effectiveness – Dollar Revenue/Cost of Company’s People 
overallCostEffectivenessDollarRevenueList2011 <- dbGetQuery(con, "SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2011 AND overall_cost_dollar_revenue_cost is not null");
overallCostEffectivenessDollarRevenueList2012 <- dbGetQuery(con, "SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2012 AND overall_cost_dollar_revenue_cost is not null");
overallCostEffectivenessDollarRevenueList2013 <- dbGetQuery(con, "SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2013 AND overall_cost_dollar_revenue_cost is not null");
overallCostEffectivenessDollarRevenueList2014 <- dbGetQuery(con, "SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2014 AND overall_cost_dollar_revenue_cost is not null");
overallCostEffectivenessDollarRevenueList2015 <- dbGetQuery(con, "SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2015 AND overall_cost_dollar_revenue_cost is not null");
overallCostEffectivenessDollarRevenueList2016 <- dbGetQuery(con, "SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2016 AND overall_cost_dollar_revenue_cost is not null");
overallCostEffectivenessDollarRevenueCurCompany2011 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND overall_cost_dollar_revenue_cost is not null"));
overallCostEffectivenessDollarRevenueCurCompany2012 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND overall_cost_dollar_revenue_cost is not null"));
overallCostEffectivenessDollarRevenueCurCompany2013 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND overall_cost_dollar_revenue_cost is not null"));
overallCostEffectivenessDollarRevenueCurCompany2014 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND overall_cost_dollar_revenue_cost is not null"));
overallCostEffectivenessDollarRevenueCurCompany2015 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND overall_cost_dollar_revenue_cost is not null"));
overallCostEffectivenessDollarRevenueCurCompany2016 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_revenue_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND overall_cost_dollar_revenue_cost is not null"));


#33 - Overall Cost Effectiveness – Dollar Value Added/ Cost of Company’s People 
overallCostEffectivenessDollarValueAddedList2011 <- dbGetQuery(con, "SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2011 AND overall_cost_dollar_value_added_cost is not null");
overallCostEffectivenessDollarValueAddedList2012 <- dbGetQuery(con, "SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2012 AND overall_cost_dollar_value_added_cost is not null");
overallCostEffectivenessDollarValueAddedList2013 <- dbGetQuery(con, "SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2013 AND overall_cost_dollar_value_added_cost is not null");
overallCostEffectivenessDollarValueAddedList2014 <- dbGetQuery(con, "SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2014 AND overall_cost_dollar_value_added_cost is not null");
overallCostEffectivenessDollarValueAddedList2015 <- dbGetQuery(con, "SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2015 AND overall_cost_dollar_value_added_cost is not null");
overallCostEffectivenessDollarValueAddedList2016 <- dbGetQuery(con, "SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2016 AND overall_cost_dollar_value_added_cost is not null");
overallCostEffectivenessDollarValueAddedCurCompany2011 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND overall_cost_dollar_value_added_cost is not null"));
overallCostEffectivenessDollarValueAddedCurCompany2012 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND overall_cost_dollar_value_added_cost is not null"));
overallCostEffectivenessDollarValueAddedCurCompany2013 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND overall_cost_dollar_value_added_cost is not null"));
overallCostEffectivenessDollarValueAddedCurCompany2014 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND overall_cost_dollar_value_added_cost is not null"));
overallCostEffectivenessDollarValueAddedCurCompany2015 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND overall_cost_dollar_value_added_cost is not null"));
overallCostEffectivenessDollarValueAddedCurCompany2016 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_value_added_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND overall_cost_dollar_value_added_cost is not null"));


#34 - Overall Cost Effectiveness – Dollar Net Profit / Cost of Company’s People 
overallCostEffectivenessDollarNetProfitList2011 <- dbGetQuery(con, "SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2011 AND overall_cost_dollar_net_profit_cost is not null");
overallCostEffectivenessDollarNetProfitList2012 <- dbGetQuery(con, "SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2012 AND overall_cost_dollar_net_profit_cost is not null");
overallCostEffectivenessDollarNetProfitList2013 <- dbGetQuery(con, "SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2013 AND overall_cost_dollar_net_profit_cost is not null");
overallCostEffectivenessDollarNetProfitList2014 <- dbGetQuery(con, "SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2014 AND overall_cost_dollar_net_profit_cost is not null");
overallCostEffectivenessDollarNetProfitList2015 <- dbGetQuery(con, "SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2015 AND overall_cost_dollar_net_profit_cost is not null");
overallCostEffectivenessDollarNetProfitList2016 <- dbGetQuery(con, "SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2016 AND overall_cost_dollar_net_profit_cost is not null");
overallCostEffectivenessDollarNetProfitCurCompany2011 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND overall_cost_dollar_net_profit_cost is not null"));
overallCostEffectivenessDollarNetProfitCurCompany2012 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND overall_cost_dollar_net_profit_cost is not null"));
overallCostEffectivenessDollarNetProfitCurCompany2013 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND overall_cost_dollar_net_profit_cost is not null"));
overallCostEffectivenessDollarNetProfitCurCompany2014 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND overall_cost_dollar_net_profit_cost is not null"));
overallCostEffectivenessDollarNetProfitCurCompany2015 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND overall_cost_dollar_net_profit_cost is not null"));
overallCostEffectivenessDollarNetProfitCurCompany2016 <- dbGetQuery(con, paste ("SELECT overall_cost_dollar_net_profit_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND overall_cost_dollar_net_profit_cost is not null"));


#35 - Project Management Cost Effectiveness: Dollar Revenue/ Cost of Project Management Personnel 
projectManagementCostDollarRevenueList2011 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2011 AND project_management_dollar_revenue_cost is not null");
projectManagementCostDollarRevenueList2012 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2012 AND project_management_dollar_revenue_cost is not null");
projectManagementCostDollarRevenueList2013 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2013 AND project_management_dollar_revenue_cost is not null");
projectManagementCostDollarRevenueList2014 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2014 AND project_management_dollar_revenue_cost is not null");
projectManagementCostDollarRevenueList2015 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2015 AND project_management_dollar_revenue_cost is not null");
projectManagementCostDollarRevenueList2016 <- dbGetQuery(con, "SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2016 AND project_management_dollar_revenue_cost is not null");
projectManagementCostDollarRevenueCurCompany2011 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND project_management_dollar_revenue_cost is not null"));
projectManagementCostDollarRevenueCurCompany2012 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND project_management_dollar_revenue_cost is not null"));
projectManagementCostDollarRevenueCurCompany2013 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND project_management_dollar_revenue_cost is not null"));
projectManagementCostDollarRevenueCurCompany2014 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND project_management_dollar_revenue_cost is not null"));
projectManagementCostDollarRevenueCurCompany2015 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND project_management_dollar_revenue_cost is not null"));
projectManagementCostDollarRevenueCurCompany2016 <- dbGetQuery(con, paste ("SELECT project_management_dollar_revenue_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND project_management_dollar_revenue_cost is not null"));


#36 - Project Management Cost Effectiveness: Dollar Value Added/ Cost of Project Management Personnel 
projectManagementCostDollarValueAddedList2011 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2011 AND project_management_dollar_value_added_cost is not null");
projectManagementCostDollarValueAddedList2012 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2012 AND project_management_dollar_value_added_cost is not null");
projectManagementCostDollarValueAddedList2013 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2013 AND project_management_dollar_value_added_cost is not null");
projectManagementCostDollarValueAddedList2014 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2014 AND project_management_dollar_value_added_cost is not null");
projectManagementCostDollarValueAddedList2015 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2015 AND project_management_dollar_value_added_cost is not null");
projectManagementCostDollarValueAddedList2016 <- dbGetQuery(con, "SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2016 AND project_management_dollar_value_added_cost is not null");
projectManagementCostDollarValueAddedCurCompany2011 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND project_management_dollar_value_added_cost is not null"));
projectManagementCostDollarValueAddedCurCompany2012 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND project_management_dollar_value_added_cost is not null"));
projectManagementCostDollarValueAddedCurCompany2013 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND project_management_dollar_value_added_cost is not null"));
projectManagementCostDollarValueAddedCurCompany2014 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND project_management_dollar_value_added_cost is not null"));
projectManagementCostDollarValueAddedCurCompany2015 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND project_management_dollar_value_added_cost is not null"));
projectManagementCostDollarValueAddedCurCompany2016 <- dbGetQuery(con, paste ("SELECT project_management_dollar_value_added_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND project_management_dollar_value_added_cost is not null"));


#37 - Project Management Cost Effectiveness: Dollar Net Profit / Cost of Project Management Personnel 
projectManagementCostDollarNetProfitList2011 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2011 AND project_management_dollar_net_profit_cost is not null");
projectManagementCostDollarNetProfitList2012 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2012 AND project_management_dollar_net_profit_cost is not null");
projectManagementCostDollarNetProfitList2013 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2013 AND project_management_dollar_net_profit_cost is not null");
projectManagementCostDollarNetProfitList2014 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2014 AND project_management_dollar_net_profit_cost is not null");
projectManagementCostDollarNetProfitList2015 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2015 AND project_management_dollar_net_profit_cost is not null");
projectManagementCostDollarNetProfitList2016 <- dbGetQuery(con, "SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2016 AND project_management_dollar_net_profit_cost is not null");
projectManagementCostDollarNetProfitCurCompany2011 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND project_management_dollar_net_profit_cost is not null"));
projectManagementCostDollarNetProfitCurCompany2012 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND project_management_dollar_net_profit_cost is not null"));
projectManagementCostDollarNetProfitCurCompany2013 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND project_management_dollar_net_profit_cost is not null"));
projectManagementCostDollarNetProfitCurCompany2014 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND project_management_dollar_net_profit_cost is not null"));
projectManagementCostDollarNetProfitCurCompany2015 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND project_management_dollar_net_profit_cost is not null"));
projectManagementCostDollarNetProfitCurCompany2016 <- dbGetQuery(con, paste ("SELECT project_management_dollar_net_profit_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND project_management_dollar_net_profit_cost is not null"));


#38 - Craft Worker Cost Effectiveness: Dollar Revenue/ Cost of Bargaining Unit Employees 
craftWorkerCostEffectDollarRevenueList2011 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2011 AND craft_worker_dollar_revenue_cost is not null");
craftWorkerCostEffectDollarRevenueList2012 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2012 AND craft_worker_dollar_revenue_cost is not null");
craftWorkerCostEffectDollarRevenueList2013 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2013 AND craft_worker_dollar_revenue_cost is not null");
craftWorkerCostEffectDollarRevenueList2014 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2014 AND craft_worker_dollar_revenue_cost is not null");
craftWorkerCostEffectDollarRevenueList2015 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2015 AND craft_worker_dollar_revenue_cost is not null");
craftWorkerCostEffectDollarRevenueList2016 <- dbGetQuery(con, "SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2016 AND craft_worker_dollar_revenue_cost is not null");
craftWorkerCostEffectDollarRevenueCurCompany2011 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_cost is not null"));
craftWorkerCostEffectDollarRevenueCurCompany2012 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_cost is not null"));
craftWorkerCostEffectDollarRevenueCurCompany2013 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_cost is not null"));
craftWorkerCostEffectDollarRevenueCurCompany2014 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_cost is not null"));
craftWorkerCostEffectDollarRevenueCurCompany2015 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_cost is not null"));
craftWorkerCostEffectDollarRevenueCurCompany2016 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_revenue_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND craft_worker_dollar_revenue_cost is not null"));


#39 - Craft Worker Cost Effectiveness: Dollar Value Added/ Cost of Bargaining Unit Employees
craftWorkerCostEffectDollarValueAddedList2011 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2011 AND craft_worker_dollar_value_added_cost is not null");
craftWorkerCostEffectDollarValueAddedList2012 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2012 AND craft_worker_dollar_value_added_cost is not null");
craftWorkerCostEffectDollarValueAddedList2013 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2013 AND craft_worker_dollar_value_added_cost is not null");
craftWorkerCostEffectDollarValueAddedList2014 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2014 AND craft_worker_dollar_value_added_cost is not null");
craftWorkerCostEffectDollarValueAddedList2015 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2015 AND craft_worker_dollar_value_added_cost is not null");
craftWorkerCostEffectDollarValueAddedList2016 <- dbGetQuery(con, "SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2016 AND craft_worker_dollar_value_added_cost is not null");
craftWorkerCostEffectDollarValueAddedCurCompany2011 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_cost is not null"));
craftWorkerCostEffectDollarValueAddedCurCompany2012 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_cost is not null"));
craftWorkerCostEffectDollarValueAddedCurCompany2013 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_cost is not null"));
craftWorkerCostEffectDollarValueAddedCurCompany2014 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_cost is not null"));
craftWorkerCostEffectDollarValueAddedCurCompany2015 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_cost is not null"));
craftWorkerCostEffectDollarValueAddedCurCompany2016 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_value_added_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND craft_worker_dollar_value_added_cost is not null"));


#40 - Craft Worker Cost Effectiveness: Dollar Net Profit / Cost of Bargaining Unit Employees 
craftWorkerCostEffectDollarNetProfitList2011 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2011 AND craft_worker_dollar_net_profit_cost is not null");
craftWorkerCostEffectDollarNetProfitList2012 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2012 AND craft_worker_dollar_net_profit_cost is not null");
craftWorkerCostEffectDollarNetProfitList2013 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2013 AND craft_worker_dollar_net_profit_cost is not null");
craftWorkerCostEffectDollarNetProfitList2014 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2014 AND craft_worker_dollar_net_profit_cost is not null");
craftWorkerCostEffectDollarNetProfitList2015 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2015 AND craft_worker_dollar_net_profit_cost is not null");
craftWorkerCostEffectDollarNetProfitList2016 <- dbGetQuery(con, "SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2016 AND craft_worker_dollar_net_profit_cost is not null");
craftWorkerCostEffectDollarNetProfitCurCompany2011 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_cost is not null"));
craftWorkerCostEffectDollarNetProfitCurCompany2012 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_cost is not null"));
craftWorkerCostEffectDollarNetProfitCurCompany2013 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_cost is not null"));
craftWorkerCostEffectDollarNetProfitCurCompany2014 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_cost is not null"));
craftWorkerCostEffectDollarNetProfitCurCompany2015 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_cost is not null"));
craftWorkerCostEffectDollarNetProfitCurCompany2016 <- dbGetQuery(con, paste ("SELECT craft_worker_dollar_net_profit_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND craft_worker_dollar_net_profit_cost is not null"));


#41 - Supporting Employees Cost Effectiveness: Dollar Revenue/ Cost of Supporting Employees 
supportingEmployeeCostEffectDollarRevenueList2011 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2011 AND supporting_employee_dollar_revenue_cost is not null");
supportingEmployeeCostEffectDollarRevenueList2012 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2012 AND supporting_employee_dollar_revenue_cost is not null");
supportingEmployeeCostEffectDollarRevenueList2013 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2013 AND supporting_employee_dollar_revenue_cost is not null");
supportingEmployeeCostEffectDollarRevenueList2014 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2014 AND supporting_employee_dollar_revenue_cost is not null");
supportingEmployeeCostEffectDollarRevenueList2015 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2015 AND supporting_employee_dollar_revenue_cost is not null");
supportingEmployeeCostEffectDollarRevenueList2016 <- dbGetQuery(con, "SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2016 AND supporting_employee_dollar_revenue_cost is not null");
supportingEmployeeCostEffectDollarRevenueCurCompany2011 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_cost is not null"));
supportingEmployeeCostEffectDollarRevenueCurCompany2012 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_cost is not null"));
supportingEmployeeCostEffectDollarRevenueCurCompany2013 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_cost is not null"));
supportingEmployeeCostEffectDollarRevenueCurCompany2014 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_cost is not null"));
supportingEmployeeCostEffectDollarRevenueCurCompany2015 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_cost is not null"));
supportingEmployeeCostEffectDollarRevenueCurCompany2016 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_revenue_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND supporting_employee_dollar_revenue_cost is not null"));


#42 - Supporting Employees Cost Effectiveness: Dollar Value Added/ Cost of Supporting Employees
supportingEmployeeCostEffectDollarValueAddedList2011 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2011 AND supporting_employee_dollar_value_added_cost is not null");
supportingEmployeeCostEffectDollarValueAddedList2012 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2012 AND supporting_employee_dollar_value_added_cost is not null");
supportingEmployeeCostEffectDollarValueAddedList2013 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2013 AND supporting_employee_dollar_value_added_cost is not null");
supportingEmployeeCostEffectDollarValueAddedList2014 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2014 AND supporting_employee_dollar_value_added_cost is not null");
supportingEmployeeCostEffectDollarValueAddedList2015 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2015 AND supporting_employee_dollar_value_added_cost is not null");
supportingEmployeeCostEffectDollarValueAddedList2016 <- dbGetQuery(con, "SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2016 AND supporting_employee_dollar_value_added_cost is not null");
supportingEmployeeCostEffectDollarValueAddedCurCompany2011 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_cost is not null"));
supportingEmployeeCostEffectDollarValueAddedCurCompany2012 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_cost is not null"));
supportingEmployeeCostEffectDollarValueAddedCurCompany2013 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_cost is not null"));
supportingEmployeeCostEffectDollarValueAddedCurCompany2014 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_cost is not null"));
supportingEmployeeCostEffectDollarValueAddedCurCompany2015 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_cost is not null"));
supportingEmployeeCostEffectDollarValueAddedCurCompany2016 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_value_added_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND supporting_employee_dollar_value_added_cost is not null"));


#43 - Supporting Employees Cost Effectiveness: Dollar Net Profit / Cost of Supporting Employees
supportingEmployeeCostEffectDollarNetProfitList2011 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2011 AND supporting_employee_dollar_net_profit_cost is not null");
supportingEmployeeCostEffectDollarNetProfitList2012 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2012 AND supporting_employee_dollar_net_profit_cost is not null");
supportingEmployeeCostEffectDollarNetProfitList2013 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2013 AND supporting_employee_dollar_net_profit_cost is not null");
supportingEmployeeCostEffectDollarNetProfitList2014 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2014 AND supporting_employee_dollar_net_profit_cost is not null");
supportingEmployeeCostEffectDollarNetProfitList2015 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2015 AND supporting_employee_dollar_net_profit_cost is not null");
supportingEmployeeCostEffectDollarNetProfitList2016 <- dbGetQuery(con, "SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2016 AND supporting_employee_dollar_net_profit_cost is not null");
supportingEmployeeCostEffectDollarNetProfitCurCompany2011 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_cost is not null"));
supportingEmployeeCostEffectDollarNetProfitCurCompany2012 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_cost is not null"));
supportingEmployeeCostEffectDollarNetProfitCurCompany2013 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_cost is not null"));
supportingEmployeeCostEffectDollarNetProfitCurCompany2014 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_cost is not null"));
supportingEmployeeCostEffectDollarNetProfitCurCompany2015 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_cost is not null"));
supportingEmployeeCostEffectDollarNetProfitCurCompany2016 <- dbGetQuery(con, paste ("SELECT supporting_employee_dollar_net_profit_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND supporting_employee_dollar_net_profit_cost is not null"));


#44 - Cost of Field Project Management Personnel per Hours of Field Project Management Personnel
costFieldProjManagementList2011 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2011 AND cost_field_project_management_personnel is not null");
costFieldProjManagementList2012 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2012 AND cost_field_project_management_personnel is not null");
costFieldProjManagementList2013 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2013 AND cost_field_project_management_personnel is not null");
costFieldProjManagementList2014 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2014 AND cost_field_project_management_personnel is not null");
costFieldProjManagementList2015 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2015 AND cost_field_project_management_personnel is not null");
costFieldProjManagementList2016 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2016 AND cost_field_project_management_personnel is not null");
costFieldProjManagementCurCompany2011 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND cost_field_project_management_personnel is not null"));
costFieldProjManagementCurCompany2012 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND cost_field_project_management_personnel is not null"));
costFieldProjManagementCurCompany2013 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND cost_field_project_management_personnel is not null"));
costFieldProjManagementCurCompany2014 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND cost_field_project_management_personnel is not null"));
costFieldProjManagementCurCompany2015 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND cost_field_project_management_personnel is not null"));
costFieldProjManagementCurCompany2016 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND cost_field_project_management_personnel is not null"));


#45 - Cost of Bargaining Unit Employees per Expended Man Hours of Bargaining Unit Employees
costBargainingUnitEmployeeList2011 <- dbGetQuery(con, "SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2011 AND cost_bargaining_unit_employee_expended is not null");
costBargainingUnitEmployeeList2012 <- dbGetQuery(con, "SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2012 AND cost_bargaining_unit_employee_expended is not null");
costBargainingUnitEmployeeList2013 <- dbGetQuery(con, "SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2013 AND cost_bargaining_unit_employee_expended is not null");
costBargainingUnitEmployeeList2014 <- dbGetQuery(con, "SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2014 AND cost_bargaining_unit_employee_expended is not null");
costBargainingUnitEmployeeList2015 <- dbGetQuery(con, "SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2015 AND cost_bargaining_unit_employee_expended is not null");
costBargainingUnitEmployeeList2016 <- dbGetQuery(con, "SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2016 AND cost_bargaining_unit_employee_expended is not null");
costBargainingUnitEmployeeCurCompany2011 <- dbGetQuery(con, paste ("SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND cost_bargaining_unit_employee_expended is not null"));
costBargainingUnitEmployeeCurCompany2012 <- dbGetQuery(con, paste ("SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND cost_bargaining_unit_employee_expended is not null"));
costBargainingUnitEmployeeCurCompany2013 <- dbGetQuery(con, paste ("SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND cost_bargaining_unit_employee_expended is not null"));
costBargainingUnitEmployeeCurCompany2014 <- dbGetQuery(con, paste ("SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND cost_bargaining_unit_employee_expended is not null"));
costBargainingUnitEmployeeCurCompany2015 <- dbGetQuery(con, paste ("SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND cost_bargaining_unit_employee_expended is not null"));
costBargainingUnitEmployeeCurCompany2016 <- dbGetQuery(con, paste ("SELECT cost_bargaining_unit_employee_expended FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND cost_bargaining_unit_employee_expended is not null"));


#46 - Cost of Supporting Employees per Hours of Supporting Employees
costSupportingEmployeesList2011 <- dbGetQuery(con, "SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2011 AND cost_supporting_employee_per_hour is not null");
costSupportingEmployeesList2012 <- dbGetQuery(con, "SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2012 AND cost_supporting_employee_per_hour is not null");
costSupportingEmployeesList2013 <- dbGetQuery(con, "SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2013 AND cost_supporting_employee_per_hour is not null");
costSupportingEmployeesList2014 <- dbGetQuery(con, "SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2014 AND cost_supporting_employee_per_hour is not null");
costSupportingEmployeesList2015 <- dbGetQuery(con, "SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2015 AND cost_supporting_employee_per_hour is not null");
costSupportingEmployeesList2016 <- dbGetQuery(con, "SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2016 AND cost_supporting_employee_per_hour is not null");
costSupportingEmployeesCurCompany2011 <- dbGetQuery(con, paste ("SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND cost_supporting_employee_per_hour is not null"));
costSupportingEmployeesCurCompany2012 <- dbGetQuery(con, paste ("SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND cost_supporting_employee_per_hour is not null"));
costSupportingEmployeesCurCompany2013 <- dbGetQuery(con, paste ("SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND cost_supporting_employee_per_hour is not null"));
costSupportingEmployeesCurCompany2014 <- dbGetQuery(con, paste ("SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND cost_supporting_employee_per_hour is not null"));
costSupportingEmployeesCurCompany2015 <- dbGetQuery(con, paste ("SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND cost_supporting_employee_per_hour is not null"));
costSupportingEmployeesCurCompany2016 <- dbGetQuery(con, paste ("SELECT cost_supporting_employee_per_hour FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND cost_supporting_employee_per_hour is not null"));


#47 - Cost of Field Project Management Personnel per Cost of Bargaining Unit Employees 
costFieldProjManagementPersonnelList2011 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2011 AND cost_field_project_management_personnel_cost is not null");
costFieldProjManagementPersonnelList2012 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2012 AND cost_field_project_management_personnel_cost is not null");
costFieldProjManagementPersonnelList2013 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2013 AND cost_field_project_management_personnel_cost is not null");
costFieldProjManagementPersonnelList2014 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2014 AND cost_field_project_management_personnel_cost is not null");
costFieldProjManagementPersonnelList2015 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2015 AND cost_field_project_management_personnel_cost is not null");
costFieldProjManagementPersonnelList2016 <- dbGetQuery(con, "SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2016 AND cost_field_project_management_personnel_cost is not null");
costFieldProjManagementPersonnelCurCompany2011 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND cost_field_project_management_personnel_cost is not null"));
costFieldProjManagementPersonnelCurCompany2012 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND cost_field_project_management_personnel_cost is not null"));
costFieldProjManagementPersonnelCurCompany2013 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND cost_field_project_management_personnel_cost is not null"));
costFieldProjManagementPersonnelCurCompany2014 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND cost_field_project_management_personnel_cost is not null"));
costFieldProjManagementPersonnelCurCompany2015 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND cost_field_project_management_personnel_cost is not null"));
costFieldProjManagementPersonnelCurCompany2016 <- dbGetQuery(con, paste ("SELECT cost_field_project_management_personnel_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND cost_field_project_management_personnel_cost is not null"));


#48 - Cost of Supporting Employees per Cost of Bargaining Unit Employees
costSupportingEmployeeCostBargainingList2011 <- dbGetQuery(con, "SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2011 AND cost_supp_employee_cost is not null");
costSupportingEmployeeCostBargainingList2012 <- dbGetQuery(con, "SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2012 AND cost_supp_employee_cost is not null");
costSupportingEmployeeCostBargainingList2013 <- dbGetQuery(con, "SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2013 AND cost_supp_employee_cost is not null");
costSupportingEmployeeCostBargainingList2014 <- dbGetQuery(con, "SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2014 AND cost_supp_employee_cost is not null");
costSupportingEmployeeCostBargainingList2015 <- dbGetQuery(con, "SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2015 AND cost_supp_employee_cost is not null");
costSupportingEmployeeCostBargainingList2016 <- dbGetQuery(con, "SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2016 AND cost_supp_employee_cost is not null");
costSupportingEmployeeCostBargainingCurCompany2011 <- dbGetQuery(con, paste ("SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND cost_supp_employee_cost is not null"));
costSupportingEmployeeCostBargainingCurCompany2012 <- dbGetQuery(con, paste ("SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND cost_supp_employee_cost is not null"));
costSupportingEmployeeCostBargainingCurCompany2013 <- dbGetQuery(con, paste ("SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND cost_supp_employee_cost is not null"));
costSupportingEmployeeCostBargainingCurCompany2014 <- dbGetQuery(con, paste ("SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND cost_supp_employee_cost is not null"));
costSupportingEmployeeCostBargainingCurCompany2015 <- dbGetQuery(con, paste ("SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND cost_supp_employee_cost is not null"));
costSupportingEmployeeCostBargainingCurCompany2016 <- dbGetQuery(con, paste ("SELECT cost_supp_employee_cost FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND cost_supp_employee_cost is not null"));


#49 - Hours of Field Project Management Personnel per Hours of Bargaining Unit Employees 
hoursFieldProjectManagementList2011 <- dbGetQuery(con, "SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2011 AND hours_field_project_management_personnel is not null");
hoursFieldProjectManagementList2012 <- dbGetQuery(con, "SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2012 AND hours_field_project_management_personnel is not null");
hoursFieldProjectManagementList2013 <- dbGetQuery(con, "SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2013 AND hours_field_project_management_personnel is not null");
hoursFieldProjectManagementList2014 <- dbGetQuery(con, "SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2014 AND hours_field_project_management_personnel is not null");
hoursFieldProjectManagementList2015 <- dbGetQuery(con, "SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2015 AND hours_field_project_management_personnel is not null");
hoursFieldProjectManagementList2016 <- dbGetQuery(con, "SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2016 AND hours_field_project_management_personnel is not null");
hoursFieldProjectManagementCurCompany2011 <- dbGetQuery(con, paste ("SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND hours_field_project_management_personnel is not null"));
hoursFieldProjectManagementCurCompany2012 <- dbGetQuery(con, paste ("SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND hours_field_project_management_personnel is not null"));
hoursFieldProjectManagementCurCompany2013 <- dbGetQuery(con, paste ("SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND hours_field_project_management_personnel is not null"));
hoursFieldProjectManagementCurCompany2014 <- dbGetQuery(con, paste ("SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND hours_field_project_management_personnel is not null"));
hoursFieldProjectManagementCurCompany2015 <- dbGetQuery(con, paste ("SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND hours_field_project_management_personnel is not null"));
hoursFieldProjectManagementCurCompany2016 <- dbGetQuery(con, paste ("SELECT hours_field_project_management_personnel FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND hours_field_project_management_personnel is not null"));


#50 - Hours of Supporting Employees per Hours of Bargaining Unit Employees 
hoursSupportingEmployeeList2011 <- dbGetQuery(con, "SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2011 AND hours_supporting_employee_per_hour is not null");
hoursSupportingEmployeeList2012 <- dbGetQuery(con, "SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2012 AND hours_supporting_employee_per_hour is not null");
hoursSupportingEmployeeList2013 <- dbGetQuery(con, "SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2013 AND hours_supporting_employee_per_hour is not null");
hoursSupportingEmployeeList2014 <- dbGetQuery(con, "SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2014 AND hours_supporting_employee_per_hour is not null");
hoursSupportingEmployeeList2015 <- dbGetQuery(con, "SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2015 AND hours_supporting_employee_per_hour is not null");
hoursSupportingEmployeeList2016 <- dbGetQuery(con, "SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2016 AND hours_supporting_employee_per_hour is not null");
hoursSupportingEmployeeCurCompany2011 <- dbGetQuery(con, paste ("SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2011 and company_id=", webCompanyId," AND hours_supporting_employee_per_hour is not null"));
hoursSupportingEmployeeCurCompany2012 <- dbGetQuery(con, paste ("SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2012 and company_id=", webCompanyId," AND hours_supporting_employee_per_hour is not null"));
hoursSupportingEmployeeCurCompany2013 <- dbGetQuery(con, paste ("SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2013 and company_id=", webCompanyId," AND hours_supporting_employee_per_hour is not null"));
hoursSupportingEmployeeCurCompany2014 <- dbGetQuery(con, paste ("SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2014 and company_id=", webCompanyId," AND hours_supporting_employee_per_hour is not null"));
hoursSupportingEmployeeCurCompany2015 <- dbGetQuery(con, paste ("SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2015 and company_id=", webCompanyId," AND hours_supporting_employee_per_hour is not null"));
hoursSupportingEmployeeCurCompany2016 <- dbGetQuery(con, paste ("SELECT hours_supporting_employee_per_hour FROM secure_login.adminresults where year=2016 and company_id=", webCompanyId," AND hours_supporting_employee_per_hour is not null"));



######################################################################################################################################


#50 - Hours of Supporting Employees per Hours of Bargaining Unit Employees 
Hours.of.Supporting.Employees.per.Expended.Man.Hours.of.Bargaining.Unit.Employees=comp$hours_supporting_employee_per_hour
#2011 data of (1)
hoursSupportingEmployeeQuantile2011 = quantile(hoursSupportingEmployeeList2011$hours_supporting_employee_per_hour,c(.25,.5,.75))
hoursSupportingEmployeeMean2011 = mean(hoursSupportingEmployeeList2011$hours_supporting_employee_per_hour)
#2012 data of (1)
hoursSupportingEmployeeQuantile2012= quantile(hoursSupportingEmployeeList2012$hours_supporting_employee_per_hour,c(.25,.5,.75))
hoursSupportingEmployeeMean2012 = mean(hoursSupportingEmployeeList2012$hours_supporting_employee_per_hour)
#2013 data of (1)
hoursSupportingEmployeeQuantile2013 = quantile(hoursSupportingEmployeeList2013$hours_supporting_employee_per_hour,c(.25,.5,.75))
hoursSupportingEmployeeMean2013 = mean(hoursSupportingEmployeeList2013$hours_supporting_employee_per_hour)
#2014 data of (1)
hoursSupportingEmployeeQuantile2014 = quantile(hoursSupportingEmployeeList2014$hours_supporting_employee_per_hour,c(.25,.5,.75))
hoursSupportingEmployeeMean2014 = mean(hoursSupportingEmployeeList2014$hours_supporting_employee_per_hour)
#2015 data of (1)
hoursSupportingEmployeeQuantile2015 = quantile(hoursSupportingEmployeeList2015$hours_supporting_employee_per_hour,c(.25,.5,.75))
hoursSupportingEmployeeMean2015 = mean(hoursSupportingEmployeeList2015$hours_supporting_employee_per_hour)
#2016 data of (1)
hoursSupportingEmployeeQuantile2016 = quantile(hoursSupportingEmployeeList2016$hours_supporting_employee_per_hour,c(.25,.5,.75))
hoursSupportingEmployeeMean2016 = mean(hoursSupportingEmployeeList2016$hours_supporting_employee_per_hour)


#49 - Hours of Field Project Management Personnel per Hours of Bargaining Unit Employees 
Hours.of.Field.Project.Management.Personnel.per.Expended.Man.Hours.of.Bargaining.Unit.Employees=comp$hours_field_project_management_personnel
#2011 data of (1)
hoursFieldProjectManagementQuantile2011 = quantile(hoursFieldProjectManagementList2011$hours_field_project_management_personnel,c(.25,.5,.75))
hoursFieldProjectManagementMean2011 = mean(hoursFieldProjectManagementList2011$hours_field_project_management_personnel)
#2012 data of (1)
hoursFieldProjectManagementQuantile2012= quantile(hoursFieldProjectManagementList2012$hours_field_project_management_personnel,c(.25,.5,.75))
hoursFieldProjectManagementMean2012 = mean(hoursFieldProjectManagementList2012$hours_field_project_management_personnel)
#2013 data of (1)
hoursFieldProjectManagementQuantile2013 = quantile(hoursFieldProjectManagementList2013$hours_field_project_management_personnel,c(.25,.5,.75))
hoursFieldProjectManagementMean2013 = mean(hoursFieldProjectManagementList2013$hours_field_project_management_personnel)
#2014 data of (1)
hoursFieldProjectManagementQuantile2014 = quantile(hoursFieldProjectManagementList2014$hours_field_project_management_personnel,c(.25,.5,.75))
hoursFieldProjectManagementMean2014 = mean(hoursFieldProjectManagementList2014$hours_field_project_management_personnel)
#2015 data of (1)
hoursFieldProjectManagementQuantile2015 = quantile(hoursFieldProjectManagementList2015$hours_field_project_management_personnel,c(.25,.5,.75))
hoursFieldProjectManagementMean2015 = mean(hoursFieldProjectManagementList2015$hours_field_project_management_personnel)
#2016 data of (1)
hoursFieldProjectManagementQuantile2016 = quantile(hoursFieldProjectManagementList2016$hours_field_project_management_personnel,c(.25,.5,.75))
hoursFieldProjectManagementMean2016 = mean(hoursFieldProjectManagementList2016$hours_field_project_management_personnel)


#48 - Cost of Supporting Employees per Cost of Bargaining Unit Employees
Cost.of.Supporting.Employees.per.Cost.of.Bargaining.Unit.Employees=comp$cost_supp_employee_cost
#2011 data of (1)
costSupportingEmployeeCostBargainingQuantile2011 = quantile(costSupportingEmployeeCostBargainingList2011$cost_supp_employee_cost,c(.25,.5,.75))
costSupportingEmployeeCostBargainingMean2011 = mean(costSupportingEmployeeCostBargainingList2011$cost_supp_employee_cost)
#2012 data of (1)
costSupportingEmployeeCostBargainingQuantile2012= quantile(costSupportingEmployeeCostBargainingList2012$cost_supp_employee_cost,c(.25,.5,.75))
costSupportingEmployeeCostBargainingMean2012 = mean(costSupportingEmployeeCostBargainingList2012$cost_supp_employee_cost)
#2013 data of (1)
costSupportingEmployeeCostBargainingQuantile2013 = quantile(costSupportingEmployeeCostBargainingList2013$cost_supp_employee_cost,c(.25,.5,.75))
costSupportingEmployeeCostBargainingMean2013 = mean(costSupportingEmployeeCostBargainingList2013$cost_supp_employee_cost)
#2014 data of (1)
costSupportingEmployeeCostBargainingQuantile2014 = quantile(costSupportingEmployeeCostBargainingList2014$cost_supp_employee_cost,c(.25,.5,.75))
costSupportingEmployeeCostBargainingMean2014 = mean(costSupportingEmployeeCostBargainingList2014$cost_supp_employee_cost)
#2015 data of (1)
costSupportingEmployeeCostBargainingQuantile2015 = quantile(costSupportingEmployeeCostBargainingList2015$cost_supp_employee_cost,c(.25,.5,.75))
costSupportingEmployeeCostBargainingMean2015 = mean(costSupportingEmployeeCostBargainingList2015$cost_supp_employee_cost)
#2016 data of (1)
costSupportingEmployeeCostBargainingQuantile2016 = quantile(costSupportingEmployeeCostBargainingList2016$cost_supp_employee_cost,c(.25,.5,.75))
costSupportingEmployeeCostBargainingMean2016 = mean(costSupportingEmployeeCostBargainingList2016$cost_supp_employee_cost)


#47 - Cost of Field Project Management Personnel per Cost of Bargaining Unit Employees 
Cost.of.Field.Project.Management.Personnel.per.Cost.of.Bargaining.Unit.Employees=comp$cost_field_project_management_personnel_cost
#2011 data of (1)
costFieldProjManagementPersonnelQuantile2011 = quantile(costFieldProjManagementPersonnelList2011$cost_field_project_management_personnel_cost,c(.25,.5,.75))
costFieldProjManagementPersonnelMean2011 = mean(costFieldProjManagementPersonnelList2011$cost_field_project_management_personnel_cost)
#2012 data of (1)
costFieldProjManagementPersonnelQuantile2012 = quantile(costFieldProjManagementPersonnelList2012$cost_field_project_management_personnel_cost,c(.25,.5,.75))
costFieldProjManagementPersonnelMean2012 = mean(costFieldProjManagementPersonnelList2012$cost_field_project_management_personnel_cost)
#2013 data of (1)
costFieldProjManagementPersonnelQuantile2013 = quantile(costFieldProjManagementPersonnelList2013$cost_field_project_management_personnel_cost,c(.25,.5,.75))
costFieldProjManagementPersonnelMean2013 = mean(costFieldProjManagementPersonnelList2013$cost_field_project_management_personnel_cost)
#2014 data of (1)
costFieldProjManagementPersonnelQuantile2014 = quantile(costFieldProjManagementPersonnelList2014$cost_field_project_management_personnel_cost,c(.25,.5,.75))
costFieldProjManagementPersonnelMean2014 = mean(costFieldProjManagementPersonnelList2014$cost_field_project_management_personnel_cost)
#2015 data of (1)
costFieldProjManagementPersonnelQuantile2015 = quantile(costFieldProjManagementPersonnelList2015$cost_field_project_management_personnel_cost,c(.25,.5,.75))
costFieldProjManagementPersonnelMean2015 = mean(costFieldProjManagementPersonnelList2015$cost_field_project_management_personnel_cost)
#2016 data of (1)
costFieldProjManagementPersonnelQuantile2016 = quantile(costFieldProjManagementPersonnelList2016$cost_field_project_management_personnel_cost,c(.25,.5,.75))
costFieldProjManagementPersonnelMean2016 = mean(costFieldProjManagementPersonnelList2016$cost_field_project_management_personnel_cost)


#46 - Cost of Supporting Employees per Hours of Supporting Employees
Cost.of.Supporting.Employees.per.Hours.of.Supporting.Employees=comp$cost_supporting_employee_per_hour
#2011 data of (1)
costSupportingEmployeesQuantile2011 = quantile(costSupportingEmployeesList2011$cost_supporting_employee_per_hour,c(.25,.5,.75))
costSupportingEmployeesMean2011 = mean(costSupportingEmployeesList2011$cost_supporting_employee_per_hour)
#2012 data of (1)
costSupportingEmployeesQuantile2012 = quantile(costSupportingEmployeesList2012$cost_supporting_employee_per_hour,c(.25,.5,.75))
costSupportingEmployeesMean2012 = mean(costSupportingEmployeesList2012$cost_supporting_employee_per_hour)
#2013 data of (1)
costSupportingEmployeesQuantile2013 = quantile(costSupportingEmployeesList2013$cost_supporting_employee_per_hour,c(.25,.5,.75))
costSupportingEmployeesMean2013 = mean(costSupportingEmployeesList2013$cost_supporting_employee_per_hour)
#2014 data of (1)
costSupportingEmployeesQuantile2014 = quantile(costSupportingEmployeesList2014$cost_supporting_employee_per_hour,c(.25,.5,.75))
costSupportingEmployeesMean2014 = mean(costSupportingEmployeesList2014$cost_supporting_employee_per_hour)
#2015 data of (1)
costSupportingEmployeesQuantile2015 = quantile(costSupportingEmployeesList2015$cost_supporting_employee_per_hour,c(.25,.5,.75))
costSupportingEmployeesMean2015 = mean(costSupportingEmployeesList2015$cost_supporting_employee_per_hour)
#2016 data of (1)
costSupportingEmployeesQuantile2016 = quantile(costSupportingEmployeesList2016$cost_supporting_employee_per_hour,c(.25,.5,.75))
costSupportingEmployeesMean2016 = mean(costSupportingEmployeesList2016$cost_supporting_employee_per_hour)


#45 - Cost of Bargaining Unit Employees per Expended Man Hours of Bargaining Unit Employees
Cost.of.Bargaining.Unit.Employees.per.Expended.Man.Hours.of.Bargaining.Unit.Employees=comp$cost_bargaining_unit_employee_expended
#2011 data of (1)
costBargainingUnitEmployeeQuantile2011 = quantile(costBargainingUnitEmployeeList2011$cost_bargaining_unit_employee_expended,c(.25,.5,.75))
costBargainingUnitEmployeeMean2011 = mean(costBargainingUnitEmployeeList2011$cost_bargaining_unit_employee_expended)
#2012 data of (1)
costBargainingUnitEmployeeQuantile2012 = quantile(costBargainingUnitEmployeeList2012$cost_bargaining_unit_employee_expended,c(.25,.5,.75))
costBargainingUnitEmployeeMean2012 = mean(costBargainingUnitEmployeeList2012$cost_bargaining_unit_employee_expended)
#2013 data of (1)
costBargainingUnitEmployeeQuantile2013 = quantile(costBargainingUnitEmployeeList2013$cost_bargaining_unit_employee_expended,c(.25,.5,.75))
costBargainingUnitEmployeeMean2013 = mean(costBargainingUnitEmployeeList2013$cost_bargaining_unit_employee_expended)
#2014 data of (1)
costBargainingUnitEmployeeQuantile2014 = quantile(costBargainingUnitEmployeeList2014$cost_bargaining_unit_employee_expended,c(.25,.5,.75))
costBargainingUnitEmployeeMean2014 = mean(costBargainingUnitEmployeeList2014$cost_bargaining_unit_employee_expended)
#2015 data of (1)
costBargainingUnitEmployeeQuantile2015 = quantile(costBargainingUnitEmployeeList2015$cost_bargaining_unit_employee_expended,c(.25,.5,.75))
costBargainingUnitEmployeeMean2015 = mean(costBargainingUnitEmployeeList2015$cost_bargaining_unit_employee_expended)
#2016 data of (1)
costBargainingUnitEmployeeQuantile2016 = quantile(costBargainingUnitEmployeeList2016$cost_bargaining_unit_employee_expended,c(.25,.5,.75))
costBargainingUnitEmployeeMean2016 = mean(costBargainingUnitEmployeeList2016$cost_bargaining_unit_employee_expended)


#44 - Cost of Field Project Management Personnel per Hours of Field Project Management Personnel
Cost.of.Field.Project.Management.Personnel.per.Hours.of.Field.Project.Management.Personnel=comp$cost_field_project_management_personnel
#2011 data of (1)
costFieldProjManagementQuantile2011 = quantile(costFieldProjManagementList2011$cost_field_project_management_personnel,c(.25,.5,.75))
costFieldProjManagementMean2011 = mean(costFieldProjManagementList2011$cost_field_project_management_personnel)
#2012 data of (1)
costFieldProjManagementQuantile2012 = quantile(costFieldProjManagementList2012$cost_field_project_management_personnel,c(.25,.5,.75))
costFieldProjManagementMean2012 = mean(costFieldProjManagementList2012$cost_field_project_management_personnel)
#2013 data of (1)
costFieldProjManagementQuantile2013 = quantile(costFieldProjManagementList2013$cost_field_project_management_personnel,c(.25,.5,.75))
costFieldProjManagementMean2013 = mean(costFieldProjManagementList2013$cost_field_project_management_personnel)
#2014 data of (1)
costFieldProjManagementQuantile2014 = quantile(costFieldProjManagementList2014$cost_field_project_management_personnel,c(.25,.5,.75))
costFieldProjManagementMean2014 = mean(costFieldProjManagementList2014$cost_field_project_management_personnel)
#2015 data of (1)
costFieldProjManagementQuantile2015 = quantile(costFieldProjManagementList2015$cost_field_project_management_personnel,c(.25,.5,.75))
costFieldProjManagementMean2015 = mean(costFieldProjManagementList2015$cost_field_project_management_personnel)
#2016 data of (1)
costFieldProjManagementQuantile2016 = quantile(costFieldProjManagementList2016$cost_field_project_management_personnel,c(.25,.5,.75))
costFieldProjManagementMean2016 = mean(costFieldProjManagementList2016$cost_field_project_management_personnel)


#43 - Supporting Employees Cost Effectiveness: Dollar Net Profit / Cost of Supporting Employees
Net.Profit.per.Cost.of.Supporting.Employees=comp$supporting_employee_dollar_net_profit_cost
#2011 data of (1)
supportingEmployeeCostEffectDollarNetProfitQuantile2011 = quantile(supportingEmployeeCostEffectDollarNetProfitList2011$supporting_employee_dollar_net_profit_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarNetProfitMean2011 = mean(supportingEmployeeCostEffectDollarNetProfitList2011$supporting_employee_dollar_net_profit_cost)
#2012 data of (1)
supportingEmployeeCostEffectDollarNetProfitQuantile2012 = quantile(supportingEmployeeCostEffectDollarNetProfitList2012$supporting_employee_dollar_net_profit_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarNetProfitMean2012 = mean(supportingEmployeeCostEffectDollarNetProfitList2012$supporting_employee_dollar_net_profit_cost)
#2013 data of (1)
supportingEmployeeCostEffectDollarNetProfitQuantile2013 = quantile(supportingEmployeeCostEffectDollarNetProfitList2013$supporting_employee_dollar_net_profit_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarNetProfitMean2013 = mean(supportingEmployeeCostEffectDollarNetProfitList2013$supporting_employee_dollar_net_profit_cost)
#2014 data of (1)
supportingEmployeeCostEffectDollarNetProfitQuantile2014 = quantile(supportingEmployeeCostEffectDollarNetProfitList2014$supporting_employee_dollar_net_profit_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarNetProfitMean2014 = mean(supportingEmployeeCostEffectDollarNetProfitList2014$supporting_employee_dollar_net_profit_cost)
#2015 data of (1)
supportingEmployeeCostEffectDollarNetProfitQuantile2015 = quantile(supportingEmployeeCostEffectDollarNetProfitList2015$supporting_employee_dollar_net_profit_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarNetProfitMean2015 = mean(supportingEmployeeCostEffectDollarNetProfitList2015$supporting_employee_dollar_net_profit_cost)
#2016 data of (1)
supportingEmployeeCostEffectDollarNetProfitQuantile2016 = quantile(supportingEmployeeCostEffectDollarNetProfitList2016$supporting_employee_dollar_net_profit_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarNetProfitMean2016 = mean(supportingEmployeeCostEffectDollarNetProfitList2016$supporting_employee_dollar_net_profit_cost)


#42 - Supporting Employees Cost Effectiveness: Dollar Value Added/ Cost of Supporting Employees
Value.Added.per.Cost.of.Supporting.Employees=comp$supporting_employee_dollar_value_added_cost
#2011 data of (1)
supportingEmployeeCostEffectDollarValueAddedQuantile2011 = quantile(supportingEmployeeCostEffectDollarValueAddedList2011$supporting_employee_dollar_value_added_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarValueAddedMean2011 = mean(supportingEmployeeCostEffectDollarValueAddedList2011$supporting_employee_dollar_value_added_cost)
#2012 data of (1)
supportingEmployeeCostEffectDollarValueAddedQuantile2012 = quantile(supportingEmployeeCostEffectDollarValueAddedList2012$supporting_employee_dollar_value_added_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarValueAddedMean2012 = mean(supportingEmployeeCostEffectDollarValueAddedList2012$supporting_employee_dollar_value_added_cost)
#2013 data of (1)
supportingEmployeeCostEffectDollarValueAddedQuantile2013 = quantile(supportingEmployeeCostEffectDollarValueAddedList2013$supporting_employee_dollar_value_added_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarValueAddedMean2013 = mean(supportingEmployeeCostEffectDollarValueAddedList2013$supporting_employee_dollar_value_added_cost)
#2014 data of (1)
supportingEmployeeCostEffectDollarValueAddedQuantile2014 = quantile(supportingEmployeeCostEffectDollarValueAddedList2014$supporting_employee_dollar_value_added_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarValueAddedMean2014 = mean(supportingEmployeeCostEffectDollarValueAddedList2014$supporting_employee_dollar_value_added_cost)
#2015 data of (1)
supportingEmployeeCostEffectDollarValueAddedQuantile2015 = quantile(supportingEmployeeCostEffectDollarValueAddedList2015$supporting_employee_dollar_value_added_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarValueAddedMean2015 = mean(supportingEmployeeCostEffectDollarValueAddedList2015$supporting_employee_dollar_value_added_cost)
#2016 data of (1)
supportingEmployeeCostEffectDollarValueAddedQuantile2016 = quantile(supportingEmployeeCostEffectDollarValueAddedList2016$supporting_employee_dollar_value_added_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarValueAddedMean2016 = mean(supportingEmployeeCostEffectDollarValueAddedList2016$supporting_employee_dollar_value_added_cost)


#41 - Supporting Employees Cost Effectiveness: Dollar Revenue/ Cost of Supporting Employees 
Revenue.per.Cost.of.Supporting.Employees=comp$supporting_employee_dollar_revenue_cost
#2011 data of (1)
supportingEmployeeCostEffectDollarRevenueQuantile2011 = quantile(supportingEmployeeCostEffectDollarRevenueList2011$supporting_employee_dollar_revenue_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarRevenueMean2011 = mean(supportingEmployeeCostEffectDollarRevenueList2011$supporting_employee_dollar_revenue_cost)
#2012 data of (1)
supportingEmployeeCostEffectDollarRevenueQuantile2012 = quantile(supportingEmployeeCostEffectDollarRevenueList2012$supporting_employee_dollar_revenue_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarRevenueMean2012 = mean(supportingEmployeeCostEffectDollarRevenueList2012$supporting_employee_dollar_revenue_cost)
#2013 data of (1)
supportingEmployeeCostEffectDollarRevenueQuantile2013 = quantile(supportingEmployeeCostEffectDollarRevenueList2013$supporting_employee_dollar_revenue_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarRevenueMean2013 = mean(supportingEmployeeCostEffectDollarRevenueList2013$supporting_employee_dollar_revenue_cost)
#2014 data of (1)
supportingEmployeeCostEffectDollarRevenueQuantile2014 = quantile(supportingEmployeeCostEffectDollarRevenueList2014$supporting_employee_dollar_revenue_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarRevenueMean2014 = mean(supportingEmployeeCostEffectDollarRevenueList2014$supporting_employee_dollar_revenue_cost)
#2015 data of (1)
supportingEmployeeCostEffectDollarRevenueQuantile2015 = quantile(supportingEmployeeCostEffectDollarRevenueList2015$supporting_employee_dollar_revenue_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarRevenueMean2015 = mean(supportingEmployeeCostEffectDollarRevenueList2015$supporting_employee_dollar_revenue_cost)
#2016 data of (1)
supportingEmployeeCostEffectDollarRevenueQuantile2016 = quantile(supportingEmployeeCostEffectDollarRevenueList2016$supporting_employee_dollar_revenue_cost,c(.25,.5,.75))
supportingEmployeeCostEffectDollarRevenueMean2016 = mean(supportingEmployeeCostEffectDollarRevenueList2016$supporting_employee_dollar_revenue_cost)


#40 - Craft Worker Cost Effectiveness: Dollar Net Profit / Cost of Bargaining Unit Employees 
Net.Profit.per.Cost.of.Bargaining.Unit.Employees=comp$craft_worker_dollar_net_profit_cost
#2011 data of (1)
craftWorkerCostEffectDollarNetProfitQuantile2011 = quantile(craftWorkerCostEffectDollarNetProfitList2011$craft_worker_dollar_net_profit_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarNetProfitMean2011 = mean(craftWorkerCostEffectDollarNetProfitList2011$craft_worker_dollar_net_profit_cost)
#2012 data of (1)
craftWorkerCostEffectDollarNetProfitQuantile2012 = quantile(craftWorkerCostEffectDollarNetProfitList2012$craft_worker_dollar_net_profit_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarNetProfitMean2012 = mean(craftWorkerCostEffectDollarNetProfitList2012$craft_worker_dollar_net_profit_cost)
#2013 data of (1)
craftWorkerCostEffectDollarNetProfitQuantile2013 = quantile(craftWorkerCostEffectDollarNetProfitList2013$craft_worker_dollar_net_profit_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarNetProfitMean2013 = mean(craftWorkerCostEffectDollarNetProfitList2013$craft_worker_dollar_net_profit_cost)
#2014 data of (1)
craftWorkerCostEffectDollarNetProfitQuantile2014 = quantile(craftWorkerCostEffectDollarNetProfitList2014$craft_worker_dollar_net_profit_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarNetProfitMean2014 = mean(craftWorkerCostEffectDollarNetProfitList2014$craft_worker_dollar_net_profit_cost)
#2015 data of (1)
craftWorkerCostEffectDollarNetProfitQuantile2015 = quantile(craftWorkerCostEffectDollarNetProfitList2015$craft_worker_dollar_net_profit_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarNetProfitMean2015 = mean(craftWorkerCostEffectDollarNetProfitList2015$craft_worker_dollar_net_profit_cost)
#2016 data of (1)
craftWorkerCostEffectDollarNetProfitQuantile2016 = quantile(craftWorkerCostEffectDollarNetProfitList2016$craft_worker_dollar_net_profit_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarNetProfitMean2016 = mean(craftWorkerCostEffectDollarNetProfitList2016$craft_worker_dollar_net_profit_cost)


#39 - Craft Worker Cost Effectiveness: Dollar Value Added/ Cost of Bargaining Unit Employees
Value.Added.per.Cost.of.Bargaining.Unit.Employees=comp$craft_worker_dollar_value_added_cost
#2011 data of (1)
craftWorkerCostEffectDollarValueAddedQuantile2011 = quantile(craftWorkerCostEffectDollarValueAddedList2011$craft_worker_dollar_value_added_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarValueAddedMean2011 = mean(craftWorkerCostEffectDollarValueAddedList2011$craft_worker_dollar_value_added_cost)
#2012 data of (1)
craftWorkerCostEffectDollarValueAddedQuantile2012 = quantile(craftWorkerCostEffectDollarValueAddedList2012$craft_worker_dollar_value_added_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarValueAddedMean2012 = mean(craftWorkerCostEffectDollarValueAddedList2012$craft_worker_dollar_value_added_cost)
#2013 data of (1)
craftWorkerCostEffectDollarValueAddedQuantile2013 = quantile(craftWorkerCostEffectDollarValueAddedList2013$craft_worker_dollar_value_added_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarValueAddedMean2013 = mean(craftWorkerCostEffectDollarValueAddedList2013$craft_worker_dollar_value_added_cost)
#2014 data of (1)
craftWorkerCostEffectDollarValueAddedQuantile2014 = quantile(craftWorkerCostEffectDollarValueAddedList2014$craft_worker_dollar_value_added_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarValueAddedMean2014 = mean(craftWorkerCostEffectDollarValueAddedList2014$craft_worker_dollar_value_added_cost)
#2015 data of (1)
craftWorkerCostEffectDollarValueAddedQuantile2015 = quantile(craftWorkerCostEffectDollarValueAddedList2015$craft_worker_dollar_value_added_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarValueAddedMean2015 = mean(craftWorkerCostEffectDollarValueAddedList2015$craft_worker_dollar_value_added_cost)
#2016 data of (1)
craftWorkerCostEffectDollarValueAddedQuantile2016 = quantile(craftWorkerCostEffectDollarValueAddedList2016$craft_worker_dollar_value_added_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarValueAddedMean2016 = mean(craftWorkerCostEffectDollarValueAddedList2016$craft_worker_dollar_value_added_cost)


#38 - Craft Worker Cost Effectiveness: Dollar Revenue/ Cost of Bargaining Unit Employees 
Revenue.per.Cost.of.Bargaining.Unit.Employees=comp$craft_worker_dollar_revenue_cost
#2011 data of (1)
craftWorkerCostEffectDollarRevenueQuantile2011 = quantile(craftWorkerCostEffectDollarRevenueList2011$craft_worker_dollar_revenue_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarRevenueMean2011 = mean(craftWorkerCostEffectDollarRevenueList2011$craft_worker_dollar_revenue_cost)
#2012 data of (1)
craftWorkerCostEffectDollarRevenueQuantile2012 = quantile(craftWorkerCostEffectDollarRevenueList2012$craft_worker_dollar_revenue_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarRevenueMean2012 = mean(craftWorkerCostEffectDollarRevenueList2012$craft_worker_dollar_revenue_cost)
#2013 data of (1)
craftWorkerCostEffectDollarRevenueQuantile2013 = quantile(craftWorkerCostEffectDollarRevenueList2013$craft_worker_dollar_revenue_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarRevenueMean2013 = mean(craftWorkerCostEffectDollarRevenueList2013$craft_worker_dollar_revenue_cost)
#2014 data of (1)
craftWorkerCostEffectDollarRevenueQuantile2014 = quantile(craftWorkerCostEffectDollarRevenueList2014$craft_worker_dollar_revenue_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarRevenueMean2014 = mean(craftWorkerCostEffectDollarRevenueList2014$craft_worker_dollar_revenue_cost)
#2015 data of (1)
craftWorkerCostEffectDollarRevenueQuantile2015 = quantile(craftWorkerCostEffectDollarRevenueList2015$craft_worker_dollar_revenue_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarRevenueMean2015 = mean(craftWorkerCostEffectDollarRevenueList2015$craft_worker_dollar_revenue_cost)
#2016 data of (1)
craftWorkerCostEffectDollarRevenueQuantile2016 = quantile(craftWorkerCostEffectDollarRevenueList2016$craft_worker_dollar_revenue_cost,c(.25,.5,.75))
craftWorkerCostEffectDollarRevenueMean2016 = mean(craftWorkerCostEffectDollarRevenueList2016$craft_worker_dollar_revenue_cost)



#37 - Project Management Cost Effectiveness: Dollar Net Profit / Cost of Project Management Personnel
Net.Profit.per.Cost.of.Field.Project.Management.Personnel=comp$project_management_dollar_net_profit_cost
#2011 data of (1)
projectManagementCostDollarNetProfitQuantile2011 = quantile(projectManagementCostDollarNetProfitList2011$project_management_dollar_net_profit_cost,c(.25,.5,.75))
projectManagementCostDollarNetProfitMean2011 = mean(projectManagementCostDollarNetProfitList2011$project_management_dollar_net_profit_cost)
#2012 data of (1)
projectManagementCostDollarNetProfitQuantile2012 = quantile(projectManagementCostDollarNetProfitList2012$project_management_dollar_net_profit_cost,c(.25,.5,.75))
projectManagementCostDollarNetProfitMean2012 = mean(projectManagementCostDollarNetProfitList2012$project_management_dollar_net_profit_cost)
#2013 data of (1)
projectManagementCostDollarNetProfitQuantile2013 = quantile(projectManagementCostDollarNetProfitList2013$project_management_dollar_net_profit_cost,c(.25,.5,.75))
projectManagementCostDollarNetProfitMean2013 = mean(projectManagementCostDollarNetProfitList2013$project_management_dollar_net_profit_cost)
#2014 data of (1)
projectManagementCostDollarNetProfitQuantile2014 = quantile(projectManagementCostDollarNetProfitList2014$project_management_dollar_net_profit_cost,c(.25,.5,.75))
projectManagementCostDollarNetProfitMean2014 = mean(projectManagementCostDollarNetProfitList2014$project_management_dollar_net_profit_cost)
#2015 data of (1)
projectManagementCostDollarNetProfitQuantile2015 = quantile(projectManagementCostDollarNetProfitList2015$project_management_dollar_net_profit_cost,c(.25,.5,.75))
projectManagementCostDollarNetProfitMean2015 = mean(projectManagementCostDollarNetProfitList2015$project_management_dollar_net_profit_cost)
#2016 data of (1)
projectManagementCostDollarNetProfitQuantile2016 = quantile(projectManagementCostDollarNetProfitList2016$project_management_dollar_net_profit_cost,c(.25,.5,.75))
projectManagementCostDollarNetProfitMean2016 = mean(projectManagementCostDollarNetProfitList2016$project_management_dollar_net_profit_cost)


#36 - Project Management Cost Effectiveness: Dollar Value Added/ Cost of Project Management Personnel 
Value.Added.per.Cost.of.Field.Project.Management.Personnel=comp$project_management_dollar_value_added_cost
#2011 data of (1)
projectManagementCostDollarValueAddedQuantile2011 = quantile(projectManagementCostDollarValueAddedList2011$project_management_dollar_value_added_cost,c(.25,.5,.75))
projectManagementCostDollarValueAddedMean2011 = mean(projectManagementCostDollarValueAddedList2011$project_management_dollar_value_added_cost)
#2012 data of (1)
projectManagementCostDollarValueAddedQuantile2012 = quantile(projectManagementCostDollarValueAddedList2012$project_management_dollar_value_added_cost,c(.25,.5,.75))
projectManagementCostDollarValueAddedMean2012 = mean(projectManagementCostDollarValueAddedList2012$project_management_dollar_value_added_cost)
#2013 data of (1)
projectManagementCostDollarValueAddedQuantile2013 = quantile(projectManagementCostDollarValueAddedList2013$project_management_dollar_value_added_cost,c(.25,.5,.75))
projectManagementCostDollarValueAddedMean2013 = mean(projectManagementCostDollarValueAddedList2013$project_management_dollar_value_added_cost)
#2014 data of (1)
projectManagementCostDollarValueAddedQuantile2014 = quantile(projectManagementCostDollarValueAddedList2014$project_management_dollar_value_added_cost,c(.25,.5,.75))
projectManagementCostDollarValueAddedMean2014 = mean(projectManagementCostDollarValueAddedList2014$project_management_dollar_value_added_cost)
#2015 data of (1)
projectManagementCostDollarValueAddedQuantile2015 = quantile(projectManagementCostDollarValueAddedList2015$project_management_dollar_value_added_cost,c(.25,.5,.75))
projectManagementCostDollarValueAddedMean2015 = mean(projectManagementCostDollarValueAddedList2015$project_management_dollar_value_added_cost)
#2016 data of (1)
projectManagementCostDollarValueAddedQuantile2016 = quantile(projectManagementCostDollarValueAddedList2016$project_management_dollar_value_added_cost,c(.25,.5,.75))
projectManagementCostDollarValueAddedMean2016 = mean(projectManagementCostDollarValueAddedList2016$project_management_dollar_value_added_cost)


#35 - Project Management Cost Effectiveness: Dollar Revenue/ Cost of Project Management Personnel 
Revenue.per.Cost.of.Field.Project.Management.Personnel=comp$project_management_dollar_revenue_cost
#2011 data of (1)
projectManagementCostDollarRevenueQuantile2011 = quantile(projectManagementCostDollarRevenueList2011$project_management_dollar_revenue_cost,c(.25,.5,.75))
projectManagementCostDollarRevenueMean2011 = mean(projectManagementCostDollarRevenueList2011$project_management_dollar_revenue_cost)
#2012 data of (1)
projectManagementCostDollarRevenueQuantile2012 = quantile(projectManagementCostDollarRevenueList2012$project_management_dollar_revenue_cost,c(.25,.5,.75))
projectManagementCostDollarRevenueMean2012 = mean(projectManagementCostDollarRevenueList2012$project_management_dollar_revenue_cost)
#2013 data of (1)
projectManagementCostDollarRevenueQuantile2013 = quantile(projectManagementCostDollarRevenueList2013$project_management_dollar_revenue_cost,c(.25,.5,.75))
projectManagementCostDollarRevenueMean2013 = mean(projectManagementCostDollarRevenueList2013$project_management_dollar_revenue_cost)
#2014 data of (1)
projectManagementCostDollarRevenueQuantile2014 = quantile(projectManagementCostDollarRevenueList2014$project_management_dollar_revenue_cost,c(.25,.5,.75))
projectManagementCostDollarRevenueMean2014 = mean(projectManagementCostDollarRevenueList2014$project_management_dollar_revenue_cost)
#2015 data of (1)
projectManagementCostDollarRevenueQuantile2015 = quantile(projectManagementCostDollarRevenueList2015$project_management_dollar_revenue_cost,c(.25,.5,.75))
projectManagementCostDollarRevenueMean2015 = mean(projectManagementCostDollarRevenueList2015$project_management_dollar_revenue_cost)
#2016 data of (1)
projectManagementCostDollarRevenueQuantile2016 = quantile(projectManagementCostDollarRevenueList2016$project_management_dollar_revenue_cost,c(.25,.5,.75))
projectManagementCostDollarRevenueMean2016 = mean(projectManagementCostDollarRevenueList2016$project_management_dollar_revenue_cost)


#34 - Overall Cost Effectiveness – Dollar Net Profit / Cost of Company’s People 
Net.Profit.per.Total.Cost.of.People=comp$overall_cost_dollar_net_profit_cost
#2011 data of (1)
overallCostEffectivenessDollarNetProfitQuantile2011 = quantile(overallCostEffectivenessDollarNetProfitList2011$overall_cost_dollar_net_profit_cost,c(.25,.5,.75))
overallCostEffectivenessDollarNetProfitMean2011 = mean(overallCostEffectivenessDollarNetProfitList2011$overall_cost_dollar_net_profit_cost)
#2012 data of (1)
overallCostEffectivenessDollarNetProfitQuantile2012 = quantile(overallCostEffectivenessDollarNetProfitList2012$overall_cost_dollar_net_profit_cost,c(.25,.5,.75))
overallCostEffectivenessDollarNetProfitMean2012 = mean(overallCostEffectivenessDollarNetProfitList2012$overall_cost_dollar_net_profit_cost)
#2013 data of (1)
overallCostEffectivenessDollarNetProfitQuantile2013 = quantile(overallCostEffectivenessDollarNetProfitList2013$overall_cost_dollar_net_profit_cost,c(.25,.5,.75))
overallCostEffectivenessDollarNetProfitMean2013 = mean(overallCostEffectivenessDollarNetProfitList2013$overall_cost_dollar_net_profit_cost)
#2014 data of (1)
overallCostEffectivenessDollarNetProfitQuantile2014 = quantile(overallCostEffectivenessDollarNetProfitList2014$overall_cost_dollar_net_profit_cost,c(.25,.5,.75))
overallCostEffectivenessDollarNetProfitMean2014 = mean(overallCostEffectivenessDollarNetProfitList2014$overall_cost_dollar_net_profit_cost)
#2015 data of (1)
overallCostEffectivenessDollarNetProfitQuantile2015 = quantile(overallCostEffectivenessDollarNetProfitList2015$overall_cost_dollar_net_profit_cost,c(.25,.5,.75))
overallCostEffectivenessDollarNetProfitMean2015 = mean(overallCostEffectivenessDollarNetProfitList2015$overall_cost_dollar_net_profit_cost)
#2016 data of (1)
overallCostEffectivenessDollarNetProfitQuantile2016 = quantile(overallCostEffectivenessDollarNetProfitList2016$overall_cost_dollar_net_profit_cost,c(.25,.5,.75))
overallCostEffectivenessDollarNetProfitMean2016 = mean(overallCostEffectivenessDollarNetProfitList2016$overall_cost_dollar_net_profit_cost)


#33 - Overall Cost Effectiveness – Dollar Value Added/ Cost of Company’s People 
Value.Added.per.Total.Cost.of.People=comp$overall_cost_dollar_value_added_cost
#2011 data of (1)
overallCostEffectivenessDollarValueAddedQuantile2011 = quantile(overallCostEffectivenessDollarValueAddedList2011$overall_cost_dollar_value_added_cost,c(.25,.5,.75))
overallCostEffectivenessDollarValueAddedMean2011 = mean(overallCostEffectivenessDollarValueAddedList2011$overall_cost_dollar_value_added_cost)
#2012 data of (1)
overallCostEffectivenessDollarValueAddedQuantile2012 = quantile(overallCostEffectivenessDollarValueAddedList2012$overall_cost_dollar_value_added_cost,c(.25,.5,.75))
overallCostEffectivenessDollarValueAddedMean2012 = mean(overallCostEffectivenessDollarValueAddedList2012$overall_cost_dollar_value_added_cost)
#2013 data of (1)
overallCostEffectivenessDollarValueAddedQuantile2013 = quantile(overallCostEffectivenessDollarValueAddedList2013$overall_cost_dollar_value_added_cost,c(.25,.5,.75))
overallCostEffectivenessDollarValueAddedMean2013 = mean(overallCostEffectivenessDollarValueAddedList2013$overall_cost_dollar_value_added_cost)
#2014 data of (1)
overallCostEffectivenessDollarValueAddedQuantile2014 = quantile(overallCostEffectivenessDollarValueAddedList2014$overall_cost_dollar_value_added_cost,c(.25,.5,.75))
overallCostEffectivenessDollarValueAddedMean2014 = mean(overallCostEffectivenessDollarValueAddedList2014$overall_cost_dollar_value_added_cost)
#2015 data of (1)
overallCostEffectivenessDollarValueAddedQuantile2015 = quantile(overallCostEffectivenessDollarValueAddedList2015$overall_cost_dollar_value_added_cost,c(.25,.5,.75))
overallCostEffectivenessDollarValueAddedMean2015 = mean(overallCostEffectivenessDollarValueAddedList2015$overall_cost_dollar_value_added_cost)
#2016 data of (1)
overallCostEffectivenessDollarValueAddedQuantile2016 = quantile(overallCostEffectivenessDollarValueAddedList2016$overall_cost_dollar_value_added_cost,c(.25,.5,.75))
overallCostEffectivenessDollarValueAddedMean2016 = mean(overallCostEffectivenessDollarValueAddedList2016$overall_cost_dollar_value_added_cost)


#32 - Overall Cost Effectiveness – Dollar Revenue/Cost of Company’s People 
Revenue.per.Total.Cost.of.People=comp$overall_cost_dollar_revenue_cost
#2011 data of (1)
overallCostEffectivenessDollarRevenueQuantile2011 = quantile(overallCostEffectivenessDollarRevenueList2011$overall_cost_dollar_revenue_cost,c(.25,.5,.75))
overallCostEffectivenessDollarRevenueMean2011 = mean(overallCostEffectivenessDollarRevenueList2011$overall_cost_dollar_revenue_cost)
#2012 data of (1)
overallCostEffectivenessDollarRevenueQuantile2012 = quantile(overallCostEffectivenessDollarRevenueList2012$overall_cost_dollar_revenue_cost,c(.25,.5,.75))
overallCostEffectivenessDollarRevenueMean2012 = mean(overallCostEffectivenessDollarRevenueList2012$overall_cost_dollar_revenue_cost)
#2013 data of (1)
overallCostEffectivenessDollarRevenueQuantile2013 = quantile(overallCostEffectivenessDollarRevenueList2013$overall_cost_dollar_revenue_cost,c(.25,.5,.75))
overallCostEffectivenessDollarRevenueMean2013 = mean(overallCostEffectivenessDollarRevenueList2013$overall_cost_dollar_revenue_cost)
#2014 data of (1)
overallCostEffectivenessDollarRevenueQuantile2014 = quantile(overallCostEffectivenessDollarRevenueList2014$overall_cost_dollar_revenue_cost,c(.25,.5,.75))
overallCostEffectivenessDollarRevenueMean2014 = mean(overallCostEffectivenessDollarRevenueList2014$overall_cost_dollar_revenue_cost)
#2015 data of (1)
overallCostEffectivenessDollarRevenueQuantile2015 = quantile(overallCostEffectivenessDollarRevenueList2015$overall_cost_dollar_revenue_cost,c(.25,.5,.75))
overallCostEffectivenessDollarRevenueMean2015 = mean(overallCostEffectivenessDollarRevenueList2015$overall_cost_dollar_revenue_cost)
#2016 data of (1)
overallCostEffectivenessDollarRevenueQuantile2016 = quantile(overallCostEffectivenessDollarRevenueList2016$overall_cost_dollar_revenue_cost,c(.25,.5,.75))
overallCostEffectivenessDollarRevenueMean2016 = mean(overallCostEffectivenessDollarRevenueList2016$overall_cost_dollar_revenue_cost)


#31 - Supporting Employees Profitability Measurement: Dollar Net Profit / FTEs of Supporting Employees
Net.Profit.per.FTE.of.Supporting.Employees=comp$supporting_employee_dollar_net_profit_added_fte
#2011 data of (1)
supportingEmployeeDollarNetProfitFteQuantile2011 = quantile(supportingEmployeeDollarNetProfitFteList2011$supporting_employee_dollar_net_profit_added_fte,c(.25,.5,.75))
supportingEmployeeDollarNetProfitFteMean2011 = mean(supportingEmployeeDollarNetProfitFteList2011$supporting_employee_dollar_net_profit_added_fte)
#2012 data of (1)
supportingEmployeeDollarNetProfitFteQuantile2012 = quantile(supportingEmployeeDollarNetProfitFteList2012$supporting_employee_dollar_net_profit_added_fte,c(.25,.5,.75))
supportingEmployeeDollarNetProfitFteMean2012 = mean(supportingEmployeeDollarNetProfitFteList2012$supporting_employee_dollar_net_profit_added_fte)
#2013 data of (1)
supportingEmployeeDollarNetProfitFteQuantile2013 = quantile(supportingEmployeeDollarNetProfitFteList2013$supporting_employee_dollar_net_profit_added_fte,c(.25,.5,.75))
supportingEmployeeDollarNetProfitFteMean2013 = mean(supportingEmployeeDollarNetProfitFteList2013$supporting_employee_dollar_net_profit_added_fte)
#2014 data of (1)
supportingEmployeeDollarNetProfitFteQuantile2014 = quantile(supportingEmployeeDollarNetProfitFteList2014$supporting_employee_dollar_net_profit_added_fte,c(.25,.5,.75))
supportingEmployeeDollarNetProfitFteMean2014 = mean(supportingEmployeeDollarNetProfitFteList2014$supporting_employee_dollar_net_profit_added_fte)
#2015 data of (1)
supportingEmployeeDollarNetProfitFteQuantile2015 = quantile(supportingEmployeeDollarNetProfitFteList2015$supporting_employee_dollar_net_profit_added_fte,c(.25,.5,.75))
supportingEmployeeDollarNetProfitFteMean2015 = mean(supportingEmployeeDollarNetProfitFteList2015$supporting_employee_dollar_net_profit_added_fte)
#2016 data of (1)
supportingEmployeeDollarNetProfitFteQuantile2016 = quantile(supportingEmployeeDollarNetProfitFteList2016$supporting_employee_dollar_net_profit_added_fte,c(.25,.5,.75))
supportingEmployeeDollarNetProfitFteMean2016 = mean(supportingEmployeeDollarNetProfitFteList2016$supporting_employee_dollar_net_profit_added_fte)


#30 - Supporting Employees Productivity Measurement: Dollar Value Added/ FTEs of Supporting Employees
Value.Added.per.FTE.of.Supporting.Employees=comp$supporting_employee_dollar_value_added_fte
#2011 data of (1)
supportingEmployeeDollarValueAddedFteQuantile2011 = quantile(supportingEmployeeDollarValueAddedFteList2011$supporting_employee_dollar_value_added_fte,c(.25,.5,.75))
supportingEmployeeDollarValueAddedFteMean2011 = mean(supportingEmployeeDollarValueAddedFteList2011$supporting_employee_dollar_value_added_fte)
#2012 data of (1)
supportingEmployeeDollarValueAddedFteQuantile2012 = quantile(supportingEmployeeDollarValueAddedFteList2012$supporting_employee_dollar_value_added_fte,c(.25,.5,.75))
supportingEmployeeDollarValueAddedFteMean2012 = mean(supportingEmployeeDollarValueAddedFteList2012$supporting_employee_dollar_value_added_fte)
#2013 data of (1)
supportingEmployeeDollarValueAddedFteQuantile2013 = quantile(supportingEmployeeDollarValueAddedFteList2013$supporting_employee_dollar_value_added_fte,c(.25,.5,.75))
supportingEmployeeDollarValueAddedFteMean2013 = mean(supportingEmployeeDollarValueAddedFteList2013$supporting_employee_dollar_value_added_fte)
#2014 data of (1)
supportingEmployeeDollarValueAddedFteQuantile2014 = quantile(supportingEmployeeDollarValueAddedFteList2014$supporting_employee_dollar_value_added_fte,c(.25,.5,.75))
supportingEmployeeDollarValueAddedFteMean2014 = mean(supportingEmployeeDollarValueAddedFteList2014$supporting_employee_dollar_value_added_fte)
#2015 data of (1)
supportingEmployeeDollarValueAddedFteQuantile2015 = quantile(supportingEmployeeDollarValueAddedFteList2015$supporting_employee_dollar_value_added_fte,c(.25,.5,.75))
supportingEmployeeDollarValueAddedFteMean2015 = mean(supportingEmployeeDollarValueAddedFteList2015$supporting_employee_dollar_value_added_fte)
#2016 data of (1)
supportingEmployeeDollarValueAddedFteQuantile2016 = quantile(supportingEmployeeDollarValueAddedFteList2016$supporting_employee_dollar_value_added_fte,c(.25,.5,.75))
supportingEmployeeDollarValueAddedFteMean2016 = mean(supportingEmployeeDollarValueAddedFteList2016$supporting_employee_dollar_value_added_fte)


#29 - Supporting Employees Productivity Measurement: Dollar Revenue/ FTEs of Supporting Employees 
Revenue.per.FTE.of.Supporting.Employees=comp$supporting_employee_dollar_revenue_fte
#2011 data of (1)
supportingEmployeeDollarRevenueFteQuantile2011 = quantile(supportingEmployeeDollarRevenueFteList2011$supporting_employee_dollar_revenue_fte,c(.25,.5,.75))
supportingEmployeeDollarRevenueFteMean2011 = mean(supportingEmployeeDollarRevenueFteList2011$supporting_employee_dollar_revenue_fte)
#2012 data of (1)
supportingEmployeeDollarRevenueFteQuantile2012 = quantile(supportingEmployeeDollarRevenueFteList2012$supporting_employee_dollar_revenue_fte,c(.25,.5,.75))
supportingEmployeeDollarRevenueFteMean2012 = mean(supportingEmployeeDollarRevenueFteList2012$supporting_employee_dollar_revenue_fte)
#2013 data of (1)
supportingEmployeeDollarRevenueFteQuantile2013 = quantile(supportingEmployeeDollarRevenueFteList2013$supporting_employee_dollar_revenue_fte,c(.25,.5,.75))
supportingEmployeeDollarRevenueFteMean2013 = mean(supportingEmployeeDollarRevenueFteList2013$supporting_employee_dollar_revenue_fte)
#2014 data of (1)
supportingEmployeeDollarRevenueFteQuantile2014 = quantile(supportingEmployeeDollarRevenueFteList2014$supporting_employee_dollar_revenue_fte,c(.25,.5,.75))
supportingEmployeeDollarRevenueFteMean2014 = mean(supportingEmployeeDollarRevenueFteList2014$supporting_employee_dollar_revenue_fte)
#2015 data of (1)
supportingEmployeeDollarRevenueFteQuantile2015 = quantile(supportingEmployeeDollarRevenueFteList2015$supporting_employee_dollar_revenue_fte,c(.25,.5,.75))
supportingEmployeeDollarRevenueFteMean2015 = mean(supportingEmployeeDollarRevenueFteList2015$supporting_employee_dollar_revenue_fte)
#2016 data of (1)
supportingEmployeeDollarRevenueFteQuantile2016 = quantile(supportingEmployeeDollarRevenueFteList2016$supporting_employee_dollar_revenue_fte,c(.25,.5,.75))
supportingEmployeeDollarRevenueFteMean2016 = mean(supportingEmployeeDollarRevenueFteList2016$supporting_employee_dollar_revenue_fte)


#28 - Craft Worker Profitability Measurement: Dollar Net Profit / FTEs of Bargaining Unit Employees 
Net.Profit.per.Expended.Man.FTE.of.Bargaining.Unit.Employees=comp$craft_worker_dollar_net_profit_fte
#2011 data of (1)
craftWorkerDollarNetProfitFteQuantile2011 = quantile(craftWorkerDollarNetProfitFteList2011$craft_worker_dollar_net_profit_fte,c(.25,.5,.75))
craftWorkerDollarNetProfitFteMean2011 = mean(craftWorkerDollarNetProfitFteList2011$craft_worker_dollar_net_profit_fte)
#2012 data of (1)
craftWorkerDollarNetProfitFteQuantile2012 = quantile(craftWorkerDollarNetProfitFteList2012$craft_worker_dollar_net_profit_fte,c(.25,.5,.75))
craftWorkerDollarNetProfitFteMean2012 = mean(craftWorkerDollarNetProfitFteList2012$craft_worker_dollar_net_profit_fte)
#2013 data of (1)
craftWorkerDollarNetProfitFteQuantile2013 = quantile(craftWorkerDollarNetProfitFteList2013$craft_worker_dollar_net_profit_fte,c(.25,.5,.75))
craftWorkerDollarNetProfitFteMean2013 = mean(craftWorkerDollarNetProfitFteList2013$craft_worker_dollar_net_profit_fte)
#2014 data of (1)
craftWorkerDollarNetProfitFteQuantile2014 = quantile(craftWorkerDollarNetProfitFteList2014$craft_worker_dollar_net_profit_fte,c(.25,.5,.75))
craftWorkerDollarNetProfitFteMean2014 = mean(craftWorkerDollarNetProfitFteList2014$craft_worker_dollar_net_profit_fte)
#2015 data of (1)
craftWorkerDollarNetProfitFteQuantile2015 = quantile(craftWorkerDollarNetProfitFteList2015$craft_worker_dollar_net_profit_fte,c(.25,.5,.75))
craftWorkerDollarNetProfitFteMean2015 = mean(craftWorkerDollarNetProfitFteList2015$craft_worker_dollar_net_profit_fte)
#2016 data of (1)
craftWorkerDollarNetProfitFteQuantile2016 = quantile(craftWorkerDollarNetProfitFteList2016$craft_worker_dollar_net_profit_fte,c(.25,.5,.75))
craftWorkerDollarNetProfitFteMean2016 = mean(craftWorkerDollarNetProfitFteList2016$craft_worker_dollar_net_profit_fte)


#27 - Craft Worker Productivity Measurement: Dollar Value Added/ FTEs of Bargaining Unit 
Value.Added.per.Expended.Man.FTE.of.Bargaining.Unit.Employees=comp$craft_worker_dollar_value_added_fte
#2011 data of (1)
craftWorkerDollarValueAddedFteQuantile2011 = quantile(craftWorkerDollarValueAddedFteList2011$craft_worker_dollar_value_added_fte,c(.25,.5,.75))
craftWorkerDollarValueAddedFteMean2011 = mean(craftWorkerDollarValueAddedFteList2011$craft_worker_dollar_value_added_fte)
#2012 data of (1)
craftWorkerDollarValueAddedFteQuantile2012 = quantile(craftWorkerDollarValueAddedFteList2012$craft_worker_dollar_value_added_fte,c(.25,.5,.75))
craftWorkerDollarValueAddedFteMean2012 = mean(craftWorkerDollarValueAddedFteList2012$craft_worker_dollar_value_added_fte)
#2013 data of (1)
craftWorkerDollarValueAddedFteQuantile2013 = quantile(craftWorkerDollarValueAddedFteList2013$craft_worker_dollar_value_added_fte,c(.25,.5,.75))
craftWorkerDollarValueAddedFteMean2013 = mean(craftWorkerDollarValueAddedFteList2013$craft_worker_dollar_value_added_fte)
#2014 data of (1)
craftWorkerDollarValueAddedFteQuantile2014 = quantile(craftWorkerDollarValueAddedFteList2014$craft_worker_dollar_value_added_fte,c(.25,.5,.75))
craftWorkerDollarValueAddedFteMean2014 = mean(craftWorkerDollarValueAddedFteList2014$craft_worker_dollar_value_added_fte)
#2015 data of (1)
craftWorkerDollarValueAddedFteQuantile2015 = quantile(craftWorkerDollarValueAddedFteList2015$craft_worker_dollar_value_added_fte,c(.25,.5,.75))
craftWorkerDollarValueAddedFteMean2015 = mean(craftWorkerDollarValueAddedFteList2015$craft_worker_dollar_value_added_fte)
#2016 data of (1)
craftWorkerDollarValueAddedFteQuantile2016 = quantile(craftWorkerDollarValueAddedFteList2016$craft_worker_dollar_value_added_fte,c(.25,.5,.75))
craftWorkerDollarValueAddedFteMean2016 = mean(craftWorkerDollarValueAddedFteList2016$craft_worker_dollar_value_added_fte)



#26 - Craft Worker Productivity Measurement: Dollar Revenue/ FTEs of Bargaining Unit Employees 
Revenue.per.Expended.Man.FTE.of.Bargaining.Unit.Employees=comp$craft_worker_dollar_revenue_fte
#2011 data of (1)
craftWorkerDollarRevenueFteQuantile2011 = quantile(craftWorkerDollarRevenueFteList2011$craft_worker_dollar_revenue_fte,c(.25,.5,.75))
craftWorkerDollarRevenueFteMean2011 = mean(craftWorkerDollarRevenueFteList2011$craft_worker_dollar_revenue_fte)
#2012 data of (1)
craftWorkerDollarRevenueFteQuantile2012 = quantile(craftWorkerDollarRevenueFteList2012$craft_worker_dollar_revenue_fte,c(.25,.5,.75))
craftWorkerDollarRevenueFteMean2012 = mean(craftWorkerDollarRevenueFteList2012$craft_worker_dollar_revenue_fte)
#2013 data of (1)
craftWorkerDollarRevenueFteQuantile2013 = quantile(craftWorkerDollarRevenueFteList2013$craft_worker_dollar_revenue_fte,c(.25,.5,.75))
craftWorkerDollarRevenueFteMean2013 = mean(craftWorkerDollarRevenueFteList2013$craft_worker_dollar_revenue_fte)
#2014 data of (1)
craftWorkerDollarRevenueFteQuantile2014 = quantile(craftWorkerDollarRevenueFteList2014$craft_worker_dollar_revenue_fte,c(.25,.5,.75))
craftWorkerDollarRevenueFteMean2014 = mean(craftWorkerDollarRevenueFteList2014$craft_worker_dollar_revenue_fte)
#2015 data of (1)
craftWorkerDollarRevenueFteQuantile2015 = quantile(craftWorkerDollarRevenueFteList2015$craft_worker_dollar_revenue_fte,c(.25,.5,.75))
craftWorkerDollarRevenueFteMean2015 = mean(craftWorkerDollarRevenueFteList2015$craft_worker_dollar_revenue_fte)
#2016 data of (1)
craftWorkerDollarRevenueFteQuantile2016 = quantile(craftWorkerDollarRevenueFteList2016$craft_worker_dollar_revenue_fte,c(.25,.5,.75))
craftWorkerDollarRevenueFteMean2016 = mean(craftWorkerDollarRevenueFteList2016$craft_worker_dollar_revenue_fte)


#25 - Project Management Profitability Measurement: Dollar Net Profit /FTEs of Project Management Personnel 
Net.Profit.per.Hour.of.Field.Project.Management.Personnel=comp$project_management_dollar_net_profit_fte
#2011 data of (1)
projectManagementDollarNetProfitPersonnelFteQuantile2011 = quantile(projectManagementDollarNetProfitPersonnelFteList2011$project_management_dollar_net_profit_fte,c(.25,.5,.75))
projectManagementDollarNetProfitPersonnelFteMean2011 = mean(projectManagementDollarNetProfitPersonnelFteList2011$project_management_dollar_net_profit_fte)
#2012 data of (1)
projectManagementDollarNetProfitPersonnelFteQuantile2012 = quantile(projectManagementDollarNetProfitPersonnelFteList2012$project_management_dollar_net_profit_fte,c(.25,.5,.75))
projectManagementDollarNetProfitPersonnelFteMean2012 = mean(projectManagementDollarNetProfitPersonnelFteList2012$project_management_dollar_net_profit_fte)
#2013 data of (1)
projectManagementDollarNetProfitPersonnelFteQuantile2013 = quantile(projectManagementDollarNetProfitPersonnelFteList2013$project_management_dollar_net_profit_fte,c(.25,.5,.75))
projectManagementDollarNetProfitPersonnelFteMean2013 = mean(projectManagementDollarNetProfitPersonnelFteList2013$project_management_dollar_net_profit_fte)
#2014 data of (1)
projectManagementDollarNetProfitPersonnelFteQuantile2014 = quantile(projectManagementDollarNetProfitPersonnelFteList2014$project_management_dollar_net_profit_fte,c(.25,.5,.75))
projectManagementDollarNetProfitPersonnelFteMean2014 = mean(projectManagementDollarNetProfitPersonnelFteList2014$project_management_dollar_net_profit_fte)
#2015 data of (1)
projectManagementDollarNetProfitPersonnelFteQuantile2015 = quantile(projectManagementDollarNetProfitPersonnelFteList2015$project_management_dollar_net_profit_fte,c(.25,.5,.75))
projectManagementDollarNetProfitPersonnelFteMean2015 = mean(projectManagementDollarNetProfitPersonnelFteList2015$project_management_dollar_net_profit_fte)
#2016 data of (1)
projectManagementDollarNetProfitPersonnelFteQuantile2016 = quantile(projectManagementDollarNetProfitPersonnelFteList2016$project_management_dollar_net_profit_fte,c(.25,.5,.75))
projectManagementDollarNetProfitPersonnelFteMean2016 = mean(projectManagementDollarNetProfitPersonnelFteList2016$project_management_dollar_net_profit_fte)



#24 - Project Management Productivity Measurement: Dollar Value Added/FTEs of Project Management 
Value.Added.per.Hour.of.Field.Project.Management.Personnel=comp$project_management_dollar_value_added_fte
#2011 data of (1)
projectManagementDollarValueAddedPersonnelFteQuantile2011 = quantile(projectManagementDollarValueAddedPersonnelFteList2011$project_management_dollar_value_added_fte,c(.25,.5,.75))
projectManagementDollarValueAddedPersonnelFteMean2011 = mean(projectManagementDollarValueAddedPersonnelFteList2011$project_management_dollar_value_added_fte)
#2012 data of (1)
projectManagementDollarValueAddedPersonnelFteQuantile2012 = quantile(projectManagementDollarValueAddedPersonnelFteList2012$project_management_dollar_value_added_fte,c(.25,.5,.75))
projectManagementDollarValueAddedPersonnelFteMean2012 = mean(projectManagementDollarValueAddedPersonnelFteList2012$project_management_dollar_value_added_fte)
#2013 data of (1)
projectManagementDollarValueAddedPersonnelFteQuantile2013 = quantile(projectManagementDollarValueAddedPersonnelFteList2013$project_management_dollar_value_added_fte,c(.25,.5,.75))
projectManagementDollarValueAddedPersonnelFteMean2013 = mean(projectManagementDollarValueAddedPersonnelFteList2013$project_management_dollar_value_added_fte)
#2014 data of (1)
projectManagementDollarValueAddedPersonnelFteQuantile2014 = quantile(projectManagementDollarValueAddedPersonnelFteList2014$project_management_dollar_value_added_fte,c(.25,.5,.75))
projectManagementDollarValueAddedPersonnelFteMean2014 = mean(projectManagementDollarValueAddedPersonnelFteList2014$project_management_dollar_value_added_fte)
#2015 data of (1)
projectManagementDollarValueAddedPersonnelFteQuantile2015 = quantile(projectManagementDollarValueAddedPersonnelFteList2015$project_management_dollar_value_added_fte,c(.25,.5,.75))
projectManagementDollarValueAddedPersonnelFteMean2015 = mean(projectManagementDollarValueAddedPersonnelFteList2015$project_management_dollar_value_added_fte)
#2016 data of (1)
projectManagementDollarValueAddedPersonnelFteQuantile2016 = quantile(projectManagementDollarValueAddedPersonnelFteList2016$project_management_dollar_value_added_fte,c(.25,.5,.75))
projectManagementDollarValueAddedPersonnelFteMean2016 = mean(projectManagementDollarValueAddedPersonnelFteList2016$project_management_dollar_value_added_fte)


#23 - Project Management Productivity Measurement: Dollar Revenue/FTEs of Project Management Personnel 
Revenue.per.Hour.of.Field.Project.Management.Personnel=comp$project_management_dollar_revenue_fte
#2011 data of (1)
projectManagementDollarRevenuePersonnelFteQuantile2011 = quantile(projectManagementDollarRevenuePersonnelFteList2011$project_management_dollar_revenue_fte,c(.25,.5,.75))
projectManagementDollarRevenuePersonnelFteMean2011 = mean(projectManagementDollarRevenuePersonnelFteList2011$project_management_dollar_revenue_fte)
#2012 data of (1)
projectManagementDollarRevenuePersonnelFteQuantile2012 = quantile(projectManagementDollarRevenuePersonnelFteList2012$project_management_dollar_revenue_fte,c(.25,.5,.75))
projectManagementDollarRevenuePersonnelFteMean2012 = mean(projectManagementDollarRevenuePersonnelFteList2012$project_management_dollar_revenue_fte)
#2013 data of (1)
projectManagementDollarRevenuePersonnelFteQuantile2013 = quantile(projectManagementDollarRevenuePersonnelFteList2013$project_management_dollar_revenue_fte,c(.25,.5,.75))
projectManagementDollarRevenuePersonnelFteMean2013 = mean(projectManagementDollarRevenuePersonnelFteList2013$project_management_dollar_revenue_fte)
#2014 data of (1)
projectManagementDollarRevenuePersonnelFteQuantile2014 = quantile(projectManagementDollarRevenuePersonnelFteList2014$project_management_dollar_revenue_fte,c(.25,.5,.75))
projectManagementDollarRevenuePersonnelFteMean2014 = mean(projectManagementDollarRevenuePersonnelFteList2014$project_management_dollar_revenue_fte)
#2015 data of (1)
projectManagementDollarRevenuePersonnelFteQuantile2015 = quantile(projectManagementDollarRevenuePersonnelFteList2015$project_management_dollar_revenue_fte,c(.25,.5,.75))
projectManagementDollarRevenuePersonnelFteMean2015 = mean(projectManagementDollarRevenuePersonnelFteList2015$project_management_dollar_revenue_fte)
#2016 data of (1)
projectManagementDollarRevenuePersonnelFteQuantile2016 = quantile(projectManagementDollarRevenuePersonnelFteList2016$project_management_dollar_revenue_fte,c(.25,.5,.75))
projectManagementDollarRevenuePersonnelFteMean2016 = mean(projectManagementDollarRevenuePersonnelFteList2016$project_management_dollar_revenue_fte)


#22 - Overall Profitability Measurement – Dollar Net Profit /FTEs of  Company’s People
Net.Profit.per.Total.FTE.of.People=comp$overall_productivity_dollar_net_profit_fte
#2011 data of (1)
overallProductivityDollarNetProfitFteQuantile2011 = quantile(overallProductivityDollarNetProfitFteList2011$overall_productivity_dollar_net_profit_fte,c(.25,.5,.75))
overallProductivityDollarNetProfitFteMean2011 = mean(overallProductivityDollarNetProfitFteList2011$overall_productivity_dollar_net_profit_fte)
#2012 data of (1)
overallProductivityDollarNetProfitFteQuantile2012 = quantile(overallProductivityDollarNetProfitFteList2012$overall_productivity_dollar_net_profit_fte,c(.25,.5,.75))
overallProductivityDollarNetProfitFteMean2012 = mean(overallProductivityDollarNetProfitFteList2012$overall_productivity_dollar_net_profit_fte)
#2013 data of (1)
overallProductivityDollarNetProfitFteQuantile2013 = quantile(overallProductivityDollarNetProfitFteList2013$overall_productivity_dollar_net_profit_fte,c(.25,.5,.75))
overallProductivityDollarNetProfitFteMean2013 = mean(overallProductivityDollarNetProfitFteList2013$overall_productivity_dollar_net_profit_fte)
#2014 data of (1)
overallProductivityDollarNetProfitFteQuantile2014 = quantile(overallProductivityDollarNetProfitFteList2014$overall_productivity_dollar_net_profit_fte,c(.25,.5,.75))
overallProductivityDollarNetProfitFteMean2014 = mean(overallProductivityDollarNetProfitFteList2014$overall_productivity_dollar_net_profit_fte)
#2015 data of (1)
overallProductivityDollarNetProfitFteQuantile2015 = quantile(overallProductivityDollarNetProfitFteList2015$overall_productivity_dollar_net_profit_fte,c(.25,.5,.75))
overallProductivityDollarNetProfitFteMean2015 = mean(overallProductivityDollarNetProfitFteList2015$overall_productivity_dollar_net_profit_fte)
#2016 data of (1)
overallProductivityDollarNetProfitFteQuantile2016 = quantile(overallProductivityDollarNetProfitFteList2016$overall_productivity_dollar_net_profit_fte,c(.25,.5,.75))
overallProductivityDollarNetProfitFteMean2016 = mean(overallProductivityDollarNetProfitFteList2016$overall_productivity_dollar_net_profit_fte)



#21 Overall Productivity Measurement – Dollar Value Added/FTEs of Company’s People 
Value.Added.per.Total.FTE.of.People=comp$overall_productivity_dollar_value_added_fte
#2011 data of (1)
overallProductivityDollarValueAddedFteQuantile2011 = quantile(overallProductivityDollarValueAddedFteList2011$overall_productivity_dollar_value_added_fte,c(.25,.5,.75))
overallProductivityDollarValueAddedFteMean2011 = mean(overallProductivityDollarValueAddedFteList2011$overall_productivity_dollar_value_added_fte)
#2012 data of (1)
overallProductivityDollarValueAddedFteQuantile2012 = quantile(overallProductivityDollarValueAddedFteList2012$overall_productivity_dollar_value_added_fte,c(.25,.5,.75))
overallProductivityDollarValueAddedFteMean2012 = mean(overallProductivityDollarValueAddedFteList2012$overall_productivity_dollar_value_added_fte)
#2013 data of (1)
overallProductivityDollarValueAddedFteQuantile2013 = quantile(overallProductivityDollarValueAddedFteList2013$overall_productivity_dollar_value_added_fte,c(.25,.5,.75))
overallProductivityDollarValueAddedFteMean2013 = mean(overallProductivityDollarValueAddedFteList2013$overall_productivity_dollar_value_added_fte)
#2014 data of (1)
overallProductivityDollarValueAddedFteQuantile2014 = quantile(overallProductivityDollarValueAddedFteList2014$overall_productivity_dollar_value_added_fte,c(.25,.5,.75))
overallProductivityDollarValueAddedFteMean2014 = mean(overallProductivityDollarValueAddedFteList2014$overall_productivity_dollar_value_added_fte)
#2015 data of (1)
overallProductivityDollarValueAddedFteQuantile2015 = quantile(overallProductivityDollarValueAddedFteList2015$overall_productivity_dollar_value_added_fte,c(.25,.5,.75))
overallProductivityDollarValueAddedFteMean2015 = mean(overallProductivityDollarValueAddedFteList2015$overall_productivity_dollar_value_added_fte)
#2016 data of (1)
overallProductivityDollarValueAddedFteQuantile2016 = quantile(overallProductivityDollarValueAddedFteList2016$overall_productivity_dollar_value_added_fte,c(.25,.5,.75))
overallProductivityDollarValueAddedFteMean2016 = mean(overallProductivityDollarValueAddedFteList2016$overall_productivity_dollar_value_added_fte)


#20 Overall Productivity Measurement – Dollar Revenue/FTEs of Company’s People
Revenue.per.Total.FTE.of.People=comp$overall_productivity_dollar_revenue_fte
#2011 data of (1)
overallProductivityDollarRevenueFteQuantile2011 = quantile(overallProductivityDollarRevenueFteList2011$overall_productivity_dollar_revenue_fte,c(.25,.5,.75))
overallProductivityDollarRevenueFteMean2011 = mean(overallProductivityDollarRevenueFteList2011$overall_productivity_dollar_revenue_fte)
#2012 data of (1)
overallProductivityDollarRevenueFteQuantile2012 = quantile(overallProductivityDollarRevenueFteList2012$overall_productivity_dollar_revenue_fte,c(.25,.5,.75))
overallProductivityDollarRevenueFteMean2012 = mean(overallProductivityDollarRevenueFteList2012$overall_productivity_dollar_revenue_fte)
#2013 data of (1)
overallProductivityDollarRevenueFteQuantile2013 = quantile(overallProductivityDollarRevenueFteList2013$overall_productivity_dollar_revenue_fte,c(.25,.5,.75))
overallProductivityDollarRevenueFteMean2013 = mean(overallProductivityDollarRevenueFteList2013$overall_productivity_dollar_revenue_fte)
#2014 data of (1)
overallProductivityDollarRevenueFteQuantile2014 = quantile(overallProductivityDollarRevenueFteList2014$overall_productivity_dollar_revenue_fte,c(.25,.5,.75))
overallProductivityDollarRevenueFteMean2014 = mean(overallProductivityDollarRevenueFteList2014$overall_productivity_dollar_revenue_fte)
#2015 data of (1)
overallProductivityDollarRevenueFteQuantile2015 = quantile(overallProductivityDollarRevenueFteList2015$overall_productivity_dollar_revenue_fte,c(.25,.5,.75))
overallProductivityDollarRevenueFteMean2015 = mean(overallProductivityDollarRevenueFteList2015$overall_productivity_dollar_revenue_fte)
#2016 data of (1)
overallProductivityDollarRevenueFteQuantile2016 = quantile(overallProductivityDollarRevenueFteList2016$overall_productivity_dollar_revenue_fte,c(.25,.5,.75))
overallProductivityDollarRevenueFteMean2016 = mean(overallProductivityDollarRevenueFteList2016$overall_productivity_dollar_revenue_fte)


#19 Supporting Employees Profitability Measurement: Dollar Net Profit / Hours of Supporting Employees
Net.Profit.per.Hours.of.Supporting.Employees=comp$supporting_employee_dollar_net_profit
#2011 data of (1)
supportingEmployeeDollarNetProfitQuantile2011 = quantile(supportingEmployeeDollarNetProfitList2011$supporting_employee_dollar_net_profit,c(.25,.5,.75))
supportingEmployeeDollarNetProfitMean2011 = mean(supportingEmployeeDollarNetProfitList2011$supporting_employee_dollar_net_profit)
#2012 data of (1)
supportingEmployeeDollarNetProfitQuantile2012 = quantile(supportingEmployeeDollarNetProfitList2012$supporting_employee_dollar_net_profit,c(.25,.5,.75))
supportingEmployeeDollarNetProfitMean2012 = mean(supportingEmployeeDollarNetProfitList2012$supporting_employee_dollar_net_profit)
#2013 data of (1)
supportingEmployeeDollarNetProfitQuantile2013 = quantile(supportingEmployeeDollarNetProfitList2013$supporting_employee_dollar_net_profit,c(.25,.5,.75))
supportingEmployeeDollarNetProfitMean2013 = mean(supportingEmployeeDollarNetProfitList2013$supporting_employee_dollar_net_profit)
#2014 data of (1)
supportingEmployeeDollarNetProfitQuantile2014 = quantile(supportingEmployeeDollarNetProfitList2014$supporting_employee_dollar_net_profit,c(.25,.5,.75))
supportingEmployeeDollarNetProfitMean2014 = mean(supportingEmployeeDollarNetProfitList2014$supporting_employee_dollar_net_profit)
#2015 data of (1)
supportingEmployeeDollarNetProfitQuantile2015 = quantile(supportingEmployeeDollarNetProfitList2015$supporting_employee_dollar_net_profit,c(.25,.5,.75))
supportingEmployeeDollarNetProfitMean2015 = mean(supportingEmployeeDollarNetProfitList2015$supporting_employee_dollar_net_profit)
#2016 data of (1)
supportingEmployeeDollarNetProfitQuantile2016 = quantile(supportingEmployeeDollarNetProfitList2016$supporting_employee_dollar_net_profit,c(.25,.5,.75))
supportingEmployeeDollarNetProfitMean2016 = mean(supportingEmployeeDollarNetProfitList2016$supporting_employee_dollar_net_profit)



#18 Supporting Employees Productivity Measurement: Dollar Value Added/ Hours of Supporting Employees
Value.Added.per.Hours.of.Supporting.Employees=comp$supporting_employee_dollar_value_added
#2011 data of (1)
supportingEmployeeDollarValueAddedQuantile2011 = quantile(supportingEmployeeDollarValueAddedList2011$supporting_employee_dollar_value_added,c(.25,.5,.75))
supportingEmployeeDollarValueAddedMean2011 = mean(supportingEmployeeDollarValueAddedList2011$supporting_employee_dollar_value_added)
#2012 data of (1)
supportingEmployeeDollarValueAddedQuantile2012 = quantile(supportingEmployeeDollarValueAddedList2012$supporting_employee_dollar_value_added,c(.25,.5,.75))
supportingEmployeeDollarValueAddedMean2012 = mean(supportingEmployeeDollarValueAddedList2012$supporting_employee_dollar_value_added)
#2013 data of (1)
supportingEmployeeDollarValueAddedQuantile2013 = quantile(supportingEmployeeDollarValueAddedList2013$supporting_employee_dollar_value_added,c(.25,.5,.75))
supportingEmployeeDollarValueAddedMean2013 = mean(supportingEmployeeDollarValueAddedList2013$supporting_employee_dollar_value_added)
#2014 data of (1)
supportingEmployeeDollarValueAddedQuantile2014 = quantile(supportingEmployeeDollarValueAddedList2014$supporting_employee_dollar_value_added,c(.25,.5,.75))
supportingEmployeeDollarValueAddedMean2014 = mean(supportingEmployeeDollarValueAddedList2014$supporting_employee_dollar_value_added)
#2015 data of (1)
supportingEmployeeDollarValueAddedQuantile2015 = quantile(supportingEmployeeDollarValueAddedList2015$supporting_employee_dollar_value_added,c(.25,.5,.75))
supportingEmployeeDollarValueAddedMean2015 = mean(supportingEmployeeDollarValueAddedList2015$supporting_employee_dollar_value_added)
#2016 data of (1)
supportingEmployeeDollarValueAddedQuantile2016 = quantile(supportingEmployeeDollarValueAddedList2016$supporting_employee_dollar_value_added,c(.25,.5,.75))
supportingEmployeeDollarValueAddedMean2016 = mean(supportingEmployeeDollarValueAddedList2016$supporting_employee_dollar_value_added)



#17 Supporting Employees Productivity Measurement: Dollar Revenue/ Hours of Supporting Employees 
Revenue.per.Hours.of.Supporting.Employees=comp$supporting_employee_dollar_revenue
#2011 data of (1)
supportingEmployeeDollarRevenueQuantile2011 = quantile(supportingEmployeeDollarRevenueList2011$supporting_employee_dollar_revenue,c(.25,.5,.75))
supportingEmployeeDollarRevenueMean2011 = mean(supportingEmployeeDollarRevenueList2011$supporting_employee_dollar_revenue)
#2012 data of (1)
supportingEmployeeDollarRevenueQuantile2012 = quantile(supportingEmployeeDollarRevenueList2012$supporting_employee_dollar_revenue,c(.25,.5,.75))
supportingEmployeeDollarRevenueMean2012 = mean(supportingEmployeeDollarRevenueList2012$supporting_employee_dollar_revenue)
#2013 data of (1)
supportingEmployeeDollarRevenueQuantile2013 = quantile(supportingEmployeeDollarRevenueList2013$supporting_employee_dollar_revenue,c(.25,.5,.75))
supportingEmployeeDollarRevenueMean2013 = mean(supportingEmployeeDollarRevenueList2013$supporting_employee_dollar_revenue)
#2014 data of (1)
supportingEmployeeDollarRevenueQuantile2014 = quantile(supportingEmployeeDollarRevenueList2014$supporting_employee_dollar_revenue,c(.25,.5,.75))
supportingEmployeeDollarRevenueMean2014 = mean(supportingEmployeeDollarRevenueList2014$supporting_employee_dollar_revenue)
#2015 data of (1)
supportingEmployeeDollarRevenueQuantile2015 = quantile(supportingEmployeeDollarRevenueList2015$supporting_employee_dollar_revenue,c(.25,.5,.75))
supportingEmployeeDollarRevenueMean2015 = mean(supportingEmployeeDollarRevenueList2015$supporting_employee_dollar_revenue)
#2016 data of (1)
supportingEmployeeDollarRevenueQuantile2016 = quantile(supportingEmployeeDollarRevenueList2016$supporting_employee_dollar_revenue,c(.25,.5,.75))
supportingEmployeeDollarRevenueMean2016 = mean(supportingEmployeeDollarRevenueList2016$supporting_employee_dollar_revenue)


#16 Craft Worker Profitability Measurement: Dollar Net Profit / Hours of Bargaining Unit Employees 
Net.Profit.per.Expended.Man.Hours.of.Bargaining.Unit.Employees=comp$craft_worker_dollar_net_profit
#2011 data of (1)
craftWorkerDollarNetProfitQuantile2011 = quantile(craftWorkerDollarNetProfitList2011$craft_worker_dollar_net_profit,c(.25,.5,.75))
craftWorkerDollarNetProfitMean2011 = mean(craftWorkerDollarNetProfitList2011$craft_worker_dollar_net_profit)
#2012 data of (1)
craftWorkerDollarNetProfitQuantile2012 = quantile(craftWorkerDollarNetProfitList2012$craft_worker_dollar_net_profit,c(.25,.5,.75))
craftWorkerDollarNetProfitMean2012 = mean(craftWorkerDollarNetProfitList2012$craft_worker_dollar_net_profit)
#2013 data of (1)
craftWorkerDollarNetProfitQuantile2013 = quantile(craftWorkerDollarNetProfitList2013$craft_worker_dollar_net_profit,c(.25,.5,.75))
craftWorkerDollarNetProfitMean2013 = mean(craftWorkerDollarNetProfitList2013$craft_worker_dollar_net_profit)
#2014 data of (1)
craftWorkerDollarNetProfitQuantile2014 = quantile(craftWorkerDollarNetProfitList2014$craft_worker_dollar_net_profit,c(.25,.5,.75))
craftWorkerDollarNetProfitMean2014 = mean(craftWorkerDollarNetProfitList2014$craft_worker_dollar_net_profit)
#2015 data of (1)
craftWorkerDollarNetProfitQuantile2015 = quantile(craftWorkerDollarNetProfitList2015$craft_worker_dollar_net_profit,c(.25,.5,.75))
craftWorkerDollarNetProfitMean2015 = mean(craftWorkerDollarNetProfitList2015$craft_worker_dollar_net_profit)
#2016 data of (1)
craftWorkerDollarNetProfitQuantile2016 = quantile(craftWorkerDollarNetProfitList2016$craft_worker_dollar_net_profit,c(.25,.5,.75))
craftWorkerDollarNetProfitMean2016 = mean(craftWorkerDollarNetProfitList2016$craft_worker_dollar_net_profit)


#15 Craft Worker Productivity Measurement: Dollar Value Added/ Hours of Bargaining Unit  
Value.Added.per.Expended.Man.Hours.of.Bargaining.Unit.Employees=comp$craft_worker_dollar_value_added
#2011 data of (1)
craftWorkerDollarValueAddedQuantile2011 = quantile(craftWorkerDollarValueAddedList2011$craft_worker_dollar_value_added,c(.25,.5,.75))
craftWorkerDollarValueAddedMean2011 = mean(craftWorkerDollarValueAddedList2011$craft_worker_dollar_value_added)
#2012 data of (1)
craftWorkerDollarValueAddedQuantile2012 = quantile(craftWorkerDollarValueAddedList2012$craft_worker_dollar_value_added,c(.25,.5,.75))
craftWorkerDollarValueAddedMean2012 = mean(craftWorkerDollarValueAddedList2012$craft_worker_dollar_value_added)
#2013 data of (1)
craftWorkerDollarValueAddedQuantile2013 = quantile(craftWorkerDollarValueAddedList2013$craft_worker_dollar_value_added,c(.25,.5,.75))
craftWorkerDollarValueAddedMean2013 = mean(craftWorkerDollarValueAddedList2013$craft_worker_dollar_value_added)
#2014 data of (1)
craftWorkerDollarValueAddedQuantile2014 = quantile(craftWorkerDollarValueAddedList2014$craft_worker_dollar_value_added,c(.25,.5,.75))
craftWorkerDollarValueAddedMean2014 = mean(craftWorkerDollarValueAddedList2014$craft_worker_dollar_value_added)
#2015 data of (1)
craftWorkerDollarValueAddedQuantile2015 = quantile(craftWorkerDollarValueAddedList2015$craft_worker_dollar_value_added,c(.25,.5,.75))
craftWorkerDollarValueAddedMean2015 = mean(craftWorkerDollarValueAddedList2015$craft_worker_dollar_value_added)
#2016 data of (1)
craftWorkerDollarValueAddedQuantile2016 = quantile(craftWorkerDollarValueAddedList2016$craft_worker_dollar_value_added,c(.25,.5,.75))
craftWorkerDollarValueAddedMean2016 = mean(craftWorkerDollarValueAddedList2016$craft_worker_dollar_value_added)


#14 Craft Worker Productivity Measurement: Dollar Revenue/ Hours of Bargaining Unit Employees 
Revenue.per.Expended.Man.Hours.of.Bargaining.Unit.Employees=comp$craft_worker_dollar_revenue
#2011 data of (1)
craftWorkerDollarRevenueQuantile2011 = quantile(craftWorkerDollarRevenueList2011$craft_worker_dollar_revenue,c(.25,.5,.75))
craftWorkerDollarRevenueMean2011 = mean(craftWorkerDollarRevenueList2011$craft_worker_dollar_revenue)
#2012 data of (1)
craftWorkerDollarRevenueQuantile2012 = quantile(craftWorkerDollarRevenueList2012$craft_worker_dollar_revenue,c(.25,.5,.75))
craftWorkerDollarRevenueMean2012 = mean(craftWorkerDollarRevenueList2012$craft_worker_dollar_revenue)
#2013 data of (1)
craftWorkerDollarRevenueQuantile2013 = quantile(craftWorkerDollarRevenueList2013$craft_worker_dollar_revenue,c(.25,.5,.75))
craftWorkerDollarRevenueMean2013 = mean(craftWorkerDollarRevenueList2013$craft_worker_dollar_revenue)
#2014 data of (1)
craftWorkerDollarRevenueQuantile2014 = quantile(craftWorkerDollarRevenueList2014$craft_worker_dollar_revenue,c(.25,.5,.75))
craftWorkerDollarRevenueMean2014 = mean(craftWorkerDollarRevenueList2014$craft_worker_dollar_revenue)
#2015 data of (1)
craftWorkerDollarRevenueQuantile2015 = quantile(craftWorkerDollarRevenueList2015$craft_worker_dollar_revenue,c(.25,.5,.75))
craftWorkerDollarRevenueMean2015 = mean(craftWorkerDollarRevenueList2015$craft_worker_dollar_revenue)
#2016 data of (1)
craftWorkerDollarRevenueQuantile2016 = quantile(craftWorkerDollarRevenueList2016$craft_worker_dollar_revenue,c(.25,.5,.75))
craftWorkerDollarRevenueMean2016 = mean(craftWorkerDollarRevenueList2016$craft_worker_dollar_revenue)


#13 Project Management Profitability Measurement: Dollar Net Profit /Hours of Project Management Personnel 
Net.Profit.per.Hour.of.Field.Project.Management.Personnel=comp$project_management_dollar_net_profit
#2011 data of (1)
projectManagementProductivityDollarNetProfitQuantile2011 = quantile(projectManagementDollarNetProfitList2011$project_management_dollar_net_profit,c(.25,.5,.75))
projectManagementProductivityDollarNetProfitMean2011 = mean(projectManagementDollarNetProfitList2011$project_management_dollar_net_profit)
#2012 data of (1)
projectManagementProductivityDollarNetProfitQuantile2012 = quantile(projectManagementDollarNetProfitList2012$project_management_dollar_net_profit,c(.25,.5,.75))
projectManagementProductivityDollarNetProfitMean2012 = mean(projectManagementDollarNetProfitList2012$project_management_dollar_net_profit)
#2013 data of (1)
projectManagementProductivityDollarNetProfitQuantile2013 = quantile(projectManagementDollarNetProfitList2013$project_management_dollar_net_profit,c(.25,.5,.75))
projectManagementProductivityDollarNetProfitMean2013 = mean(projectManagementDollarNetProfitList2013$project_management_dollar_net_profit)
#2014 data of (1)
projectManagementProductivityDollarNetProfitQuantile2014 = quantile(projectManagementDollarNetProfitList2014$project_management_dollar_net_profit,c(.25,.5,.75))
projectManagementProductivityDollarNetProfitMean2014 = mean(projectManagementDollarNetProfitList2014$project_management_dollar_net_profit)
#2015 data of (1)
projectManagementProductivityDollarNetProfitQuantile2015 = quantile(projectManagementDollarNetProfitList2015$project_management_dollar_net_profit,c(.25,.5,.75))
projectManagementProductivityDollarNetProfitMean2015 = mean(projectManagementDollarNetProfitList2015$project_management_dollar_net_profit)
#2016 data of (1)
projectManagementProductivityDollarNetProfitQuantile2016 = quantile(projectManagementDollarNetProfitList2016$project_management_dollar_net_profit,c(.25,.5,.75))
projectManagementProductivityDollarNetProfitMean2016 = mean(projectManagementDollarNetProfitList2016$project_management_dollar_net_profit)


#12 Project Management Productivity Measurement: Dollar Value Added/Hours of Project Management Personnel 
Value.Added.per.Hour.of.Field.Project.Management.Personnel=comp$project_management_dollar_value_added
#2011 data of (1)
projectManagementProductivityDollarValueAddedQuantile2011 = quantile(projectManagementDollarValueAddedList2011$project_management_dollar_value_added,c(.25,.5,.75))
projectManagementProductivityDollarValueAddedMean2011 = mean(projectManagementDollarValueAddedList2011$project_management_dollar_value_added)
#2012 data of (1)
projectManagementProductivityDollarValueAddedQuantile2012 = quantile(projectManagementDollarValueAddedList2012$project_management_dollar_value_added,c(.25,.5,.75))
projectManagementProductivityDollarValueAddedMean2012 = mean(projectManagementDollarValueAddedList2012$project_management_dollar_value_added)
#2013 data of (1)
projectManagementProductivityDollarValueAddedQuantile2013 = quantile(projectManagementDollarValueAddedList2013$project_management_dollar_value_added,c(.25,.5,.75))
projectManagementProductivityDollarValueAddedMean2013 = mean(projectManagementDollarValueAddedList2013$project_management_dollar_value_added)
#2014 data of (1)
projectManagementProductivityDollarValueAddedQuantile2014 = quantile(projectManagementDollarValueAddedList2014$project_management_dollar_value_added,c(.25,.5,.75))
projectManagementProductivityDollarValueAddedMean2014 = mean(projectManagementDollarValueAddedList2014$project_management_dollar_value_added)
#2015 data of (1)
projectManagementProductivityDollarValueAddedQuantile2015 = quantile(projectManagementDollarValueAddedList2015$project_management_dollar_value_added,c(.25,.5,.75))
projectManagementProductivityDollarValueAddedMean2015 = mean(projectManagementDollarValueAddedList2015$project_management_dollar_value_added)
#2016 data of (1)
projectManagementProductivityDollarValueAddedQuantile2016 = quantile(projectManagementDollarValueAddedList2016$project_management_dollar_value_added,c(.25,.5,.75))
projectManagementProductivityDollarValueAddedMean2016 = mean(projectManagementDollarValueAddedList2016$project_management_dollar_value_added)


#11 Project Management Productivity Measurement: Dollar Revenue/Hours of Project Management Personnel 
Revenue.per.Hour.of.Field.Project.Management.Personnel=comp$project_management_dollar_revenue
#2011 data of (1)
projectManagementProductivityDollarRevenueQuantile2011 = quantile(projectManagementDollarRevenueList2011$project_management_dollar_revenue,c(.25,.5,.75))
projectManagementProductivityDollarRevenueMean2011 = mean(projectManagementDollarRevenueList2011$project_management_dollar_revenue)
#2012 data of (1)
projectManagementProductivityDollarRevenueQuantile2012 = quantile(projectManagementDollarRevenueList2012$project_management_dollar_revenue,c(.25,.5,.75))
projectManagementProductivityDollarRevenueMean2012 = mean(projectManagementDollarRevenueList2012$project_management_dollar_revenue)
#2013 data of (1)
projectManagementProductivityDollarRevenueQuantile2013 = quantile(projectManagementDollarRevenueList2013$project_management_dollar_revenue,c(.25,.5,.75))
projectManagementProductivityDollarRevenueMean2013 = mean(projectManagementDollarRevenueList2013$project_management_dollar_revenue)
#2014 data of (1)
projectManagementProductivityDollarRevenueQuantile2014 = quantile(projectManagementDollarRevenueList2014$project_management_dollar_revenue,c(.25,.5,.75))
projectManagementProductivityDollarRevenueMean2014 = mean(projectManagementDollarRevenueList2014$project_management_dollar_revenue)
#2015 data of (1)
projectManagementProductivityDollarRevenueQuantile2015 = quantile(projectManagementDollarRevenueList2015$project_management_dollar_revenue,c(.25,.5,.75))
projectManagementProductivityDollarRevenueMean2015 = mean(projectManagementDollarRevenueList2015$project_management_dollar_revenue)
#2016 data of (1)
projectManagementProductivityDollarRevenueQuantile2016 = quantile(projectManagementDollarRevenueList2016$project_management_dollar_revenue,c(.25,.5,.75))
projectManagementProductivityDollarRevenueMean2016 = mean(projectManagementDollarRevenueList2016$project_management_dollar_revenue)


#10 Overall Profitability Measurement – Dollar Net Profit /Hours of Company’s People
Net.Profit.per.Total.hours.of.People=comp$overall_productivity_measurement_dollar_net_profit
#2011 data of (1)
overallProductivityMeasurementDollarNetProfitQuantile2011 = quantile(overallProductivityMeasurementDollarNetProfitList2011$overall_productivity_measurement_dollar_net_profit,c(.25,.5,.75))
overallProductivityMeasurementDollarNetProfitMean2011 = mean(overallProductivityMeasurementDollarNetProfitList2011$overall_productivity_measurement_dollar_net_profit)
#2012 data of (1)
overallProductivityMeasurementDollarNetProfitQuantile2012 = quantile(overallProductivityMeasurementDollarNetProfitList2012$overall_productivity_measurement_dollar_net_profit,c(.25,.5,.75))
overallProductivityMeasurementDollarNetProfitMean2012 = mean(overallProductivityMeasurementDollarNetProfitList2012$overall_productivity_measurement_dollar_net_profit)
#2013 data of (1)
overallProductivityMeasurementDollarNetProfitQuantile2013 = quantile(overallProductivityMeasurementDollarNetProfitList2013$overall_productivity_measurement_dollar_net_profit,c(.25,.5,.75))
overallProductivityMeasurementDollarNetProfitMean2013 = mean(overallProductivityMeasurementDollarNetProfitList2013$overall_productivity_measurement_dollar_net_profit)
#2014 data of (1)
overallProductivityMeasurementDollarNetProfitQuantile2014 = quantile(overallProductivityMeasurementDollarNetProfitList2014$overall_productivity_measurement_dollar_net_profit,c(.25,.5,.75))
overallProductivityMeasurementDollarNetProfitMean2014 = mean(overallProductivityMeasurementDollarNetProfitList2014$overall_productivity_measurement_dollar_net_profit)
#2015 data of (1)
overallProductivityMeasurementDollarNetProfitQuantile2015 = quantile(overallProductivityMeasurementDollarNetProfitList2015$overall_productivity_measurement_dollar_net_profit,c(.25,.5,.75))
overallProductivityMeasurementDollarNetProfitMean2015 = mean(overallProductivityMeasurementDollarNetProfitList2015$overall_productivity_measurement_dollar_net_profit)
#2016 data of (1)
overallProductivityMeasurementDollarNetProfitQuantile2016 = quantile(overallProductivityMeasurementDollarNetProfitList2016$overall_productivity_measurement_dollar_net_profit,c(.25,.5,.75))
overallProductivityMeasurementDollarNetProfitMean2016 = mean(overallProductivityMeasurementDollarNetProfitList2016$overall_productivity_measurement_dollar_net_profit)


#9 Overall Productivity Measurement – Dollar Value Added/Hours of Company’s People 
Value.Added.per.Total.hours.of.People=comp$overall_productivity_measurement_dollar_value_added
#2011 data of (1)
overallProductivityMeasurementDollarValueAddedQuantile2011 = quantile(overallProductivityMeasurementDollarValueAddedList2011$overall_productivity_measurement_dollar_value_added,c(.25,.5,.75))
overallProductivityMeasurementDollarValueAddedMean2011 = mean(overallProductivityMeasurementDollarValueAddedList2011$overall_productivity_measurement_dollar_value_added)
#2012 data of (1)
overallProductivityMeasurementDollarValueAddedQuantile2012 = quantile(overallProductivityMeasurementDollarValueAddedList2012$overall_productivity_measurement_dollar_value_added,c(.25,.5,.75))
overallProductivityMeasurementDollarValueAddedMean2012 = mean(overallProductivityMeasurementDollarValueAddedList2012$overall_productivity_measurement_dollar_value_added)
#2013 data of (1)
overallProductivityMeasurementDollarValueAddedQuantile2013 = quantile(overallProductivityMeasurementDollarValueAddedList2013$overall_productivity_measurement_dollar_value_added,c(.25,.5,.75))
overallProductivityMeasurementDollarValueAddedMean2013 = mean(overallProductivityMeasurementDollarValueAddedList2013$overall_productivity_measurement_dollar_value_added)
#2014 data of (1)
overallProductivityMeasurementDollarValueAddedQuantile2014 = quantile(overallProductivityMeasurementDollarValueAddedList2014$overall_productivity_measurement_dollar_value_added,c(.25,.5,.75))
overallProductivityMeasurementDollarValueAddedMean2014 = mean(overallProductivityMeasurementDollarValueAddedList2014$overall_productivity_measurement_dollar_value_added)
#2015 data of (1)
overallProductivityMeasurementDollarValueAddedQuantile2015 = quantile(overallProductivityMeasurementDollarValueAddedList2015$overall_productivity_measurement_dollar_value_added,c(.25,.5,.75))
overallProductivityMeasurementDollarValueAddedMean2015 = mean(overallProductivityMeasurementDollarValueAddedList2015$overall_productivity_measurement_dollar_value_added)
#2016 data of (1)
overallProductivityMeasurementDollarValueAddedQuantile2016 = quantile(overallProductivityMeasurementDollarValueAddedList2016$overall_productivity_measurement_dollar_value_added,c(.25,.5,.75))
overallProductivityMeasurementDollarValueAddedMean2016 = mean(overallProductivityMeasurementDollarValueAddedList2016$overall_productivity_measurement_dollar_value_added)


#8 Overall Productivity Measurement – Dollar Revenue/Hours of Company’s People
Revenue.per.Total.hours.of.People=comp$overall_productivity_measurement_dollar_revenue
#2011 data of (1)
overallProductivityMeasurementDollarRevenueHoursQuantile2011 = quantile(overallProductivityMeasurementList2011$overall_productivity_measurement_dollar_revenue,c(.25,.5,.75))
overallProductivityMeasurementDollarRevenueHoursMean2011 = mean(overallProductivityMeasurementList2011$overall_productivity_measurement_dollar_revenue)
#2012 data of (1)
overallProductivityMeasurementDollarRevenueHoursQuantile2012 = quantile(overallProductivityMeasurementList2012$overall_productivity_measurement_dollar_revenue,c(.25,.5,.75))
overallProductivityMeasurementDollarRevenueHoursMean2012 = mean(overallProductivityMeasurementList2012$overall_productivity_measurement_dollar_revenue)
#2013 data of (1)
overallProductivityMeasurementDollarRevenueHoursQuantile2013 = quantile(overallProductivityMeasurementList2013$overall_productivity_measurement_dollar_revenue,c(.25,.5,.75))
overallProductivityMeasurementDollarRevenueHoursMean2013 = mean(overallProductivityMeasurementList2013$overall_productivity_measurement_dollar_revenue)
#2014 data of (1)
overallProductivityMeasurementDollarRevenueHoursQuantile2014 = quantile(overallProductivityMeasurementList2014$overall_productivity_measurement_dollar_revenue,c(.25,.5,.75))
overallProductivityMeasurementDollarRevenueHoursMean2014 = mean(overallProductivityMeasurementList2014$overall_productivity_measurement_dollar_revenue)
#2015 data of (1)
overallProductivityMeasurementDollarRevenueHoursQuantile2015 = quantile(overallProductivityMeasurementList2015$overall_productivity_measurement_dollar_revenue,c(.25,.5,.75))
overallProductivityMeasurementDollarRevenueHoursMean2015 = mean(overallProductivityMeasurementList2015$overall_productivity_measurement_dollar_revenue)
#2016 data of (1)
overallProductivityMeasurementDollarRevenueHoursQuantile2016 = quantile(overallProductivityMeasurementList2016$overall_productivity_measurement_dollar_revenue,c(.25,.5,.75))
overallProductivityMeasurementDollarRevenueHoursMean2016 = mean(overallProductivityMeasurementList2016$overall_productivity_measurement_dollar_revenue)


#6 Payments Disbursed to Subcontractors as a percentage of the Revenue
Percentage.of.Revenue.as.Payments.Disbursed.to.Subcontractors=comp$pay_disbursed_subcontr
#2011 data of (1)
payDisbursedSubContrQuantile2011 = quantile(payDisbursedSubContrList2011$pay_disbursed_subcontr,c(.25,.5,.75))
payDisbursedSubContrMean2011 = mean(payDisbursedSubContrList2011$pay_disbursed_subcontr)
#2012 data of (1)
payDisbursedSubContrQuantile2012 = quantile(payDisbursedSubContrList2012$pay_disbursed_subcontr,c(.25,.5,.75))
payDisbursedSubContrMean2012 = mean(payDisbursedSubContrList2012$pay_disbursed_subcontr)
#2013 data of (1)
payDisbursedSubContrQuantile2013 = quantile(payDisbursedSubContrList2013$pay_disbursed_subcontr,c(.25,.5,.75))
payDisbursedSubContrMean2013 = mean(payDisbursedSubContrList2013$pay_disbursed_subcontr)
#2014 data of (1)
payDisbursedSubContrQuantile2014 = quantile(payDisbursedSubContrList2014$pay_disbursed_subcontr,c(.25,.5,.75))
payDisbursedSubContrMean2014 = mean(payDisbursedSubContrList2014$pay_disbursed_subcontr)
#2015 data of (1)
payDisbursedSubContrQuantile2015 = quantile(payDisbursedSubContrList2015$pay_disbursed_subcontr,c(.25,.5,.75))
payDisbursedSubContrMean2015 = mean(payDisbursedSubContrList2015$pay_disbursed_subcontr)
#2016 data of (1)
payDisbursedSubContrQuantile2016 = quantile(payDisbursedSubContrList2016$pay_disbursed_subcontr,c(.25,.5,.75))
payDisbursedSubContrMean2016 = mean(payDisbursedSubContrList2016$pay_disbursed_subcontr)


#Cost of purchased materials by the company as a percentage of the revenue
Percentage.of.Revenue.as.Cost.of.Purchased.Materials=comp$cost_purchased_materials
#2011 data of (1)
costPurchasedMaterialsQuantile2011 = quantile(costPurchasedMaterials2011$cost_purchased_materials,c(.25,.5,.75))
costPurchasedMaterialsMean2011 = mean(costPurchasedMaterials2011$cost_purchased_materials)
#2012 data of (1)
costPurchasedMaterialsQuantile2012 = quantile(costPurchasedMaterials2012$cost_purchased_materials,c(.25,.5,.75))
costPurchasedMaterialsMean2012 = mean(costPurchasedMaterials2012$cost_purchased_materials)
#2013 data of (1)
costPurchasedMaterialsQuantile2013 = quantile(costPurchasedMaterials2013$cost_purchased_materials,c(.25,.5,.75))
costPurchasedMaterialsMean2013 = mean(costPurchasedMaterials2013$cost_purchased_materials)
#2014 data of (1)
costPurchasedMaterialsQuantile2014 = quantile(costPurchasedMaterials2014$cost_purchased_materials,c(.25,.5,.75))
costPurchasedMaterialsMean2014 = mean(costPurchasedMaterials2014$cost_purchased_materials)
#2015 data of (1)
costPurchasedMaterialsQuantile2015 = quantile(costPurchasedMaterials2015$cost_purchased_materials,c(.25,.5,.75))
costPurchasedMaterialsMean2015 = mean(costPurchasedMaterials2015$cost_purchased_materials)
#2016 data of (1)
costPurchasedMaterialsQuantile2016 = quantile(costPurchasedMaterials2016$cost_purchased_materials,c(.25,.5,.75))
costPurchasedMaterialsMean2016 = mean(costPurchasedMaterials2016$cost_purchased_materials)


# Net Profit Percentage
Net.Profit.Percentage=comp$net_profit_percentage
#2011 data of (1)
netProfitQuantile2011 = quantile(netProfitPercentageList2011$net_profit_percentage,c(.25,.5,.75))
netProfitMean2011 = mean(netProfitPercentageList2011$net_profit_percentage)
#2012 data of (1)
netProfitQuantile2012 = quantile(netProfitPercentageList2012$net_profit_percentage,c(.25,.5,.75))
netProfitMean2012 = mean(netProfitPercentageList2012$net_profit_percentage)
#2013 data of (1)
netProfitQuantile2013 = quantile(netProfitPercentageList2013$net_profit_percentage,c(.25,.5,.75))
netProfitMean2013 = mean(netProfitPercentageList2013$net_profit_percentage)
#2014 data of (1)
netProfitQuantile2014 = quantile(netProfitPercentageList2014$net_profit_percentage,c(.25,.5,.75))
netProfitMean2014 = mean(netProfitPercentageList2014$net_profit_percentage)
#2015 data of (1)
netProfitQuantile2015 = quantile(netProfitPercentageList2015$net_profit_percentage,c(.25,.5,.75))
netProfitMean2015 = mean(netProfitPercentageList2015$net_profit_percentage)
#2016 data of (1)
netProfitQuantile2016 = quantile(netProfitPercentageList2016$net_profit_percentage,c(.25,.5,.75))
netProfitMean2016 = mean(netProfitPercentageList2016$net_profit_percentage)



checkNA <- function(x) {
  if(length(x) == 0) {
    result <- NA
  }
  else
  {
    result <- x
  }
  return(result)
}


# Renaming the year as well as company name (Eckardt in the previous example) 
year=ordered(comp$year, levels=c("2011","2012","2013","2014","2015", "2016"))
Company=comp$company_name


# function that plots pdf output graph
plotGraphType1<-function(yAxis, titleVal)
{
  p <- ggplot(comp, aes_string(x="factor(year)", y=yAxis))
  p + geom_boxplot(outlier.size=NA) + geom_jitter(width=0.25,aes(color=Company),size=30)+
  theme(legend.key.height=unit(30,"line")) + 
  
  stat_summary(fun.y=mean, geom="point", shape="MEAN", size=50)+
  ggtitle(paste("\n",titleVal,"\n")) +
  theme(plot.title = element_text(family = "Times", color="#FF0000", face="bold", size=400, hjust=0.5, vjust=1)) + 
  theme(text=element_text(size=300))
}



# function that plots pdf output graph
plotGraphType2<-function(yAxis, titleVal)
{
  p <- ggplot(comp, aes_string(x="factor(year)", y=yAxis))
  p + geom_boxplot(outlier.size=NA) + geom_jitter(width=0.25,aes(color=Company),size=30)+
  scale_y_continuous(labels = percent)+
  theme(legend.key.height=unit(30,"line")) + 
  
  stat_summary(fun.y=mean, geom="point", shape="MEAN", size=50)+
  ggtitle(paste("\n",titleVal,"\n")) +
  theme(plot.title = element_text(family = "Times", color="#FF0000", face="bold", size=400, hjust=0.5, vjust=1)) + 
  theme(text=element_text(size=300))
}


# Function that plots pdf output data
plotData<-function(pdfTitle, pdfTitle2, pdfCompName, yearOne75th, yearOne50th, yearOne25th, yearOneMean, yearOneFormulaVal, yearTwo75th, yearTwo50th, yearTwo25th, yearTwoMean, yearTwoFormulaVal, yearThree75th, yearThree50th, yearThree25th, yearThreeMean, yearThreeFormulaVal, yearFour75th, yearFour50th, yearFour25th, yearFourMean, yearFourFormulaVal, yearFive75th, yearFive50th, yearFive25th, yearFiveMean, yearFiveFormulaVal,
yearSix75th, yearSix50th, yearSix25th, yearSixMean, yearSixFormulaVal)
{

	plot(-21:11, type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
	text(17, 11, adj = c( 0.5, NA ),paste("",pdfTitle,""),cex=20.0, col="red", font=2)
	text(17, 9, adj = c( 0.5, NA ),paste("",pdfTitle2,""),cex=20.0, col="red", font=2)
	
	text(1, 7.5, adj = c( 0, 1 ),"2011", col="red",cex=15.0)
	text(1, 6, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearOne75th), 2), nsmall = 2),""),cex=15.0)
	text(1, 4.5, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearOne50th), 2), nsmall = 2),""),cex=15.0)
	text(1, 3, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearOne25th), 2), nsmall = 2),""),cex=15.0)
	text(1, 1.5, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearOneMean), 2), nsmall = 2),""),cex=15.0)
	text(1, 0, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearOneFormulaVal), 2), nsmall = 2),""), cex=15.0, col="red")

	text(19, 7.5, adj = c( 0, 1 ),"2012", col="red",cex=15.0)
	text(19, 6, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearTwo75th), 2), nsmall = 2),""),cex=15.0)
	text(19, 4.5, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearTwo50th), 2), nsmall = 2),""),cex=15.0)
	text(19, 3, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearTwo25th), 2), nsmall = 2),""),cex=15.0)
	text(19, 1.5, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearTwoMean), 2), nsmall = 2),""),cex=15.0)
	text(19, 0, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearTwoFormulaVal), 2), nsmall = 2),""), col="red",cex=15.0)

	text(1, -3, adj = c( 0, 1 ),"2013", col="red",cex=15.0)
	text(1, -4.5, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearThree75th), 2), nsmall = 2),""),cex=15.0)
	text(1, -6, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearThree50th), 2), nsmall = 2),""),cex=15.0)
	text(1, -7.5, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearThree25th), 2), nsmall = 2),""),cex=15.0)
	text(1, -9, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearThreeMean), 2), nsmall = 2),""),cex=15.0)
	text(1, -10.5, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearThreeFormulaVal), 2), nsmall = 2),""), col="red",cex=15.0)

	text(19, -3, adj = c( 0, 1 ),"2014", col="red",cex=15.0)
	text(19, -4.5, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearFour75th), 2), nsmall = 2),""),cex=15.0)
	text(19, -6, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearFour50th), 2), nsmall = 2),""),cex=15.0)
	text(19, -7.5, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearFour25th), 2), nsmall = 2),""),cex=15.0)
	text(19, -9, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearFourMean), 2), nsmall = 2),""),cex=15.0)
	text(19, -10.5, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearFourFormulaVal), 2), nsmall = 2),""), col="red",cex=15.0)

	text(1, -13.5, adj = c( 0, 1 ),"2015", col="red",cex=15.0)
	text(1, -15, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearFive75th), 2), nsmall = 2),""),cex=15.0)
	text(1, -16.5, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearFive50th), 2), nsmall = 2),""),cex=15.0)
	text(1, -18, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearFive25th), 2), nsmall = 2),""),cex=15.0)
	text(1, -19.5, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearFiveMean), 2), nsmall = 2),""),cex=15.0)
	text(1, -21, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearFiveFormulaVal), 2), nsmall = 2),""), col="red",cex=15.0)
	
	text(19, -13.5, adj = c( 0, 1 ),"2016", col="red",cex=15.0)
	text(19, -15, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearSix75th), 2), nsmall = 2),""),cex=15.0)
	text(19, -16.5, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearSix50th), 2), nsmall = 2),""),cex=15.0)
	text(19, -18, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearSix25th), 2), nsmall = 2),""),cex=15.0)
	text(19, -19.5, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearSixMean), 2), nsmall = 2),""),cex=15.0)
	text(19, -21, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearSixFormulaVal), 2), nsmall = 2),""), col="red",cex=15.0)
	
}



# Function that plots pdf output data
plotDataType2<-function(pdfTitle, pdfTitle2, pdfCompName, yearOne75th, yearOne50th, yearOne25th, yearOneMean, yearOneFormulaVal, yearTwo75th, yearTwo50th, yearTwo25th, yearTwoMean, yearTwoFormulaVal, yearThree75th, yearThree50th, yearThree25th, yearThreeMean, yearThreeFormulaVal, yearFour75th, yearFour50th, yearFour25th, yearFourMean, yearFourFormulaVal, yearFive75th, yearFive50th, yearFive25th, yearFiveMean, yearFiveFormulaVal,
yearSix75th, yearSix50th, yearSix25th, yearSixMean, yearSixFormulaVal)
{
	plot(-21:11, type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
	text(17, 11, adj = c( 0.5, NA ),paste("",pdfTitle,""),cex=20.0, col="red", font=2)
	text(17, 9, adj = c( 0.5, NA ),paste("",pdfTitle2,""),cex=20.0, col="red", font=2)
	
	text(1, 7.5, adj = c( 0, 1 ),"2011", col="red",cex=15.0)
	text(1, 6, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearOne75th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, 4.5, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearOne50th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, 3, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearOne25th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, 1.5, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearOneMean*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, 0, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearOneFormulaVal*100), 2), nsmall = 2),"%"), cex=15.0, col="red")

	text(19, 7.5, adj = c( 0, 1 ),"2012", col="red",cex=15.0)
	text(19, 6, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearTwo75th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, 4.5, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearTwo50th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, 3, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearTwo25th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, 1.5, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearTwoMean*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, 0, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearTwoFormulaVal*100), 2), nsmall = 2),"%"), col="red",cex=15.0)

	text(1, -3, adj = c( 0, 1 ),"2013", col="red",cex=15.0)
	text(1, -4.5, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearThree75th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, -6, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearThree50th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, -7.5, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearThree25th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, -9, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearThreeMean*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, -10.5, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearThreeFormulaVal*100), 2), nsmall = 2),"%"), col="red",cex=15.0)

	text(19, -3, adj = c( 0, 1 ),"2014", col="red",cex=15.0)
	text(19, -4.5, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearFour75th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, -6, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearFour50th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, -7.5, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearFour25th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, -9, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearFourMean*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, -10.5, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearFourFormulaVal*100), 2), nsmall = 2),"%"), col="red",cex=15.0)

	text(1, -13.5, adj = c( 0, 1 ),"2015", col="red",cex=15.0)
	text(1, -15, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearFive75th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, -16.5, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearFive50th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, -18, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearFive25th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, -19.5, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearFiveMean*100), 2), nsmall = 2),"%"),cex=15.0)
	text(1, -21, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearFiveFormulaVal*100), 2), nsmall = 2),"%"), col="red",cex=15.0)
	
	text(19, -13.5, adj = c( 0, 1 ),"2016", col="red",cex=15.0)
	text(19, -15, adj = c( 0, 1 ),paste("75th percentile : ",format(round(checkNA(yearSix75th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, -16.5, adj = c( 0, 1 ),paste("Median 50th percentile:",format(round(checkNA(yearSix50th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, -18, adj = c( 0, 1 ),paste("25th percentile: ",format(round(checkNA(yearSix25th*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, -19.5, adj = c( 0, 1 ),paste("Mean (average): ",format(round(checkNA(yearSixMean*100), 2), nsmall = 2),"%"),cex=15.0)
	text(19, -21, adj = c( 0, 1 ),paste(pdfCompName,": ",format(round(checkNA(yearSixFormulaVal*100), 2), nsmall = 2),"%"), col="red",cex=15.0)
	
}


jj1 <- readJPEG("img/page1.JPG",native=TRUE)
jj2 <- readJPEG("img/page2.JPG",native=TRUE)
jj3 <- readJPEG("img/page3.JPG",native=TRUE)
jj4 <- readJPEG("img/page4.JPG",native=TRUE)
jj5 <- readJPEG("img/page5.JPG",native=TRUE)
jj6 <- readJPEG("img/page6.JPG",native=TRUE)
jj7 <- readJPEG("img/page7.JPG",native=TRUE)
jj8 <- readJPEG("img/page8.JPG",native=TRUE)
jj9 <- readJPEG("img/page9.JPG",native=TRUE)
jj10 <- readJPEG("img/page10.JPG",native=TRUE)
jj11 <- readJPEG("img/page11.JPG",native=TRUE)

str = paste (webCompanyName ,".pdf")
#pdf(str, paper="a4r")
pdf(str, width=200, height=150, bg="white")

par(family = 'Helvetica', ps=20)


#Page 1: Landing
plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj1,1,1,1000,1000)
text(500, 400, adj = c( 0.5, NA ),paste("",webCompanyName,""),cex=22.0, col="red", font=2)

plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj2,1,1,1000,1000)

plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj3,1,1,1000,1000)

plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj4,1,1,1000,1000)

plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj5,1,1,1000,1000)




#Formula 1
#Page 2: Net Profit Percentage Plot 
returnGraph1<-plotGraphType2("Net.Profit.Percentage", "Net Profit Percentage")
plot(returnGraph1)
#Page 3: Net Profit Percentage Data
plotDataType2("Net Profit Percentage", "", webCompanyName, 
netProfitQuantile2011[3], netProfitQuantile2011[2], netProfitQuantile2011[1], netProfitMean2011, netProfitPercentageCurCompany2011$net_profit_percentage, 
netProfitQuantile2012[3], netProfitQuantile2012[2], netProfitQuantile2012[1], netProfitMean2012, netProfitPercentageCurCompany2012$net_profit_percentage, 
netProfitQuantile2013[3], netProfitQuantile2013[2], netProfitQuantile2013[1], netProfitMean2013, netProfitPercentageCurCompany2013$net_profit_percentage, 
netProfitQuantile2014[3], netProfitQuantile2014[2], netProfitQuantile2014[1], netProfitMean2014, netProfitPercentageCurCompany2014$net_profit_percentage, 
netProfitQuantile2015[3], netProfitQuantile2015[2], netProfitQuantile2015[1], netProfitMean2015, netProfitPercentageCurCompany2015$net_profit_percentage,
netProfitQuantile2016[3], netProfitQuantile2016[2], netProfitQuantile2016[1], netProfitMean2016, netProfitPercentageCurCompany2016$net_profit_percentage)

#Formula 5
#Page 4: Cost of purchased materials by the company as a percentage of the revenue Plot
returnGraph2<-plotGraphType2("Percentage.of.Revenue.as.Cost.of.Purchased.Materials", "Cost of Purchased Materials by the Company")
plot(returnGraph2)
#Page 5: Cost of purchased materials by the company as a percentage of the revenue Data
plotDataType2("Cost of Purchased Materials by the Company", "", webCompanyName, 
costPurchasedMaterialsQuantile2011[3], costPurchasedMaterialsQuantile2011[2], costPurchasedMaterialsQuantile2011[1], costPurchasedMaterialsMean2011, costPurchasedMaterialsCurCompany2011$cost_purchased_materials, 
costPurchasedMaterialsQuantile2012[3], costPurchasedMaterialsQuantile2012[2], costPurchasedMaterialsQuantile2012[1], costPurchasedMaterialsMean2012, costPurchasedMaterialsCurCompany2012$cost_purchased_materials, 
costPurchasedMaterialsQuantile2013[3], costPurchasedMaterialsQuantile2013[2], costPurchasedMaterialsQuantile2013[1], costPurchasedMaterialsMean2013, costPurchasedMaterialsCurCompany2013$cost_purchased_materials, 
costPurchasedMaterialsQuantile2014[3], costPurchasedMaterialsQuantile2014[2], costPurchasedMaterialsQuantile2014[1], costPurchasedMaterialsMean2014, costPurchasedMaterialsCurCompany2014$cost_purchased_materials, 
costPurchasedMaterialsQuantile2015[3], costPurchasedMaterialsQuantile2015[2], costPurchasedMaterialsQuantile2015[1], costPurchasedMaterialsMean2015, costPurchasedMaterialsCurCompany2015$cost_purchased_materials,
costPurchasedMaterialsQuantile2016[3], costPurchasedMaterialsQuantile2016[2], costPurchasedMaterialsQuantile2016[1], costPurchasedMaterialsMean2016, costPurchasedMaterialsCurCompany2016$cost_purchased_materials)


#Formula 6
#Page 6: Cost of purchased materials by the company as a percentage of the revenue Plot
returnGraph3<-plotGraphType2("Percentage.of.Revenue.as.Payments.Disbursed.to.Subcontractors", "Payments Disbursed to Subcontractor")
plot(returnGraph3)
#Page 7: Cost of purchased materials by the company as a percentage of the revenue Data
plotDataType2("Payments Disbursed to Subcontractor", "", webCompanyName, 
payDisbursedSubContrQuantile2011[3], payDisbursedSubContrQuantile2011[2], payDisbursedSubContrQuantile2011[1], payDisbursedSubContrMean2011, payDisbursedSubContrCurCompany2011$pay_disbursed_subcontr, payDisbursedSubContrQuantile2012[3], payDisbursedSubContrQuantile2012[2], payDisbursedSubContrQuantile2012[1], payDisbursedSubContrMean2012, payDisbursedSubContrCurCompany2012$pay_disbursed_subcontr, payDisbursedSubContrQuantile2013[3], payDisbursedSubContrQuantile2013[2], payDisbursedSubContrQuantile2013[1], payDisbursedSubContrMean2013, payDisbursedSubContrCurCompany2013$pay_disbursed_subcontr, payDisbursedSubContrQuantile2014[3], payDisbursedSubContrQuantile2014[2], payDisbursedSubContrQuantile2014[1], payDisbursedSubContrMean2014, payDisbursedSubContrCurCompany2014$pay_disbursed_subcontr, payDisbursedSubContrQuantile2015[3], payDisbursedSubContrQuantile2015[2], payDisbursedSubContrQuantile2015[1], payDisbursedSubContrMean2015, payDisbursedSubContrCurCompany2015$pay_disbursed_subcontr,
payDisbursedSubContrQuantile2016[3], payDisbursedSubContrQuantile2016[2], payDisbursedSubContrQuantile2016[1], payDisbursedSubContrMean2016, payDisbursedSubContrCurCompany2016$pay_disbursed_subcontr)

#Transition
plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj6,1,1,1000,1000)

#Formula 8
#Page 8: Overall Productivity Measurement: Dollar Revenue/Hours of Company People Plot 
returnGraph4<-plotGraphType1("Revenue.per.Total.hours.of.People", "Overall Productivity Measurement: \nDollar Revenue/Hours of Company People")
plot(returnGraph4)
#Page 9: Overall Productivity Measurement – Dollar Revenue/Hours of Company’s People Data
plotData("Overall Productivity Measurement: ", "Dollar Revenue/Hours of Company People", webCompanyName, 
overallProductivityMeasurementDollarRevenueHoursQuantile2011[3], overallProductivityMeasurementDollarRevenueHoursQuantile2011[2], overallProductivityMeasurementDollarRevenueHoursQuantile2011[1], overallProductivityMeasurementDollarRevenueHoursMean2011, overallProductivityMeasurementCurCompany2011$overall_productivity_measurement_dollar_revenue, 
overallProductivityMeasurementDollarRevenueHoursQuantile2012[3], overallProductivityMeasurementDollarRevenueHoursQuantile2012[2], overallProductivityMeasurementDollarRevenueHoursQuantile2012[1], overallProductivityMeasurementDollarRevenueHoursMean2012, overallProductivityMeasurementCurCompany2012$overall_productivity_measurement_dollar_revenue, 
overallProductivityMeasurementDollarRevenueHoursQuantile2013[3], overallProductivityMeasurementDollarRevenueHoursQuantile2013[2], overallProductivityMeasurementDollarRevenueHoursQuantile2013[1], overallProductivityMeasurementDollarRevenueHoursMean2013, overallProductivityMeasurementCurCompany2013$overall_productivity_measurement_dollar_revenue, 
overallProductivityMeasurementDollarRevenueHoursQuantile2014[3], overallProductivityMeasurementDollarRevenueHoursQuantile2014[2], overallProductivityMeasurementDollarRevenueHoursQuantile2014[1], overallProductivityMeasurementDollarRevenueHoursMean2014, overallProductivityMeasurementCurCompany2014$overall_productivity_measurement_dollar_revenue, 
overallProductivityMeasurementDollarRevenueHoursQuantile2015[3], overallProductivityMeasurementDollarRevenueHoursQuantile2015[2], overallProductivityMeasurementDollarRevenueHoursQuantile2015[1], overallProductivityMeasurementDollarRevenueHoursMean2015, overallProductivityMeasurementCurCompany2015$overall_productivity_measurement_dollar_revenue,
overallProductivityMeasurementDollarRevenueHoursQuantile2016[3], overallProductivityMeasurementDollarRevenueHoursQuantile2016[2], overallProductivityMeasurementDollarRevenueHoursQuantile2016[1], overallProductivityMeasurementDollarRevenueHoursMean2016, overallProductivityMeasurementCurCompany2016$overall_productivity_measurement_dollar_revenue)


#Formula 9
#Page 10: Overall Productivity Measurement – Dollar Value Added/Hours of Company’s People Plot
returnGraph5<-plotGraphType1("Value.Added.per.Total.hours.of.People", "Overall Productivity Measurement: \nDollar Value Added/Hours of Company People")
plot(returnGraph5)
#Page 11: Overall Productivity Measurement – Dollar Value Added/Hours of Company’s People Data
plotData("Overall Productivity Measurement: ", "Dollar Value Added/Hours of Company People", webCompanyName, 
overallProductivityMeasurementDollarValueAddedQuantile2011[3], overallProductivityMeasurementDollarValueAddedQuantile2011[2], overallProductivityMeasurementDollarValueAddedQuantile2011[1], overallProductivityMeasurementDollarValueAddedMean2011, overallProductivityMeasurementDollarValueAddedCurCompany2011$overall_productivity_measurement_dollar_value_added ,
overallProductivityMeasurementDollarValueAddedQuantile2012[3], overallProductivityMeasurementDollarValueAddedQuantile2012[2], overallProductivityMeasurementDollarValueAddedQuantile2012[1], overallProductivityMeasurementDollarValueAddedMean2012, overallProductivityMeasurementDollarValueAddedCurCompany2012$overall_productivity_measurement_dollar_value_added , 
overallProductivityMeasurementDollarValueAddedQuantile2013[3], overallProductivityMeasurementDollarValueAddedQuantile2013[2], overallProductivityMeasurementDollarValueAddedQuantile2013[1], overallProductivityMeasurementDollarValueAddedMean2013, overallProductivityMeasurementDollarValueAddedCurCompany2013$overall_productivity_measurement_dollar_value_added , 
overallProductivityMeasurementDollarValueAddedQuantile2014[3], overallProductivityMeasurementDollarValueAddedQuantile2014[2], overallProductivityMeasurementDollarValueAddedQuantile2014[1], overallProductivityMeasurementDollarValueAddedMean2014, overallProductivityMeasurementDollarValueAddedCurCompany2014$overall_productivity_measurement_dollar_value_added , 
overallProductivityMeasurementDollarValueAddedQuantile2015[3], overallProductivityMeasurementDollarValueAddedQuantile2015[2], overallProductivityMeasurementDollarValueAddedQuantile2015[1], overallProductivityMeasurementDollarValueAddedMean2015, overallProductivityMeasurementDollarValueAddedCurCompany2015$overall_productivity_measurement_dollar_value_added ,
overallProductivityMeasurementDollarValueAddedQuantile2016[3], overallProductivityMeasurementDollarValueAddedQuantile2016[2], overallProductivityMeasurementDollarValueAddedQuantile2016[1], overallProductivityMeasurementDollarValueAddedMean2016, overallProductivityMeasurementDollarValueAddedCurCompany2016$overall_productivity_measurement_dollar_value_added )



#Formula 10
#Page 12: Overall Profitability Measurement – Dollar Net Profit /Hours of Company’s People Plot
returnGraph6<-plotGraphType1("Net.Profit.per.Total.hours.of.People", "Overall Profitability Measurement: \nDollar Net Profit /Hours of Company People")
plot(returnGraph6)
#Page 13: Overall Profitability Measurement – Dollar Net Profit /Hours of Company’s People Data
plotData("Overall Profitability Measurement: ", "Dollar Net Profit /Hours of Company People", webCompanyName, 
overallProductivityMeasurementDollarNetProfitQuantile2011[3], overallProductivityMeasurementDollarNetProfitQuantile2011[2], overallProductivityMeasurementDollarNetProfitQuantile2011[1], overallProductivityMeasurementDollarNetProfitMean2011, overallProductivityMeasurementDollarNetProfitCurCompany2011$overall_productivity_measurement_dollar_net_profit, 
overallProductivityMeasurementDollarNetProfitQuantile2012[3], overallProductivityMeasurementDollarNetProfitQuantile2012[2], overallProductivityMeasurementDollarNetProfitQuantile2012[1], overallProductivityMeasurementDollarNetProfitMean2012, overallProductivityMeasurementDollarNetProfitCurCompany2012$overall_productivity_measurement_dollar_net_profit, 
overallProductivityMeasurementDollarNetProfitQuantile2013[3], overallProductivityMeasurementDollarNetProfitQuantile2013[2], overallProductivityMeasurementDollarNetProfitQuantile2013[1], overallProductivityMeasurementDollarNetProfitMean2013, overallProductivityMeasurementDollarNetProfitCurCompany2013$overall_productivity_measurement_dollar_net_profit, 
overallProductivityMeasurementDollarNetProfitQuantile2014[3], overallProductivityMeasurementDollarNetProfitQuantile2014[2], overallProductivityMeasurementDollarNetProfitQuantile2014[1], overallProductivityMeasurementDollarNetProfitMean2014, overallProductivityMeasurementDollarNetProfitCurCompany2014$overall_productivity_measurement_dollar_net_profit, 
overallProductivityMeasurementDollarNetProfitQuantile2015[3], overallProductivityMeasurementDollarNetProfitQuantile2015[2], overallProductivityMeasurementDollarNetProfitQuantile2015[1], overallProductivityMeasurementDollarNetProfitMean2015, overallProductivityMeasurementDollarNetProfitCurCompany2015$overall_productivity_measurement_dollar_net_profit,
overallProductivityMeasurementDollarNetProfitQuantile2016[3], overallProductivityMeasurementDollarNetProfitQuantile2016[2], overallProductivityMeasurementDollarNetProfitQuantile2016[1], overallProductivityMeasurementDollarNetProfitMean2016, overallProductivityMeasurementDollarNetProfitCurCompany2016$overall_productivity_measurement_dollar_net_profit)



#Formula 11
#Page 14: Project Management Productivity Measurement: Dollar Revenue/Hours of Project Management Personnel Plot
returnGraph7<-plotGraphType1("Revenue.per.Hour.of.Field.Project.Management.Personnel", "Project Management Productivity Measurement: \nDollar Revenue/Hours of Project Management Personnel")
plot(returnGraph7)
#Page 15: Project Management Productivity Measurement: Dollar Revenue/Hours of Project Management Personnel Data
plotData("Project Management Productivity Measurement: ", "Dollar Revenue/Hours of Project Management Personnel", webCompanyName, 
projectManagementProductivityDollarRevenueQuantile2011[3], projectManagementProductivityDollarRevenueQuantile2011[2], projectManagementProductivityDollarRevenueQuantile2011[1], projectManagementProductivityDollarRevenueMean2011, projectManagementDollarRevenueCurCompany2011$project_management_dollar_revenue, 
projectManagementProductivityDollarRevenueQuantile2012[3], projectManagementProductivityDollarRevenueQuantile2012[2], projectManagementProductivityDollarRevenueQuantile2012[1], projectManagementProductivityDollarRevenueMean2012, projectManagementDollarRevenueCurCompany2012$project_management_dollar_revenue, 
projectManagementProductivityDollarRevenueQuantile2013[3], projectManagementProductivityDollarRevenueQuantile2013[2], projectManagementProductivityDollarRevenueQuantile2013[1], projectManagementProductivityDollarRevenueMean2013, projectManagementDollarRevenueCurCompany2013$project_management_dollar_revenue, 
projectManagementProductivityDollarRevenueQuantile2014[3], projectManagementProductivityDollarRevenueQuantile2014[2], projectManagementProductivityDollarRevenueQuantile2014[1], projectManagementProductivityDollarRevenueMean2014, projectManagementDollarRevenueCurCompany2014$project_management_dollar_revenue, 
projectManagementProductivityDollarRevenueQuantile2015[3], projectManagementProductivityDollarRevenueQuantile2015[2], projectManagementProductivityDollarRevenueQuantile2015[1], projectManagementProductivityDollarRevenueMean2015, projectManagementDollarRevenueCurCompany2015$project_management_dollar_revenue,
projectManagementProductivityDollarRevenueQuantile2016[3], projectManagementProductivityDollarRevenueQuantile2016[2], projectManagementProductivityDollarRevenueQuantile2016[1], projectManagementProductivityDollarRevenueMean2016, projectManagementDollarRevenueCurCompany2016$project_management_dollar_revenue)


#Formula 12
#Page 16: Project Management Productivity Measurement: Dollar Value Added/Hours of Project Management Personnel  Plot
returnGraph7<-plotGraphType1("Value.Added.per.Hour.of.Field.Project.Management.Personnel", "Project Management Productivity Measurement: \nDollar Value Added/Hours of Project Management Personnel")
plot(returnGraph7)
#Page 17: Project Management Productivity Measurement: Dollar Value Added/Hours of Project Management Personnel  Data
plotData("Project Management Productivity Measurement: ", "Dollar Value Added/Hours of Project Management Personnel", webCompanyName, 
projectManagementProductivityDollarValueAddedQuantile2011[3], projectManagementProductivityDollarValueAddedQuantile2011[2], projectManagementProductivityDollarValueAddedQuantile2011[1], projectManagementProductivityDollarValueAddedMean2011, projectManagementDollarValueAddedCurCompany2011$project_management_dollar_value_added, 
projectManagementProductivityDollarValueAddedQuantile2012[3], projectManagementProductivityDollarValueAddedQuantile2012[2], projectManagementProductivityDollarValueAddedQuantile2012[1], projectManagementProductivityDollarValueAddedMean2012, projectManagementDollarValueAddedCurCompany2012$project_management_dollar_value_added, 
projectManagementProductivityDollarValueAddedQuantile2013[3], projectManagementProductivityDollarValueAddedQuantile2013[2], projectManagementProductivityDollarValueAddedQuantile2013[1], projectManagementProductivityDollarValueAddedMean2013, projectManagementDollarValueAddedCurCompany2013$project_management_dollar_value_added, 
projectManagementProductivityDollarValueAddedQuantile2014[3], projectManagementProductivityDollarValueAddedQuantile2014[2], projectManagementProductivityDollarValueAddedQuantile2014[1], projectManagementProductivityDollarValueAddedMean2014, projectManagementDollarValueAddedCurCompany2014$project_management_dollar_value_added, 
projectManagementProductivityDollarValueAddedQuantile2015[3], projectManagementProductivityDollarValueAddedQuantile2015[2], projectManagementProductivityDollarValueAddedQuantile2015[1], projectManagementProductivityDollarValueAddedMean2015, projectManagementDollarValueAddedCurCompany2015$project_management_dollar_value_added,
projectManagementProductivityDollarValueAddedQuantile2016[3], projectManagementProductivityDollarValueAddedQuantile2016[2], projectManagementProductivityDollarValueAddedQuantile2016[1], projectManagementProductivityDollarValueAddedMean2016, projectManagementDollarValueAddedCurCompany2016$project_management_dollar_value_added)


#Formula 13
#Page 18: Project Management Profitability Measurement: Dollar Net Profit /Hours of Project Management Personnel Plot
returnGraph7<-plotGraphType1("Value.Added.per.Hour.of.Field.Project.Management.Personnel", "Project Management Profitability Measurement: \nDollar Net Profit /Hours of Project Management Personnel")
plot(returnGraph7)
#Page 19: Project Management Profitability Measurement: Dollar Net Profit /Hours of Project Management Personnel Data
plotData("Project Management Profitability Measurement: ", "Dollar Net Profit /Hours of Project Management Personnel", webCompanyName, 
projectManagementProductivityDollarNetProfitQuantile2011[3], projectManagementProductivityDollarNetProfitQuantile2011[2], projectManagementProductivityDollarNetProfitQuantile2011[1], projectManagementProductivityDollarNetProfitMean2011, projectManagementDollarNetProfitCurCompany2011$project_management_dollar_net_profit, 

projectManagementProductivityDollarNetProfitQuantile2012[3], projectManagementProductivityDollarNetProfitQuantile2012[2], projectManagementProductivityDollarNetProfitQuantile2012[1], projectManagementProductivityDollarNetProfitMean2012, projectManagementDollarNetProfitCurCompany2012$project_management_dollar_net_profit

, projectManagementProductivityDollarNetProfitQuantile2013[3], projectManagementProductivityDollarNetProfitQuantile2013[2], projectManagementProductivityDollarNetProfitQuantile2013[1], projectManagementProductivityDollarNetProfitMean2013, projectManagementDollarNetProfitCurCompany2013$project_management_dollar_net_profit

, projectManagementProductivityDollarNetProfitQuantile2014[3], projectManagementProductivityDollarNetProfitQuantile2014[2], projectManagementProductivityDollarNetProfitQuantile2014[1], projectManagementProductivityDollarNetProfitMean2014, projectManagementDollarNetProfitCurCompany2014$project_management_dollar_net_profit

, projectManagementProductivityDollarNetProfitQuantile2015[3], projectManagementProductivityDollarNetProfitQuantile2015[2], projectManagementProductivityDollarNetProfitQuantile2015[1], projectManagementProductivityDollarNetProfitMean2015, projectManagementDollarNetProfitCurCompany2015$project_management_dollar_net_profit

, projectManagementProductivityDollarNetProfitQuantile2016[3], projectManagementProductivityDollarNetProfitQuantile2016[2], projectManagementProductivityDollarNetProfitQuantile2016[1], projectManagementProductivityDollarNetProfitMean2016, projectManagementDollarNetProfitCurCompany2016$project_management_dollar_net_profit)


#Formula 14
#Page 20: Craft Worker Productivity Measurement: Dollar Revenue/ Hours of Bargaining Unit Employees Plot
returnGraph7<-plotGraphType1("Revenue.per.Expended.Man.Hours.of.Bargaining.Unit.Employees","Craft Worker Productivity Measurement: \nDollar Revenue/ Hours of Bargaining Unit Employees")
plot(returnGraph7)
#Page 21: Craft Worker Productivity Measurement: Dollar Revenue/ Hours of Bargaining Unit Employees Data
plotData("Craft Worker Productivity Measurement: ","Dollar Revenue/ Hours of Bargaining Unit Employees", webCompanyName, 
craftWorkerDollarRevenueQuantile2011[3], craftWorkerDollarRevenueQuantile2011[2], craftWorkerDollarRevenueQuantile2011[1], craftWorkerDollarRevenueMean2011, craftWorkerDollarRevenueCurCompany2011$craft_worker_dollar_revenue, 

craftWorkerDollarRevenueQuantile2012[3], craftWorkerDollarRevenueQuantile2012[2], craftWorkerDollarRevenueQuantile2012[1], craftWorkerDollarRevenueMean2012, craftWorkerDollarRevenueCurCompany2012$craft_worker_dollar_revenue

, craftWorkerDollarRevenueQuantile2013[3], craftWorkerDollarRevenueQuantile2013[2], craftWorkerDollarRevenueQuantile2013[1], craftWorkerDollarRevenueMean2013, craftWorkerDollarRevenueCurCompany2013$craft_worker_dollar_revenue

, craftWorkerDollarRevenueQuantile2014[3], craftWorkerDollarRevenueQuantile2014[2], craftWorkerDollarRevenueQuantile2014[1], craftWorkerDollarRevenueMean2014, craftWorkerDollarRevenueCurCompany2014$craft_worker_dollar_revenue

, craftWorkerDollarRevenueQuantile2015[3], craftWorkerDollarRevenueQuantile2015[2], craftWorkerDollarRevenueQuantile2015[1], craftWorkerDollarRevenueMean2015, craftWorkerDollarRevenueCurCompany2015$craft_worker_dollar_revenue

, craftWorkerDollarRevenueQuantile2016[3], craftWorkerDollarRevenueQuantile2016[2], craftWorkerDollarRevenueQuantile2016[1], craftWorkerDollarRevenueMean2016, craftWorkerDollarRevenueCurCompany2016$craft_worker_dollar_revenue)



#Formula 15
#Page 22: Craft Worker Productivity Measurement: Dollar Value Added/ Hours of Bargaining Unit Plot
returnGraph7<-plotGraphType1("Value.Added.per.Expended.Man.Hours.of.Bargaining.Unit.Employees", "Craft Worker Productivity Measurement: \nDollar Value Added/ Hours of Bargaining Unit")
plot(returnGraph7)
#Page 23: Craft Worker Productivity Measurement: Dollar Value Added/ Hours of Bargaining Unit Data
plotData("Craft Worker Productivity Measurement: ","Dollar Value Added/ Hours of Bargaining Unit", webCompanyName, 
craftWorkerDollarValueAddedQuantile2011[3], craftWorkerDollarValueAddedQuantile2011[2], craftWorkerDollarValueAddedQuantile2011[1], craftWorkerDollarValueAddedMean2011, craftWorkerDollarValueAddedCurCompany2011$craft_worker_dollar_value_added, 

craftWorkerDollarValueAddedQuantile2012[3], craftWorkerDollarValueAddedQuantile2012[2], craftWorkerDollarValueAddedQuantile2012[1], craftWorkerDollarValueAddedMean2012, craftWorkerDollarValueAddedCurCompany2012$craft_worker_dollar_value_added

, craftWorkerDollarValueAddedQuantile2013[3], craftWorkerDollarValueAddedQuantile2013[2], craftWorkerDollarValueAddedQuantile2013[1], craftWorkerDollarValueAddedMean2013, craftWorkerDollarValueAddedCurCompany2013$craft_worker_dollar_value_added

, craftWorkerDollarValueAddedQuantile2014[3], craftWorkerDollarValueAddedQuantile2014[2], craftWorkerDollarValueAddedQuantile2014[1], craftWorkerDollarValueAddedMean2014, craftWorkerDollarValueAddedCurCompany2014$craft_worker_dollar_value_added

, craftWorkerDollarValueAddedQuantile2015[3], craftWorkerDollarValueAddedQuantile2015[2], craftWorkerDollarValueAddedQuantile2015[1], craftWorkerDollarValueAddedMean2015, craftWorkerDollarValueAddedCurCompany2015$craft_worker_dollar_value_added

, craftWorkerDollarValueAddedQuantile2016[3], craftWorkerDollarValueAddedQuantile2016[2], craftWorkerDollarValueAddedQuantile2016[1], craftWorkerDollarValueAddedMean2016, craftWorkerDollarValueAddedCurCompany2016$craft_worker_dollar_value_added)


#Formula 16
#Page 24: Craft Worker Profitability Measurement: Dollar Net Profit / Hours of Bargaining Unit Employees Plot
returnGraph7<-plotGraphType1("Net.Profit.per.Expended.Man.Hours.of.Bargaining.Unit.Employees", "Craft Worker Profitability Measurement: \nDollar Net Profit / Hours of Bargaining Unit Employees")
plot(returnGraph7)
#Page 25: Craft Worker Profitability Measurement: Dollar Net Profit / Hours of Bargaining Unit Employees Data
plotData("Craft Worker Profitability Measurement: ","Dollar Net Profit / Hours of Bargaining Unit Employees", webCompanyName, 
craftWorkerDollarNetProfitQuantile2011[3], craftWorkerDollarNetProfitQuantile2011[2], craftWorkerDollarNetProfitQuantile2011[1], craftWorkerDollarNetProfitMean2011, craftWorkerDollarNetProfitCurCompany2011$craft_worker_dollar_net_profit, 

craftWorkerDollarNetProfitQuantile2012[3], craftWorkerDollarNetProfitQuantile2012[2], craftWorkerDollarNetProfitQuantile2012[1], craftWorkerDollarNetProfitMean2012, craftWorkerDollarNetProfitCurCompany2012$craft_worker_dollar_net_profit

, craftWorkerDollarNetProfitQuantile2013[3], craftWorkerDollarNetProfitQuantile2013[2], craftWorkerDollarNetProfitQuantile2013[1], craftWorkerDollarNetProfitMean2013, craftWorkerDollarNetProfitCurCompany2013$craft_worker_dollar_net_profit

, craftWorkerDollarNetProfitQuantile2014[3], craftWorkerDollarNetProfitQuantile2014[2], craftWorkerDollarNetProfitQuantile2014[1], craftWorkerDollarNetProfitMean2014, craftWorkerDollarNetProfitCurCompany2014$craft_worker_dollar_net_profit

, craftWorkerDollarNetProfitQuantile2015[3], craftWorkerDollarNetProfitQuantile2015[2], craftWorkerDollarNetProfitQuantile2015[1], craftWorkerDollarNetProfitMean2015, craftWorkerDollarNetProfitCurCompany2015$craft_worker_dollar_net_profit

, craftWorkerDollarNetProfitQuantile2016[3], craftWorkerDollarNetProfitQuantile2016[2], craftWorkerDollarNetProfitQuantile2016[1], craftWorkerDollarNetProfitMean2016, craftWorkerDollarNetProfitCurCompany2016$craft_worker_dollar_net_profit)


#Formula 17
#Page 26: Supporting Employees Productivity Measurement: Dollar Revenue/ Hours of Supporting Employees Plot
returnGraph8<-plotGraphType1("Revenue.per.Hours.of.Supporting.Employees","Supporting Employees Productivity Measurement: \nDollar Revenue/ Hours of Supporting Employees")
plot(returnGraph8)
#Page 27: Supporting Employees Productivity Measurement: Dollar Revenue/ Hours of Supporting Employees Data
plotData("Supporting Employees Productivity Measurement: ","Dollar Revenue/ Hours of Supporting Employees", webCompanyName, 
supportingEmployeeDollarRevenueQuantile2011[3], supportingEmployeeDollarRevenueQuantile2011[2], supportingEmployeeDollarRevenueQuantile2011[1], supportingEmployeeDollarRevenueMean2011, supportingEmployeeDollarRevenueCurCompany2011$supporting_employee_dollar_revenue, 

supportingEmployeeDollarRevenueQuantile2012[3], supportingEmployeeDollarRevenueQuantile2012[2], supportingEmployeeDollarRevenueQuantile2012[1], supportingEmployeeDollarRevenueMean2012, supportingEmployeeDollarRevenueCurCompany2012$supporting_employee_dollar_revenue

, supportingEmployeeDollarRevenueQuantile2013[3], supportingEmployeeDollarRevenueQuantile2013[2], supportingEmployeeDollarRevenueQuantile2013[1], supportingEmployeeDollarRevenueMean2013, supportingEmployeeDollarRevenueCurCompany2013$supporting_employee_dollar_revenue

, supportingEmployeeDollarRevenueQuantile2014[3], supportingEmployeeDollarRevenueQuantile2014[2], supportingEmployeeDollarRevenueQuantile2014[1], supportingEmployeeDollarRevenueMean2013, supportingEmployeeDollarRevenueCurCompany2014$supporting_employee_dollar_revenue

, supportingEmployeeDollarRevenueQuantile2015[3], supportingEmployeeDollarRevenueQuantile2015[2], supportingEmployeeDollarRevenueQuantile2015[1], supportingEmployeeDollarRevenueMean2015, supportingEmployeeDollarRevenueCurCompany2015$supporting_employee_dollar_revenue

, supportingEmployeeDollarRevenueQuantile2016[3], supportingEmployeeDollarRevenueQuantile2016[2], supportingEmployeeDollarRevenueQuantile2016[1], supportingEmployeeDollarRevenueMean2016, supportingEmployeeDollarRevenueCurCompany2016$supporting_employee_dollar_revenue)



#Formula 18
#Page 28: Supporting Employees Productivity Measurement: Dollar Value Added/ Hours of Supporting Employees Plot
returnGraph8<-plotGraphType1("Value.Added.per.Hours.of.Supporting.Employees", "Supporting Employees Productivity Measurement: \nDollar Value Added/ Hours of Supporting Employees")
plot(returnGraph8)
#Page 29: Supporting Employees Productivity Measurement: Dollar Value Added/ Hours of Supporting Employees Data
plotData("Supporting Employees Productivity Measurement: ","Dollar Value Added/ Hours of Supporting Employees", webCompanyName, 
supportingEmployeeDollarValueAddedQuantile2011[3], supportingEmployeeDollarValueAddedQuantile2011[2], supportingEmployeeDollarValueAddedQuantile2011[1], supportingEmployeeDollarValueAddedMean2011, supportingEmployeeDollarValueAddedCurCompany2011$supporting_employee_dollar_value_added, 

supportingEmployeeDollarValueAddedQuantile2012[3], supportingEmployeeDollarValueAddedQuantile2012[2], supportingEmployeeDollarValueAddedQuantile2012[1], supportingEmployeeDollarValueAddedMean2012, supportingEmployeeDollarValueAddedCurCompany2012$supporting_employee_dollar_value_added

, supportingEmployeeDollarValueAddedQuantile2013[3], supportingEmployeeDollarValueAddedQuantile2013[2], supportingEmployeeDollarValueAddedQuantile2013[1], supportingEmployeeDollarValueAddedMean2013, supportingEmployeeDollarValueAddedCurCompany2013$supporting_employee_dollar_value_added

, supportingEmployeeDollarValueAddedQuantile2014[3], supportingEmployeeDollarValueAddedQuantile2014[2], supportingEmployeeDollarValueAddedQuantile2014[1], supportingEmployeeDollarValueAddedMean2014, supportingEmployeeDollarValueAddedCurCompany2014$supporting_employee_dollar_value_added

, supportingEmployeeDollarValueAddedQuantile2015[3], supportingEmployeeDollarValueAddedQuantile2015[2], supportingEmployeeDollarValueAddedQuantile2015[1], supportingEmployeeDollarValueAddedMean2015, supportingEmployeeDollarValueAddedCurCompany2015$supporting_employee_dollar_value_added

, supportingEmployeeDollarValueAddedQuantile2016[3], supportingEmployeeDollarValueAddedQuantile2016[2], supportingEmployeeDollarValueAddedQuantile2016[1], supportingEmployeeDollarValueAddedMean2016, supportingEmployeeDollarValueAddedCurCompany2016$supporting_employee_dollar_value_added)



#Formula 19
#Page 30: Supporting Employees Profitability Measurement: Dollar Net Profit / Hours of Supporting Employees Plot
returnGraph8<-plotGraphType1("Net.Profit.per.Hours.of.Supporting.Employees", "Supporting Employees Profitability Measurement: \nDollar Net Profit / Hours of Supporting Employees")
plot(returnGraph8)
#Page 31: Supporting Employees Profitability Measurement: Dollar Net Profit / Hours of Supporting Employees Data
plotData("Supporting Employees Profitability Measurement: ","Dollar Net Profit / Hours of Supporting Employees", webCompanyName, 
supportingEmployeeDollarNetProfitQuantile2011[3], supportingEmployeeDollarNetProfitQuantile2011[2], supportingEmployeeDollarNetProfitQuantile2011[1], supportingEmployeeDollarNetProfitMean2011, supportingEmployeeDollarNetProfitCurCompany2011$supporting_employee_dollar_net_profit, 

supportingEmployeeDollarNetProfitQuantile2012[3], supportingEmployeeDollarNetProfitQuantile2012[2], supportingEmployeeDollarNetProfitQuantile2012[1], supportingEmployeeDollarNetProfitMean2012, supportingEmployeeDollarNetProfitCurCompany2012$supporting_employee_dollar_net_profit

, supportingEmployeeDollarNetProfitQuantile2013[3], supportingEmployeeDollarNetProfitQuantile2013[2], supportingEmployeeDollarNetProfitQuantile2013[1], supportingEmployeeDollarNetProfitMean2013, supportingEmployeeDollarNetProfitCurCompany2013$supporting_employee_dollar_net_profit

, supportingEmployeeDollarNetProfitQuantile2014[3], supportingEmployeeDollarNetProfitQuantile2014[2], supportingEmployeeDollarNetProfitQuantile2014[1], supportingEmployeeDollarNetProfitMean2014, supportingEmployeeDollarNetProfitCurCompany2014$supporting_employee_dollar_net_profit

, supportingEmployeeDollarNetProfitQuantile2015[3], supportingEmployeeDollarNetProfitQuantile2015[2], supportingEmployeeDollarNetProfitQuantile2015[1], supportingEmployeeDollarNetProfitMean2015, supportingEmployeeDollarNetProfitCurCompany2015$supporting_employee_dollar_net_profit

, supportingEmployeeDollarNetProfitQuantile2016[3], supportingEmployeeDollarNetProfitQuantile2016[2], supportingEmployeeDollarNetProfitQuantile2016[1], supportingEmployeeDollarNetProfitMean2016, supportingEmployeeDollarNetProfitCurCompany2016$supporting_employee_dollar_net_profit)



#Formula 20
#Page 32: Overall Productivity Measurement – Dollar Revenue/FTEs of Company’s People Plot
returnGraph8<-plotGraphType1("Revenue.per.Total.FTE.of.People", "Overall Productivity Measurement: \nDollar Revenue/FTEs of Company People")
plot(returnGraph8)
#Page 33: Overall Productivity Measurement – Dollar Revenue/FTEs of Company’s People Data
plotData("Overall Productivity Measurement: ","Dollar Revenue/FTEs of Company People", webCompanyName, 
overallProductivityDollarRevenueFteQuantile2011[3], overallProductivityDollarRevenueFteQuantile2011[2], overallProductivityDollarRevenueFteQuantile2011[1], overallProductivityDollarRevenueFteMean2011, overallProductivityDollarRevenueFteCurCompany2011$overall_productivity_dollar_revenue_fte, 

overallProductivityDollarRevenueFteQuantile2012[3], overallProductivityDollarRevenueFteQuantile2012[2], overallProductivityDollarRevenueFteQuantile2012[1], overallProductivityDollarRevenueFteMean2012, overallProductivityDollarRevenueFteCurCompany2012$overall_productivity_dollar_revenue_fte

, overallProductivityDollarRevenueFteQuantile2013[3], overallProductivityDollarRevenueFteQuantile2013[2], overallProductivityDollarRevenueFteQuantile2013[1], overallProductivityDollarRevenueFteMean2013, overallProductivityDollarRevenueFteCurCompany2013$overall_productivity_dollar_revenue_fte

, overallProductivityDollarRevenueFteQuantile2014[3], overallProductivityDollarRevenueFteQuantile2014[2], overallProductivityDollarRevenueFteQuantile2014[1], overallProductivityDollarRevenueFteMean2014, overallProductivityDollarRevenueFteCurCompany2014$overall_productivity_dollar_revenue_fte

, overallProductivityDollarRevenueFteQuantile2015[3], overallProductivityDollarRevenueFteQuantile2015[2], overallProductivityDollarRevenueFteQuantile2015[1], overallProductivityDollarRevenueFteMean2015, overallProductivityDollarRevenueFteCurCompany2015$overall_productivity_dollar_revenue_fte

, overallProductivityDollarRevenueFteQuantile2016[3], overallProductivityDollarRevenueFteQuantile2016[2], overallProductivityDollarRevenueFteQuantile2016[1], overallProductivityDollarRevenueFteMean2016, overallProductivityDollarRevenueFteCurCompany2016$overall_productivity_dollar_revenue_fte)


#Formula 21
#Page 34: Overall Productivity Measurement – Dollar Value Added/FTEs of Company’s People Plot
returnGraph8<-plotGraphType1("Value.Added.per.Total.FTE.of.People", "Overall Productivity Measurement: \nDollar Value Added/FTEs of Company People")
plot(returnGraph8)
#Page 35: Overall Productivity Measurement – Dollar Value Added/FTEs of Company’s People Data
plotData("Overall Productivity Measurement: ","Dollar Value Added/FTEs of Company People", webCompanyName, 
overallProductivityDollarValueAddedFteQuantile2011[3], overallProductivityDollarValueAddedFteQuantile2011[2], overallProductivityDollarValueAddedFteQuantile2011[1], overallProductivityDollarValueAddedFteMean2011, overallProductivityDollarValueAddedFteCurCompany2011$overall_productivity_dollar_value_added_fte, 

overallProductivityDollarValueAddedFteQuantile2012[3], overallProductivityDollarValueAddedFteQuantile2012[2], overallProductivityDollarValueAddedFteQuantile2012[1], overallProductivityDollarValueAddedFteMean2012, overallProductivityDollarValueAddedFteCurCompany2012$overall_productivity_dollar_value_added_fte

, overallProductivityDollarValueAddedFteQuantile2013[3], overallProductivityDollarValueAddedFteQuantile2013[2], overallProductivityDollarValueAddedFteQuantile2013[1], overallProductivityDollarValueAddedFteMean2013, overallProductivityDollarValueAddedFteCurCompany2013$overall_productivity_dollar_value_added_fte

, overallProductivityDollarValueAddedFteQuantile2014[3], overallProductivityDollarValueAddedFteQuantile2014[2], overallProductivityDollarValueAddedFteQuantile2014[1], overallProductivityDollarValueAddedFteMean2014, overallProductivityDollarValueAddedFteCurCompany2014$overall_productivity_dollar_value_added_fte

, overallProductivityDollarValueAddedFteQuantile2015[3], overallProductivityDollarValueAddedFteQuantile2015[2], overallProductivityDollarValueAddedFteQuantile2015[1], overallProductivityDollarValueAddedFteMean2015, overallProductivityDollarValueAddedFteCurCompany2015$overall_productivity_dollar_value_added_fte

, overallProductivityDollarValueAddedFteQuantile2016[3], overallProductivityDollarValueAddedFteQuantile2016[2], overallProductivityDollarValueAddedFteQuantile2016[1], overallProductivityDollarValueAddedFteMean2016, overallProductivityDollarValueAddedFteCurCompany2016$overall_productivity_dollar_value_added_fte)



#Formula 22
#Page 36: Overall Profitability Measurement – Dollar Net Profit /FTEs of  Company’s People Plot
returnGraph8<-plotGraphType1("Net.Profit.per.Total.FTE.of.People", "Overall Profitability Measurement: \nDollar Net Profit /FTEs of  Company People")
plot(returnGraph8)
#Page 37: Overall Profitability Measurement – Dollar Net Profit /FTEs of  Company’s People Data
plotData("Overall Profitability Measurement: ","Dollar Net Profit /FTEs of  Company People", webCompanyName, 
overallProductivityDollarNetProfitFteQuantile2011[3], overallProductivityDollarNetProfitFteQuantile2011[2], overallProductivityDollarNetProfitFteQuantile2011[1], overallProductivityDollarNetProfitFteMean2011, overallProductivityDollarNetProfitFteCurCompany2011$overall_productivity_dollar_net_profit_fte, 

overallProductivityDollarNetProfitFteQuantile2012[3], overallProductivityDollarNetProfitFteQuantile2012[2], overallProductivityDollarNetProfitFteQuantile2012[1], overallProductivityDollarNetProfitFteMean2012, overallProductivityDollarNetProfitFteCurCompany2012$overall_productivity_dollar_net_profit_fte

, overallProductivityDollarNetProfitFteQuantile2013[3], overallProductivityDollarNetProfitFteQuantile2013[2], overallProductivityDollarNetProfitFteQuantile2013[1], overallProductivityDollarNetProfitFteMean2013, overallProductivityDollarNetProfitFteCurCompany2013$overall_productivity_dollar_net_profit_fte

, overallProductivityDollarNetProfitFteQuantile2014[3], overallProductivityDollarNetProfitFteQuantile2014[2], overallProductivityDollarNetProfitFteQuantile2014[1], overallProductivityDollarNetProfitFteMean2014, overallProductivityDollarNetProfitFteCurCompany2014$overall_productivity_dollar_net_profit_fte

, overallProductivityDollarNetProfitFteQuantile2015[3], overallProductivityDollarNetProfitFteQuantile2015[2], overallProductivityDollarNetProfitFteQuantile2015[1], overallProductivityDollarNetProfitFteMean2015, overallProductivityDollarNetProfitFteCurCompany2015$overall_productivity_dollar_net_profit_fte

, overallProductivityDollarNetProfitFteQuantile2016[3], overallProductivityDollarNetProfitFteQuantile2016[2], overallProductivityDollarNetProfitFteQuantile2016[1], overallProductivityDollarNetProfitFteMean2016, overallProductivityDollarNetProfitFteCurCompany2016$overall_productivity_dollar_net_profit_fte)


#Formula 23
#Page 38: Project Management Productivity Measurement: Dollar Revenue/FTEs of Project Management Personnel Plot
returnGraph8<-plotGraphType1("Revenue.per.Hour.of.Field.Project.Management.Personnel", "Project Management Productivity Measurement: \nDollar Revenue/FTEs of Project Management Personnel")
plot(returnGraph8)
#Page 39: Project Management Productivity Measurement: Dollar Revenue/FTEs of Project Management Personnel Data
plotData("Project Management Productivity Measurement: ", "Dollar Revenue/FTEs of Project Management Personnel", webCompanyName, 
projectManagementDollarRevenuePersonnelFteQuantile2011[3], projectManagementDollarRevenuePersonnelFteQuantile2011[2], projectManagementDollarRevenuePersonnelFteQuantile2011[1], projectManagementDollarRevenuePersonnelFteMean2011, projectManagementDollarRevenuePersonnelFteCurCompany2011$project_management_dollar_revenue_fte, 

projectManagementDollarRevenuePersonnelFteQuantile2012[3], projectManagementDollarRevenuePersonnelFteQuantile2012[2], projectManagementDollarRevenuePersonnelFteQuantile2012[1], projectManagementDollarRevenuePersonnelFteMean2012, projectManagementDollarRevenuePersonnelFteCurCompany2012$project_management_dollar_revenue_fte

, projectManagementDollarRevenuePersonnelFteQuantile2013[3], projectManagementDollarRevenuePersonnelFteQuantile2013[2], projectManagementDollarRevenuePersonnelFteQuantile2013[1], projectManagementDollarRevenuePersonnelFteMean2013, projectManagementDollarRevenuePersonnelFteCurCompany2013$project_management_dollar_revenue_fte

, projectManagementDollarRevenuePersonnelFteQuantile2014[3], projectManagementDollarRevenuePersonnelFteQuantile2014[2], projectManagementDollarRevenuePersonnelFteQuantile2014[1], projectManagementDollarRevenuePersonnelFteMean2014, projectManagementDollarRevenuePersonnelFteCurCompany2014$project_management_dollar_revenue_fte

, projectManagementDollarRevenuePersonnelFteQuantile2015[3], projectManagementDollarRevenuePersonnelFteQuantile2015[2], projectManagementDollarRevenuePersonnelFteQuantile2015[1], projectManagementDollarRevenuePersonnelFteMean2015, projectManagementDollarRevenuePersonnelFteCurCompany2015$project_management_dollar_revenue_fte

, projectManagementDollarRevenuePersonnelFteQuantile2016[3], projectManagementDollarRevenuePersonnelFteQuantile2016[2], projectManagementDollarRevenuePersonnelFteQuantile2016[1], projectManagementDollarRevenuePersonnelFteMean2016, projectManagementDollarRevenuePersonnelFteCurCompany2016$project_management_dollar_revenue_fte)


#Formula 24
#Page 40 - Project Management Productivity Measurement: Dollar Value Added/FTEs of Project Management Plot
returnGraph8<-plotGraphType1("Value.Added.per.Hour.of.Field.Project.Management.Personnel", "Project Management Productivity Measurement: \nDollar Value Added/FTEs of Project Management")
plot(returnGraph8)
#Page 41 - Project Management Productivity Measurement: Dollar Value Added/FTEs of Project Management Data
plotData("Project Management Productivity Measurement: ", "Dollar Value Added/FTEs of Project Management", webCompanyName, 
projectManagementDollarValueAddedPersonnelFteQuantile2011[3], projectManagementDollarValueAddedPersonnelFteQuantile2011[2], projectManagementDollarValueAddedPersonnelFteQuantile2011[1], projectManagementDollarValueAddedPersonnelFteMean2011, projectManagementDollarValueAddedPersonnelFteCurCompany2011$project_management_dollar_value_added_fte, 

projectManagementDollarValueAddedPersonnelFteQuantile2012[3], projectManagementDollarValueAddedPersonnelFteQuantile2012[2], projectManagementDollarValueAddedPersonnelFteQuantile2012[1], projectManagementDollarValueAddedPersonnelFteMean2012, projectManagementDollarValueAddedPersonnelFteCurCompany2012$project_management_dollar_value_added_fte

, projectManagementDollarValueAddedPersonnelFteQuantile2013[3], projectManagementDollarValueAddedPersonnelFteQuantile2013[2], projectManagementDollarValueAddedPersonnelFteQuantile2013[1], projectManagementDollarValueAddedPersonnelFteMean2013, projectManagementDollarValueAddedPersonnelFteCurCompany2013$project_management_dollar_value_added_fte

, projectManagementDollarValueAddedPersonnelFteQuantile2014[3], projectManagementDollarValueAddedPersonnelFteQuantile2014[2], projectManagementDollarValueAddedPersonnelFteQuantile2014[1], projectManagementDollarValueAddedPersonnelFteMean2014, projectManagementDollarValueAddedPersonnelFteCurCompany2014$project_management_dollar_value_added_fte

, projectManagementDollarValueAddedPersonnelFteQuantile2015[3], projectManagementDollarValueAddedPersonnelFteQuantile2015[2], projectManagementDollarValueAddedPersonnelFteQuantile2015[1], projectManagementDollarValueAddedPersonnelFteMean2015, projectManagementDollarValueAddedPersonnelFteCurCompany2015$project_management_dollar_value_added_fte

, projectManagementDollarValueAddedPersonnelFteQuantile2016[3], projectManagementDollarValueAddedPersonnelFteQuantile2016[2], projectManagementDollarValueAddedPersonnelFteQuantile2016[1], projectManagementDollarValueAddedPersonnelFteMean2016, projectManagementDollarValueAddedPersonnelFteCurCompany2016$project_management_dollar_value_added_fte)


#Formula 25
#Page 42 - Project Management Profitability Measurement: Dollar Net Profit /FTEs of Project Management Personnel Plot
returnGraph9<-plotGraphType1("Net.Profit.per.Hour.of.Field.Project.Management.Personnel", "Project Management Profitability Measurement: \nDollar Net Profit /FTEs of Project Management Personnel")
plot(returnGraph9)
#Page 43 - Project Management Profitability Measurement: Dollar Net Profit /FTEs of Project Management Personnel Data
plotData("Project Management Profitability Measurement: ","Dollar Net Profit /FTEs of Project Management Personnel", webCompanyName, 
projectManagementDollarNetProfitPersonnelFteQuantile2011[3], projectManagementDollarNetProfitPersonnelFteQuantile2011[2], projectManagementDollarNetProfitPersonnelFteQuantile2011[1], projectManagementDollarNetProfitPersonnelFteMean2011, projectManagementDollarNetProfitPersonnelFteCurCompany2011$project_management_dollar_net_profit_fte, 

projectManagementDollarNetProfitPersonnelFteQuantile2012[3], projectManagementDollarNetProfitPersonnelFteQuantile2012[2], projectManagementDollarNetProfitPersonnelFteQuantile2012[1], projectManagementDollarNetProfitPersonnelFteMean2012, projectManagementDollarNetProfitPersonnelFteCurCompany2012$project_management_dollar_net_profit_fte

, projectManagementDollarNetProfitPersonnelFteQuantile2013[3], projectManagementDollarNetProfitPersonnelFteQuantile2013[2], projectManagementDollarNetProfitPersonnelFteQuantile2013[1], projectManagementDollarNetProfitPersonnelFteMean2013, projectManagementDollarNetProfitPersonnelFteCurCompany2013$project_management_dollar_net_profit_fte

, projectManagementDollarNetProfitPersonnelFteQuantile2014[3], projectManagementDollarNetProfitPersonnelFteQuantile2014[2], projectManagementDollarNetProfitPersonnelFteQuantile2014[1], projectManagementDollarNetProfitPersonnelFteMean2014, projectManagementDollarNetProfitPersonnelFteCurCompany2014$project_management_dollar_net_profit_fte

, projectManagementDollarNetProfitPersonnelFteQuantile2015[3], projectManagementDollarNetProfitPersonnelFteQuantile2015[2], projectManagementDollarNetProfitPersonnelFteQuantile2015[1], projectManagementDollarNetProfitPersonnelFteMean2015, projectManagementDollarNetProfitPersonnelFteCurCompany2015$project_management_dollar_net_profit_fte

, projectManagementDollarNetProfitPersonnelFteQuantile2016[3], projectManagementDollarNetProfitPersonnelFteQuantile2016[2], projectManagementDollarNetProfitPersonnelFteQuantile2016[1], projectManagementDollarNetProfitPersonnelFteMean2016, projectManagementDollarNetProfitPersonnelFteCurCompany2016$project_management_dollar_net_profit_fte)


#Formula 26
#Page 44 - Craft Worker Productivity Measurement: Dollar Revenue/ FTEs of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Revenue.per.Expended.Man.FTE.of.Bargaining.Unit.Employees", "Craft Worker Productivity Measurement: \nDollar Revenue/ FTEs of Bargaining Unit Employees")
plot(returnGraph9)
#Page 45 - Craft Worker Productivity Measurement: Dollar Revenue/ FTEs of Bargaining Unit Employees Data
plotData("Craft Worker Productivity Measurement: ","Dollar Revenue/ FTEs of Bargaining Unit Employees", webCompanyName, 
craftWorkerDollarRevenueFteQuantile2011[3], craftWorkerDollarRevenueFteQuantile2011[2], craftWorkerDollarRevenueFteQuantile2011[1], craftWorkerDollarRevenueFteMean2011, craftWorkerDollarRevenueFteCurCompany2011$craft_worker_dollar_revenue_fte, 

craftWorkerDollarRevenueFteQuantile2012[3], craftWorkerDollarRevenueFteQuantile2012[2], craftWorkerDollarRevenueFteQuantile2012[1], craftWorkerDollarRevenueFteMean2012, craftWorkerDollarRevenueFteCurCompany2012$craft_worker_dollar_revenue_fte

, craftWorkerDollarRevenueFteQuantile2013[3], craftWorkerDollarRevenueFteQuantile2013[2], craftWorkerDollarRevenueFteQuantile2013[1], craftWorkerDollarRevenueFteMean2013, craftWorkerDollarRevenueFteCurCompany2013$craft_worker_dollar_revenue_fte

, craftWorkerDollarRevenueFteQuantile2014[3], craftWorkerDollarRevenueFteQuantile2014[2], craftWorkerDollarRevenueFteQuantile2014[1], craftWorkerDollarRevenueFteMean2014, craftWorkerDollarRevenueFteCurCompany2014$craft_worker_dollar_revenue_fte

, craftWorkerDollarRevenueFteQuantile2015[3], craftWorkerDollarRevenueFteQuantile2015[2], craftWorkerDollarRevenueFteQuantile2015[1], craftWorkerDollarRevenueFteMean2015, craftWorkerDollarRevenueFteCurCompany2015$craft_worker_dollar_revenue_fte

, craftWorkerDollarRevenueFteQuantile2016[3], craftWorkerDollarRevenueFteQuantile2016[2], craftWorkerDollarRevenueFteQuantile2016[1], craftWorkerDollarRevenueFteMean2016, craftWorkerDollarRevenueFteCurCompany2016$craft_worker_dollar_revenue_fte)


#Formula 27
#Page 46 - Craft Worker Productivity Measurement: Dollar Value Added/ FTEs of Bargaining Unit Plot
returnGraph9<-plotGraphType1("Value.Added.per.Expended.Man.FTE.of.Bargaining.Unit.Employees", "Craft Worker Productivity Measurement: \nDollar Value Added/ FTEs of Bargaining Unit")
plot(returnGraph9)
#Page 47 - Craft Worker Productivity Measurement: Dollar Value Added/ FTEs of Bargaining Unit Data
plotData("Craft Worker Productivity Measurement: ","Dollar Value Added/ FTEs of Bargaining Unit Employees", webCompanyName, 
craftWorkerDollarValueAddedFteQuantile2011[3], craftWorkerDollarValueAddedFteQuantile2011[2], craftWorkerDollarValueAddedFteQuantile2011[1], craftWorkerDollarValueAddedFteMean2011, craftWorkerDollarValueAddedFteCurCompany2011$craft_worker_dollar_value_added_fte, 

craftWorkerDollarValueAddedFteQuantile2012[3], craftWorkerDollarValueAddedFteQuantile2012[2], craftWorkerDollarValueAddedFteQuantile2012[1], craftWorkerDollarValueAddedFteMean2012, craftWorkerDollarValueAddedFteCurCompany2012$craft_worker_dollar_value_added_fte

, craftWorkerDollarValueAddedFteQuantile2013[3], craftWorkerDollarValueAddedFteQuantile2013[2], craftWorkerDollarValueAddedFteQuantile2013[1], craftWorkerDollarValueAddedFteMean2013, craftWorkerDollarValueAddedFteCurCompany2013$craft_worker_dollar_value_added_fte

, craftWorkerDollarValueAddedFteQuantile2014[3], craftWorkerDollarValueAddedFteQuantile2014[2], craftWorkerDollarValueAddedFteQuantile2014[1], craftWorkerDollarValueAddedFteMean2014, craftWorkerDollarValueAddedFteCurCompany2014$craft_worker_dollar_value_added_fte

, craftWorkerDollarValueAddedFteQuantile2015[3], craftWorkerDollarValueAddedFteQuantile2015[2], craftWorkerDollarValueAddedFteQuantile2015[1], craftWorkerDollarValueAddedFteMean2015, craftWorkerDollarValueAddedFteCurCompany2015$craft_worker_dollar_value_added_fte

, craftWorkerDollarValueAddedFteQuantile2016[3], craftWorkerDollarValueAddedFteQuantile2016[2], craftWorkerDollarValueAddedFteQuantile2016[1], craftWorkerDollarValueAddedFteMean2016, craftWorkerDollarValueAddedFteCurCompany2016$craft_worker_dollar_value_added_fte)


#Formula 28
#Page 48 - Craft Worker Profitability Measurement: Dollar Net Profit / FTEs of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Net.Profit.per.Expended.Man.FTE.of.Bargaining.Unit.Employees", "Craft Worker Profitability Measurement: \nDollar Net Profit / FTEs of Bargaining Unit Employees")
plot(returnGraph9)
#Page 49 - Craft Worker Profitability Measurement: Dollar Net Profit / FTEs of Bargaining Unit Employees Data
plotData("Craft Worker Profitability Measurement: ","Dollar Net Profit / FTEs of Bargaining Unit Employees", webCompanyName, 
craftWorkerDollarNetProfitFteQuantile2011[3], craftWorkerDollarNetProfitFteQuantile2011[2], craftWorkerDollarNetProfitFteQuantile2011[1], craftWorkerDollarNetProfitFteMean2011, craftWorkerDollarNetProfitFteCurCompany2011$craft_worker_dollar_net_profit_fte, 

craftWorkerDollarNetProfitFteQuantile2012[3], craftWorkerDollarNetProfitFteQuantile2012[2], craftWorkerDollarNetProfitFteQuantile2012[1], craftWorkerDollarNetProfitFteMean2012, craftWorkerDollarNetProfitFteCurCompany2012$craft_worker_dollar_net_profit_fte

, craftWorkerDollarNetProfitFteQuantile2013[3], craftWorkerDollarNetProfitFteQuantile2013[2], craftWorkerDollarNetProfitFteQuantile2013[1], craftWorkerDollarNetProfitFteMean2013, craftWorkerDollarNetProfitFteCurCompany2013$craft_worker_dollar_net_profit_fte

, craftWorkerDollarNetProfitFteQuantile2014[3], craftWorkerDollarNetProfitFteQuantile2014[2], craftWorkerDollarNetProfitFteQuantile2014[1], craftWorkerDollarNetProfitFteMean2014, craftWorkerDollarNetProfitFteCurCompany2014$craft_worker_dollar_net_profit_fte

, craftWorkerDollarNetProfitFteQuantile2015[3], craftWorkerDollarNetProfitFteQuantile2015[2], craftWorkerDollarNetProfitFteQuantile2015[1], craftWorkerDollarNetProfitFteMean2015, craftWorkerDollarNetProfitFteCurCompany2015$craft_worker_dollar_net_profit_fte

, craftWorkerDollarNetProfitFteQuantile2016[3], craftWorkerDollarNetProfitFteQuantile2016[2], craftWorkerDollarNetProfitFteQuantile2016[1], craftWorkerDollarNetProfitFteMean2016, craftWorkerDollarNetProfitFteCurCompany2016$craft_worker_dollar_net_profit_fte)


#Formula 29
#Page 50 - Supporting Employees Productivity Measurement: Dollar Revenue/ FTEs of Supporting Employees Plot
returnGraph9<-plotGraphType1("Revenue.per.FTE.of.Supporting.Employees", "Supporting Employees Productivity Measurement: \nDollar Revenue/ FTEs of Supporting Employees")
plot(returnGraph9)
#Page 51 - Supporting Employees Productivity Measurement: Dollar Revenue/ FTEs of Supporting Employees Data
plotData("Supporting Employees Productivity Measurement: ","Dollar Revenue/ FTEs of Supporting Employees", webCompanyName, 
supportingEmployeeDollarRevenueFteQuantile2011[3], supportingEmployeeDollarRevenueFteQuantile2011[2], supportingEmployeeDollarRevenueFteQuantile2011[1], supportingEmployeeDollarRevenueFteMean2011, supportingEmployeeDollarRevenueFteCurCompany2011$supporting_employee_dollar_revenue_fte, 

supportingEmployeeDollarRevenueFteQuantile2012[3], supportingEmployeeDollarRevenueFteQuantile2012[2], supportingEmployeeDollarRevenueFteQuantile2012[1], supportingEmployeeDollarRevenueFteMean2012, supportingEmployeeDollarRevenueFteCurCompany2012$supporting_employee_dollar_revenue_fte

, supportingEmployeeDollarRevenueFteQuantile2013[3], supportingEmployeeDollarRevenueFteQuantile2013[2], supportingEmployeeDollarRevenueFteQuantile2013[1], supportingEmployeeDollarRevenueFteMean2013, supportingEmployeeDollarRevenueFteCurCompany2013$supporting_employee_dollar_revenue_fte

, supportingEmployeeDollarRevenueFteQuantile2014[3], supportingEmployeeDollarRevenueFteQuantile2014[2], supportingEmployeeDollarRevenueFteQuantile2014[1], supportingEmployeeDollarRevenueFteMean2014, supportingEmployeeDollarRevenueFteCurCompany2014$supporting_employee_dollar_revenue_fte

, supportingEmployeeDollarRevenueFteQuantile2015[3], supportingEmployeeDollarRevenueFteQuantile2015[2], supportingEmployeeDollarRevenueFteQuantile2015[1], supportingEmployeeDollarRevenueFteMean2015, supportingEmployeeDollarRevenueFteCurCompany2015$supporting_employee_dollar_revenue_fte

, supportingEmployeeDollarRevenueFteQuantile2016[3], supportingEmployeeDollarRevenueFteQuantile2016[2], supportingEmployeeDollarRevenueFteQuantile2016[1], supportingEmployeeDollarRevenueFteMean2016, supportingEmployeeDollarRevenueFteCurCompany2016$supporting_employee_dollar_revenue_fte)


#Formula 30
#Page 52 - Supporting Employees Productivity Measurement: Dollar Value Added/ FTEs of Supporting Employees Plot
returnGraph9<-plotGraphType1("Value.Added.per.FTE.of.Supporting.Employees", "Supporting Employees Productivity Measurement: \nDollar Value Added/ FTEs of Supporting Employees")
plot(returnGraph9)
#Page 53 - Supporting Employees Productivity Measurement: Dollar Value Added/ FTEs of Supporting Employees Data
plotData("Supporting Employees Productivity Measurement: ","Dollar Value Added/ FTEs of Supporting Employees", webCompanyName, 
supportingEmployeeDollarValueAddedFteQuantile2011[3], supportingEmployeeDollarValueAddedFteQuantile2011[2], supportingEmployeeDollarValueAddedFteQuantile2011[1], supportingEmployeeDollarValueAddedFteMean2011, supportingEmployeeDollarValueAddedFteCurCompany2011$supporting_employee_dollar_value_added_fte, 

supportingEmployeeDollarValueAddedFteQuantile2012[3], supportingEmployeeDollarValueAddedFteQuantile2012[2], supportingEmployeeDollarValueAddedFteQuantile2012[1], supportingEmployeeDollarValueAddedFteMean2012, supportingEmployeeDollarValueAddedFteCurCompany2012$supporting_employee_dollar_value_added_fte

, supportingEmployeeDollarValueAddedFteQuantile2013[3], supportingEmployeeDollarValueAddedFteQuantile2013[2], supportingEmployeeDollarValueAddedFteQuantile2013[1], supportingEmployeeDollarValueAddedFteMean2013, supportingEmployeeDollarValueAddedFteCurCompany2013$supporting_employee_dollar_value_added_fte

, supportingEmployeeDollarValueAddedFteQuantile2014[3], supportingEmployeeDollarValueAddedFteQuantile2014[2], supportingEmployeeDollarValueAddedFteQuantile2014[1], supportingEmployeeDollarValueAddedFteMean2014, supportingEmployeeDollarValueAddedFteCurCompany2014$supporting_employee_dollar_value_added_fte

, supportingEmployeeDollarValueAddedFteQuantile2015[3], supportingEmployeeDollarValueAddedFteQuantile2015[2], supportingEmployeeDollarValueAddedFteQuantile2015[1], supportingEmployeeDollarValueAddedFteMean2015, supportingEmployeeDollarValueAddedFteCurCompany2015$supporting_employee_dollar_value_added_fte

, supportingEmployeeDollarValueAddedFteQuantile2016[3], supportingEmployeeDollarValueAddedFteQuantile2016[2], supportingEmployeeDollarValueAddedFteQuantile2016[1], supportingEmployeeDollarValueAddedFteMean2016, supportingEmployeeDollarValueAddedFteCurCompany2016$supporting_employee_dollar_value_added_fte)


#Formula 31
#Page 54 - Supporting Employees Profitability Measurement: Dollar Net Profit / FTEs of Supporting Employees Plot
returnGraph9<-plotGraphType1("Net.Profit.per.FTE.of.Supporting.Employees", "Supporting Employees Profitability Measurement: \nDollar Net Profit / FTEs of Supporting Employees")
plot(returnGraph9)
#Page 55 - Supporting Employees Profitability Measurement: Dollar Net Profit / FTEs of Supporting Employees Data
plotData("Supporting Employees Profitability Measurement: ","Dollar Net Profit / FTEs of Supporting Employees", webCompanyName, 
supportingEmployeeDollarNetProfitFteQuantile2011[3], supportingEmployeeDollarNetProfitFteQuantile2011[2], supportingEmployeeDollarNetProfitFteQuantile2011[1], supportingEmployeeDollarNetProfitFteMean2011, supportingEmployeeDollarNetProfitFteCurCompany2011$supporting_employee_dollar_net_profit_added_fte, 

supportingEmployeeDollarNetProfitFteQuantile2012[3], supportingEmployeeDollarNetProfitFteQuantile2012[2], supportingEmployeeDollarNetProfitFteQuantile2012[1], supportingEmployeeDollarNetProfitFteMean2012, supportingEmployeeDollarNetProfitFteCurCompany2012$supporting_employee_dollar_net_profit_added_fte

, supportingEmployeeDollarNetProfitFteQuantile2013[3], supportingEmployeeDollarNetProfitFteQuantile2013[2], supportingEmployeeDollarNetProfitFteQuantile2013[1], supportingEmployeeDollarNetProfitFteMean2013, supportingEmployeeDollarNetProfitFteCurCompany2013$supporting_employee_dollar_net_profit_added_fte

, supportingEmployeeDollarNetProfitFteQuantile2014[3], supportingEmployeeDollarNetProfitFteQuantile2014[2], supportingEmployeeDollarNetProfitFteQuantile2014[1], supportingEmployeeDollarNetProfitFteMean2014, supportingEmployeeDollarNetProfitFteCurCompany2014$supporting_employee_dollar_net_profit_added_fte

, supportingEmployeeDollarNetProfitFteQuantile2015[3], supportingEmployeeDollarNetProfitFteQuantile2015[2], supportingEmployeeDollarNetProfitFteQuantile2015[1], supportingEmployeeDollarNetProfitFteMean2015, supportingEmployeeDollarNetProfitFteCurCompany2015$supporting_employee_dollar_net_profit_added_fte

, supportingEmployeeDollarNetProfitFteQuantile2016[3], supportingEmployeeDollarNetProfitFteQuantile2016[2], supportingEmployeeDollarNetProfitFteQuantile2016[1], supportingEmployeeDollarNetProfitFteMean2016, supportingEmployeeDollarNetProfitFteCurCompany2016$supporting_employee_dollar_net_profit_added_fte)

#Transition 
plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj8,1,1,1000,1000)

#Formula 32
#Page 56 - Overall Cost Effectiveness – Dollar Revenue/Cost of Company’s People Plot
returnGraph9<-plotGraphType1("Revenue.per.Total.Cost.of.People", "Overall Cost Effectiveness: \nDollar Revenue/Cost of Company People")
plot(returnGraph9)
#Page 57 - Overall Cost Effectiveness – Dollar Revenue/Cost of Company’s People Data
plotData("Overall Cost Effectiveness: ","Dollar Revenue/Cost of Company People", webCompanyName, 
overallCostEffectivenessDollarRevenueQuantile2011[3], overallCostEffectivenessDollarRevenueQuantile2011[2], overallCostEffectivenessDollarRevenueQuantile2011[1], overallCostEffectivenessDollarRevenueMean2011, overallCostEffectivenessDollarRevenueCurCompany2011$overall_cost_dollar_revenue_cost, 

overallCostEffectivenessDollarRevenueQuantile2012[3], overallCostEffectivenessDollarRevenueQuantile2012[2], overallCostEffectivenessDollarRevenueQuantile2012[1], overallCostEffectivenessDollarRevenueMean2012, overallCostEffectivenessDollarRevenueCurCompany2012$overall_cost_dollar_revenue_cost

, overallCostEffectivenessDollarRevenueQuantile2013[3], overallCostEffectivenessDollarRevenueQuantile2013[2], overallCostEffectivenessDollarRevenueQuantile2013[1], overallCostEffectivenessDollarRevenueMean2013, overallCostEffectivenessDollarRevenueCurCompany2013$overall_cost_dollar_revenue_cost

, overallCostEffectivenessDollarRevenueQuantile2014[3], overallCostEffectivenessDollarRevenueQuantile2014[2], overallCostEffectivenessDollarRevenueQuantile2014[1], overallCostEffectivenessDollarRevenueMean2014, overallCostEffectivenessDollarRevenueCurCompany2014$overall_cost_dollar_revenue_cost

, overallCostEffectivenessDollarRevenueQuantile2015[3], overallCostEffectivenessDollarRevenueQuantile2015[2], overallCostEffectivenessDollarRevenueQuantile2015[1], overallCostEffectivenessDollarRevenueMean2015, overallCostEffectivenessDollarRevenueCurCompany2015$overall_cost_dollar_revenue_cost

, overallCostEffectivenessDollarRevenueQuantile2016[3], overallCostEffectivenessDollarRevenueQuantile2016[2], overallCostEffectivenessDollarRevenueQuantile2016[1], overallCostEffectivenessDollarRevenueMean2016, overallCostEffectivenessDollarRevenueCurCompany2016$overall_cost_dollar_revenue_cost)


#Formula 33
#Page 58 - Overall Cost Effectiveness – Dollar Value Added/ Cost of Company’s People Plot
returnGraph9<-plotGraphType1("Value.Added.per.Total.Cost.of.People", "Overall Cost Effectiveness: \nDollar Value Added/ Cost of Company People")
plot(returnGraph9)
#Page 59 - Overall Cost Effectiveness – Dollar Value Added/ Cost of Company’s People Data
plotData("Overall Cost Effectiveness: ","Dollar Value Added/ Cost of Company People", webCompanyName, 
overallCostEffectivenessDollarValueAddedQuantile2011[3], overallCostEffectivenessDollarValueAddedQuantile2011[2], overallCostEffectivenessDollarValueAddedQuantile2011[1], overallCostEffectivenessDollarValueAddedMean2011, overallCostEffectivenessDollarValueAddedCurCompany2011$overall_cost_dollar_value_added_cost, 

overallCostEffectivenessDollarValueAddedQuantile2012[3], overallCostEffectivenessDollarValueAddedQuantile2012[2], overallCostEffectivenessDollarValueAddedQuantile2012[1], overallCostEffectivenessDollarValueAddedMean2012, overallCostEffectivenessDollarValueAddedCurCompany2012$overall_cost_dollar_value_added_cost

, overallCostEffectivenessDollarValueAddedQuantile2013[3], overallCostEffectivenessDollarValueAddedQuantile2013[2], overallCostEffectivenessDollarValueAddedQuantile2013[1], overallCostEffectivenessDollarValueAddedMean2013, overallCostEffectivenessDollarValueAddedCurCompany2013$overall_cost_dollar_value_added_cost

, overallCostEffectivenessDollarValueAddedQuantile2014[3], overallCostEffectivenessDollarValueAddedQuantile2014[2], overallCostEffectivenessDollarValueAddedQuantile2014[1], overallCostEffectivenessDollarValueAddedMean2014, overallCostEffectivenessDollarValueAddedCurCompany2014$overall_cost_dollar_value_added_cost

, overallCostEffectivenessDollarValueAddedQuantile2015[3], overallCostEffectivenessDollarValueAddedQuantile2015[2], overallCostEffectivenessDollarValueAddedQuantile2015[1], overallCostEffectivenessDollarValueAddedMean2015, overallCostEffectivenessDollarValueAddedCurCompany2015$overall_cost_dollar_value_added_cost

, overallCostEffectivenessDollarValueAddedQuantile2016[3], overallCostEffectivenessDollarValueAddedQuantile2016[2], overallCostEffectivenessDollarValueAddedQuantile2016[1], overallCostEffectivenessDollarValueAddedMean2016, overallCostEffectivenessDollarValueAddedCurCompany2016$overall_cost_dollar_value_added_cost)


#Formula 34
#Page 60 - Overall Cost Effectiveness – Dollar Net Profit / Cost of Company’s People Plot
returnGraph9<-plotGraphType1("Net.Profit.per.Total.Cost.of.People", "Overall Cost Effectiveness:  \nDollar Net Profit / Cost of Company People")
plot(returnGraph9)
#Page 61 - Overall Cost Effectiveness – Dollar Net Profit / Cost of Company’s People Data
plotData("Overall Cost Effectiveness: ", "Dollar Net Profit / Cost of Company People", webCompanyName, 
overallCostEffectivenessDollarNetProfitQuantile2011[3], overallCostEffectivenessDollarNetProfitQuantile2011[2], overallCostEffectivenessDollarNetProfitQuantile2011[1], overallCostEffectivenessDollarNetProfitMean2011, overallCostEffectivenessDollarNetProfitCurCompany2011$overall_cost_dollar_net_profit_cost, 

overallCostEffectivenessDollarNetProfitQuantile2012[3], overallCostEffectivenessDollarNetProfitQuantile2012[2], overallCostEffectivenessDollarNetProfitQuantile2012[1], overallCostEffectivenessDollarNetProfitMean2012, overallCostEffectivenessDollarNetProfitCurCompany2012$overall_cost_dollar_net_profit_cost

, overallCostEffectivenessDollarNetProfitQuantile2013[3], overallCostEffectivenessDollarNetProfitQuantile2013[2], overallCostEffectivenessDollarNetProfitQuantile2013[1], overallCostEffectivenessDollarNetProfitMean2013, overallCostEffectivenessDollarNetProfitCurCompany2013$overall_cost_dollar_net_profit_cost

, overallCostEffectivenessDollarNetProfitQuantile2014[3], overallCostEffectivenessDollarNetProfitQuantile2014[2], overallCostEffectivenessDollarNetProfitQuantile2014[1], overallCostEffectivenessDollarNetProfitMean2014, overallCostEffectivenessDollarNetProfitCurCompany2014$overall_cost_dollar_net_profit_cost

, overallCostEffectivenessDollarNetProfitQuantile2015[3], overallCostEffectivenessDollarNetProfitQuantile2015[2], overallCostEffectivenessDollarNetProfitQuantile2015[1], overallCostEffectivenessDollarNetProfitMean2015, overallCostEffectivenessDollarNetProfitCurCompany2015$overall_cost_dollar_net_profit_cost

, overallCostEffectivenessDollarNetProfitQuantile2016[3], overallCostEffectivenessDollarNetProfitQuantile2016[2], overallCostEffectivenessDollarNetProfitQuantile2016[1], overallCostEffectivenessDollarNetProfitMean2016, overallCostEffectivenessDollarNetProfitCurCompany2016$overall_cost_dollar_net_profit_cost)


#Formula 35
#Page 62 - Project Management Cost Effectiveness: Dollar Revenue/ Cost of Project Management Personnel Plot
returnGraph9<-plotGraphType1("Revenue.per.Cost.of.Field.Project.Management.Personnel", "Project Management Cost Effectiveness: \nDollar Revenue/ Cost of Project Management Personnel")
plot(returnGraph9)
#Page 63 - Project Management Cost Effectiveness: Dollar Revenue/ Cost of Project Management Personnel Data
plotData("Project Management Cost Effectiveness: ", "Dollar Revenue/ Cost of Project Management Personnel", webCompanyName, 
projectManagementCostDollarRevenueQuantile2011[3], projectManagementCostDollarRevenueQuantile2011[2], projectManagementCostDollarRevenueQuantile2011[1], projectManagementCostDollarRevenueMean2011, projectManagementCostDollarRevenueCurCompany2011$project_management_dollar_revenue_cost, 

projectManagementCostDollarRevenueQuantile2012[3], projectManagementCostDollarRevenueQuantile2012[2], projectManagementCostDollarRevenueQuantile2012[1], projectManagementCostDollarRevenueMean2012, projectManagementCostDollarRevenueCurCompany2012$project_management_dollar_revenue_cost

, projectManagementCostDollarRevenueQuantile2013[3], projectManagementCostDollarRevenueQuantile2013[2], projectManagementCostDollarRevenueQuantile2013[1], projectManagementCostDollarRevenueMean2013, projectManagementCostDollarRevenueCurCompany2013$project_management_dollar_revenue_cost

, projectManagementCostDollarRevenueQuantile2014[3], projectManagementCostDollarRevenueQuantile2014[2], projectManagementCostDollarRevenueQuantile2014[1], projectManagementCostDollarRevenueMean2014, projectManagementCostDollarRevenueCurCompany2014$project_management_dollar_revenue_cost

, projectManagementCostDollarRevenueQuantile2015[3], projectManagementCostDollarRevenueQuantile2015[2], projectManagementCostDollarRevenueQuantile2015[1], projectManagementCostDollarRevenueMean2015, projectManagementCostDollarRevenueCurCompany2015$project_management_dollar_revenue_cost

, projectManagementCostDollarRevenueQuantile2016[3], projectManagementCostDollarRevenueQuantile2016[2], projectManagementCostDollarRevenueQuantile2016[1], projectManagementCostDollarRevenueMean2016, projectManagementCostDollarRevenueCurCompany2016$project_management_dollar_revenue_cost)


#Formula 36
#Page 64 - Project Management Cost Effectiveness: Dollar Value Added/ Cost of Project Management Personnel Plot
returnGraph9<-plotGraphType1("Value.Added.per.Cost.of.Field.Project.Management.Personnel", "Project Management Cost Effectiveness: \nDollar Value Added/ Cost of Project Management Personnel")
plot(returnGraph9)
#Page 65 - Project Management Cost Effectiveness: Dollar Value Added/ Cost of Project Management Personnel Data
plotData("Project Management Cost Effectiveness: ", "Dollar Value Added/ Cost of Project Management Personnel", webCompanyName, 
projectManagementCostDollarValueAddedQuantile2011[3], projectManagementCostDollarValueAddedQuantile2011[2], projectManagementCostDollarValueAddedQuantile2011[1], projectManagementCostDollarValueAddedMean2011, projectManagementCostDollarValueAddedCurCompany2011$project_management_dollar_value_added_cost, 

projectManagementCostDollarValueAddedQuantile2012[3], projectManagementCostDollarValueAddedQuantile2012[2], projectManagementCostDollarValueAddedQuantile2012[1], projectManagementCostDollarValueAddedMean2012, projectManagementCostDollarValueAddedCurCompany2012$project_management_dollar_value_added_cost

, projectManagementCostDollarValueAddedQuantile2013[3], projectManagementCostDollarValueAddedQuantile2013[2], projectManagementCostDollarValueAddedQuantile2013[1], projectManagementCostDollarValueAddedMean2013, projectManagementCostDollarValueAddedCurCompany2013$project_management_dollar_value_added_cost

, projectManagementCostDollarValueAddedQuantile2014[3], projectManagementCostDollarValueAddedQuantile2014[2], projectManagementCostDollarValueAddedQuantile2014[1], projectManagementCostDollarValueAddedMean2014, projectManagementCostDollarValueAddedCurCompany2014$project_management_dollar_value_added_cost

, projectManagementCostDollarValueAddedQuantile2015[3], projectManagementCostDollarValueAddedQuantile2015[2], projectManagementCostDollarValueAddedQuantile2015[1], projectManagementCostDollarValueAddedMean2015, projectManagementCostDollarValueAddedCurCompany2015$project_management_dollar_value_added_cost

, projectManagementCostDollarValueAddedQuantile2016[3], projectManagementCostDollarValueAddedQuantile2016[2], projectManagementCostDollarValueAddedQuantile2016[1], projectManagementCostDollarValueAddedMean2016, projectManagementCostDollarValueAddedCurCompany2016$project_management_dollar_value_added_cost)


#Formula 37
#Page 66 - Project Management Cost Effectiveness: Dollar Net Profit / Cost of Project Management Personnel Plot
returnGraph9<-plotGraphType1("Net.Profit.per.Cost.of.Field.Project.Management.Personnel", "Project Management Cost Effectiveness: \nDollar Net Profit / Cost of Project Management Personnel")
plot(returnGraph9)
#Page 67 - Project Management Cost Effectiveness: Dollar Net Profit / Cost of Project Management Personnel Data
plotData("Project Management Cost Effectiveness: ", "Dollar Net Profit / Cost of Project Management Personnel", webCompanyName, 
projectManagementCostDollarNetProfitQuantile2011[3], projectManagementCostDollarNetProfitQuantile2011[2], projectManagementCostDollarNetProfitQuantile2011[1], projectManagementCostDollarNetProfitMean2011, projectManagementCostDollarNetProfitCurCompany2011$project_management_dollar_net_profit_cost, 

projectManagementCostDollarNetProfitQuantile2012[3], projectManagementCostDollarNetProfitQuantile2012[2], projectManagementCostDollarNetProfitQuantile2012[1], projectManagementCostDollarNetProfitMean2012, projectManagementCostDollarNetProfitCurCompany2012$project_management_dollar_net_profit_cost

, projectManagementCostDollarNetProfitQuantile2013[3], projectManagementCostDollarNetProfitQuantile2013[2], projectManagementCostDollarNetProfitQuantile2013[1], projectManagementCostDollarNetProfitMean2013, projectManagementCostDollarNetProfitCurCompany2013$project_management_dollar_net_profit_cost

, projectManagementCostDollarNetProfitQuantile2014[3], projectManagementCostDollarNetProfitQuantile2014[2], projectManagementCostDollarNetProfitQuantile2014[1], projectManagementCostDollarNetProfitMean2014, projectManagementCostDollarNetProfitCurCompany2014$project_management_dollar_net_profit_cost

, projectManagementCostDollarNetProfitQuantile2015[3], projectManagementCostDollarNetProfitQuantile2015[2], projectManagementCostDollarNetProfitQuantile2015[1], projectManagementCostDollarNetProfitMean2015, projectManagementCostDollarNetProfitCurCompany2015$project_management_dollar_net_profit_cost

, projectManagementCostDollarNetProfitQuantile2016[3], projectManagementCostDollarNetProfitQuantile2016[2], projectManagementCostDollarNetProfitQuantile2016[1], projectManagementCostDollarNetProfitMean2016, projectManagementCostDollarNetProfitCurCompany2016$project_management_dollar_net_profit_cost)


#Formula 38
#Page 68 - Craft Worker Cost Effectiveness: Dollar Revenue/ Cost of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Revenue.per.Cost.of.Bargaining.Unit.Employees", "Craft Worker Cost Effectiveness: \nDollar Revenue/ Cost of Bargaining Unit Employees")
plot(returnGraph9)
#Page 69 - Craft Worker Cost Effectiveness: Dollar Revenue/ Cost of Bargaining Unit Employees Data
plotData("Craft Worker Cost Effectiveness: ", "Dollar Revenue/ Cost of Bargaining Unit Employees", webCompanyName, 
craftWorkerCostEffectDollarRevenueQuantile2011[3], craftWorkerCostEffectDollarRevenueQuantile2011[2], craftWorkerCostEffectDollarRevenueQuantile2011[1], craftWorkerCostEffectDollarRevenueMean2011, craftWorkerCostEffectDollarRevenueCurCompany2011$craft_worker_dollar_revenue_cost, 

craftWorkerCostEffectDollarRevenueQuantile2012[3], craftWorkerCostEffectDollarRevenueQuantile2012[2], craftWorkerCostEffectDollarRevenueQuantile2012[1], craftWorkerCostEffectDollarRevenueMean2012, craftWorkerCostEffectDollarRevenueCurCompany2012$craft_worker_dollar_revenue_cost

, craftWorkerCostEffectDollarRevenueQuantile2013[3], craftWorkerCostEffectDollarRevenueQuantile2013[2], craftWorkerCostEffectDollarRevenueQuantile2013[1], craftWorkerCostEffectDollarRevenueMean2013, craftWorkerCostEffectDollarRevenueCurCompany2013$craft_worker_dollar_revenue_cost

, craftWorkerCostEffectDollarRevenueQuantile2014[3], craftWorkerCostEffectDollarRevenueQuantile2014[2], craftWorkerCostEffectDollarRevenueQuantile2014[1], craftWorkerCostEffectDollarRevenueMean2014, craftWorkerCostEffectDollarRevenueCurCompany2014$craft_worker_dollar_revenue_cost

, craftWorkerCostEffectDollarRevenueQuantile2015[3], craftWorkerCostEffectDollarRevenueQuantile2015[2], craftWorkerCostEffectDollarRevenueQuantile2015[1], craftWorkerCostEffectDollarRevenueMean2015, craftWorkerCostEffectDollarRevenueCurCompany2015$craft_worker_dollar_revenue_cost

, craftWorkerCostEffectDollarRevenueQuantile2016[3], craftWorkerCostEffectDollarRevenueQuantile2016[2], craftWorkerCostEffectDollarRevenueQuantile2016[1], craftWorkerCostEffectDollarRevenueMean2016, craftWorkerCostEffectDollarRevenueCurCompany2016$craft_worker_dollar_revenue_cost)


#Formula 39
#Page 70 - Craft Worker Cost Effectiveness: Dollar Value Added/ Cost of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Value.Added.per.Cost.of.Bargaining.Unit.Employees", "Craft Worker Cost Effectiveness: \nDollar Value Added/ Cost of Bargaining Unit Employees")
plot(returnGraph9)
#Page 71 - Craft Worker Cost Effectiveness: Dollar Value Added/ Cost of Bargaining Unit Employees Data
plotData("Craft Worker Cost Effectiveness: ", "Dollar Value Added/ Cost of Bargaining Unit Employees", webCompanyName, 
craftWorkerCostEffectDollarValueAddedQuantile2011[3], craftWorkerCostEffectDollarValueAddedQuantile2011[2], craftWorkerCostEffectDollarValueAddedQuantile2011[1], craftWorkerCostEffectDollarValueAddedMean2011, craftWorkerCostEffectDollarValueAddedCurCompany2011$craft_worker_dollar_value_added_cost, 

craftWorkerCostEffectDollarValueAddedQuantile2012[3], craftWorkerCostEffectDollarValueAddedQuantile2012[2], craftWorkerCostEffectDollarValueAddedQuantile2012[1], craftWorkerCostEffectDollarValueAddedMean2012, craftWorkerCostEffectDollarValueAddedCurCompany2012$craft_worker_dollar_value_added_cost

, craftWorkerCostEffectDollarValueAddedQuantile2013[3], craftWorkerCostEffectDollarValueAddedQuantile2013[2], craftWorkerCostEffectDollarValueAddedQuantile2013[1], craftWorkerCostEffectDollarValueAddedMean2013, craftWorkerCostEffectDollarValueAddedCurCompany2013$craft_worker_dollar_value_added_cost

, craftWorkerCostEffectDollarValueAddedQuantile2014[3], craftWorkerCostEffectDollarValueAddedQuantile2014[2], craftWorkerCostEffectDollarValueAddedQuantile2014[1], craftWorkerCostEffectDollarValueAddedMean2014, craftWorkerCostEffectDollarValueAddedCurCompany2014$craft_worker_dollar_value_added_cost

, craftWorkerCostEffectDollarValueAddedQuantile2015[3], craftWorkerCostEffectDollarValueAddedQuantile2015[2], craftWorkerCostEffectDollarValueAddedQuantile2015[1], craftWorkerCostEffectDollarValueAddedMean2015, craftWorkerCostEffectDollarValueAddedCurCompany2015$craft_worker_dollar_value_added_cost

, craftWorkerCostEffectDollarValueAddedQuantile2016[3], craftWorkerCostEffectDollarValueAddedQuantile2016[2], craftWorkerCostEffectDollarValueAddedQuantile2016[1], craftWorkerCostEffectDollarValueAddedMean2016, craftWorkerCostEffectDollarValueAddedCurCompany2016$craft_worker_dollar_value_added_cost)


#Formula 40
#Page 72 - Craft Worker Cost Effectiveness: Dollar Net Profit / Cost of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Net.Profit.per.Cost.of.Bargaining.Unit.Employees", "Craft Worker Cost Effectiveness: \nDollar Net Profit / Cost of Bargaining Unit Employees")
plot(returnGraph9)
#Page 73 - Craft Worker Cost Effectiveness: Dollar Net Profit / Cost of Bargaining Unit Employees Data
plotData("Craft Worker Cost Effectiveness: ", "Dollar Net Profit / Cost of Bargaining Unit Employees", webCompanyName, 
craftWorkerCostEffectDollarNetProfitQuantile2011[3], craftWorkerCostEffectDollarNetProfitQuantile2011[2], craftWorkerCostEffectDollarNetProfitQuantile2011[1], craftWorkerCostEffectDollarNetProfitMean2011, craftWorkerCostEffectDollarNetProfitCurCompany2011$craft_worker_dollar_net_profit_cost, 

craftWorkerCostEffectDollarNetProfitQuantile2012[3], craftWorkerCostEffectDollarNetProfitQuantile2012[2], craftWorkerCostEffectDollarNetProfitQuantile2012[1], craftWorkerCostEffectDollarNetProfitMean2012, craftWorkerCostEffectDollarNetProfitCurCompany2012$craft_worker_dollar_net_profit_cost

, craftWorkerCostEffectDollarNetProfitQuantile2013[3], craftWorkerCostEffectDollarNetProfitQuantile2013[2], craftWorkerCostEffectDollarNetProfitQuantile2013[1], craftWorkerCostEffectDollarNetProfitMean2013, craftWorkerCostEffectDollarNetProfitCurCompany2013$craft_worker_dollar_net_profit_cost

, craftWorkerCostEffectDollarNetProfitQuantile2014[3], craftWorkerCostEffectDollarNetProfitQuantile2014[2], craftWorkerCostEffectDollarNetProfitQuantile2014[1], craftWorkerCostEffectDollarNetProfitMean2014, craftWorkerCostEffectDollarNetProfitCurCompany2014$craft_worker_dollar_net_profit_cost

, craftWorkerCostEffectDollarNetProfitQuantile2015[3], craftWorkerCostEffectDollarNetProfitQuantile2015[2], craftWorkerCostEffectDollarNetProfitQuantile2015[1], craftWorkerCostEffectDollarNetProfitMean2015, craftWorkerCostEffectDollarNetProfitCurCompany2015$craft_worker_dollar_net_profit_cost

, craftWorkerCostEffectDollarNetProfitQuantile2016[3], craftWorkerCostEffectDollarNetProfitQuantile2016[2], craftWorkerCostEffectDollarNetProfitQuantile2016[1], craftWorkerCostEffectDollarNetProfitMean2016, craftWorkerCostEffectDollarNetProfitCurCompany2016$craft_worker_dollar_net_profit_cost)


#Formula 41
#Page 74 - Supporting Employees Cost Effectiveness: Dollar Revenue/ Cost of Supporting Employees Plot
returnGraph9<-plotGraphType1("Revenue.per.Cost.of.Supporting.Employees", "Supporting Employees Cost Effectiveness: \nDollar Revenue/ Cost of Supporting Employees")
plot(returnGraph9)
#Page 75 - Supporting Employees Cost Effectiveness: Dollar Revenue/ Cost of Supporting Employees Data
plotData("Supporting Employees Cost Effectiveness: ", "Dollar Revenue/ Cost of Supporting Employees", webCompanyName, 
supportingEmployeeCostEffectDollarRevenueQuantile2011[3], supportingEmployeeCostEffectDollarRevenueQuantile2011[2], supportingEmployeeCostEffectDollarRevenueQuantile2011[1], supportingEmployeeCostEffectDollarRevenueMean2011, supportingEmployeeCostEffectDollarRevenueCurCompany2011$supporting_employee_dollar_revenue_cost, 

supportingEmployeeCostEffectDollarRevenueQuantile2012[3], supportingEmployeeCostEffectDollarRevenueQuantile2012[2], supportingEmployeeCostEffectDollarRevenueQuantile2012[1], supportingEmployeeCostEffectDollarRevenueMean2012, supportingEmployeeCostEffectDollarRevenueCurCompany2012$supporting_employee_dollar_revenue_cost

, supportingEmployeeCostEffectDollarRevenueQuantile2013[3], supportingEmployeeCostEffectDollarRevenueQuantile2013[2], supportingEmployeeCostEffectDollarRevenueQuantile2013[1], supportingEmployeeCostEffectDollarRevenueMean2013, supportingEmployeeCostEffectDollarRevenueCurCompany2013$supporting_employee_dollar_revenue_cost

, supportingEmployeeCostEffectDollarRevenueQuantile2014[3], supportingEmployeeCostEffectDollarRevenueQuantile2014[2], supportingEmployeeCostEffectDollarRevenueQuantile2014[1], supportingEmployeeCostEffectDollarRevenueMean2014, supportingEmployeeCostEffectDollarRevenueCurCompany2014$supporting_employee_dollar_revenue_cost

, supportingEmployeeCostEffectDollarRevenueQuantile2015[3], supportingEmployeeCostEffectDollarRevenueQuantile2015[2], supportingEmployeeCostEffectDollarRevenueQuantile2015[1], supportingEmployeeCostEffectDollarRevenueMean2015, supportingEmployeeCostEffectDollarRevenueCurCompany2015$supporting_employee_dollar_revenue_cost

, supportingEmployeeCostEffectDollarRevenueQuantile2016[3], supportingEmployeeCostEffectDollarRevenueQuantile2016[2], supportingEmployeeCostEffectDollarRevenueQuantile2016[1], supportingEmployeeCostEffectDollarRevenueMean2016, supportingEmployeeCostEffectDollarRevenueCurCompany2016$supporting_employee_dollar_revenue_cost)


#Formula 42
#Page 76 - Supporting Employees Cost Effectiveness: Dollar Value Added/ Cost of Supporting Employees Plot
returnGraph9<-plotGraphType1("Value.Added.per.Cost.of.Supporting.Employees", "Supporting Employees Cost Effectiveness: \nDollar Value Added/ Cost of Supporting Employees")
plot(returnGraph9)
#Page 77 - Supporting Employees Cost Effectiveness: Dollar Value Added/ Cost of Supporting Employees Graph
plotData("Supporting Employees Cost Effectiveness: ", "Dollar Value Added/ Cost of Supporting Employees", webCompanyName, 
supportingEmployeeCostEffectDollarValueAddedQuantile2011[3], supportingEmployeeCostEffectDollarValueAddedQuantile2011[2], supportingEmployeeCostEffectDollarValueAddedQuantile2011[1], supportingEmployeeCostEffectDollarValueAddedMean2011, supportingEmployeeCostEffectDollarValueAddedCurCompany2011$supporting_employee_dollar_value_added_cost, 

supportingEmployeeCostEffectDollarValueAddedQuantile2012[3], supportingEmployeeCostEffectDollarValueAddedQuantile2012[2], supportingEmployeeCostEffectDollarValueAddedQuantile2012[1], supportingEmployeeCostEffectDollarValueAddedMean2012, supportingEmployeeCostEffectDollarValueAddedCurCompany2012$supporting_employee_dollar_value_added_cost

, supportingEmployeeCostEffectDollarValueAddedQuantile2013[3], supportingEmployeeCostEffectDollarValueAddedQuantile2013[2], supportingEmployeeCostEffectDollarValueAddedQuantile2013[1], supportingEmployeeCostEffectDollarValueAddedMean2013, supportingEmployeeCostEffectDollarValueAddedCurCompany2013$supporting_employee_dollar_value_added_cost

, supportingEmployeeCostEffectDollarValueAddedQuantile2014[3], supportingEmployeeCostEffectDollarValueAddedQuantile2014[2], supportingEmployeeCostEffectDollarValueAddedQuantile2014[1], supportingEmployeeCostEffectDollarValueAddedMean2014, supportingEmployeeCostEffectDollarValueAddedCurCompany2014$supporting_employee_dollar_value_added_cost

, supportingEmployeeCostEffectDollarValueAddedQuantile2015[3], supportingEmployeeCostEffectDollarValueAddedQuantile2015[2], supportingEmployeeCostEffectDollarValueAddedQuantile2015[1], supportingEmployeeCostEffectDollarValueAddedMean2015, supportingEmployeeCostEffectDollarValueAddedCurCompany2015$supporting_employee_dollar_value_added_cost

, supportingEmployeeCostEffectDollarValueAddedQuantile2016[3], supportingEmployeeCostEffectDollarValueAddedQuantile2016[2], supportingEmployeeCostEffectDollarValueAddedQuantile2016[1], supportingEmployeeCostEffectDollarValueAddedMean2016, supportingEmployeeCostEffectDollarValueAddedCurCompany2016$supporting_employee_dollar_value_added_cost)


#Formula 43
#Page 78 - Supporting Employees Cost Effectiveness: Dollar Net Profit / Cost of Supporting Employees Plot
returnGraph9<-plotGraphType1("Net.Profit.per.Cost.of.Supporting.Employees", "Supporting Employees Cost Effectiveness: \nDollar Net Profit / Cost of Supporting Employees")
plot(returnGraph9)
#Page 79 - Supporting Employees Cost Effectiveness: Dollar Net Profit / Cost of Supporting Employees Data
plotData("Supporting Employees Cost Effectiveness: ", "Dollar Net Profit / Cost of Supporting Employees", webCompanyName, 
supportingEmployeeCostEffectDollarNetProfitQuantile2011[3], supportingEmployeeCostEffectDollarNetProfitQuantile2011[2], supportingEmployeeCostEffectDollarNetProfitQuantile2011[1], supportingEmployeeCostEffectDollarNetProfitMean2011, supportingEmployeeCostEffectDollarNetProfitCurCompany2011$supporting_employee_dollar_net_profit_cost, 

supportingEmployeeCostEffectDollarNetProfitQuantile2012[3], supportingEmployeeCostEffectDollarNetProfitQuantile2012[2], supportingEmployeeCostEffectDollarNetProfitQuantile2012[1], supportingEmployeeCostEffectDollarNetProfitMean2012, supportingEmployeeCostEffectDollarNetProfitCurCompany2012$supporting_employee_dollar_net_profit_cost

, supportingEmployeeCostEffectDollarNetProfitQuantile2013[3], supportingEmployeeCostEffectDollarNetProfitQuantile2013[2], supportingEmployeeCostEffectDollarNetProfitQuantile2013[1], supportingEmployeeCostEffectDollarNetProfitMean2013, supportingEmployeeCostEffectDollarNetProfitCurCompany2013$supporting_employee_dollar_net_profit_cost

, supportingEmployeeCostEffectDollarNetProfitQuantile2014[3], supportingEmployeeCostEffectDollarNetProfitQuantile2014[2], supportingEmployeeCostEffectDollarNetProfitQuantile2014[1], supportingEmployeeCostEffectDollarNetProfitMean2014, supportingEmployeeCostEffectDollarNetProfitCurCompany2014$supporting_employee_dollar_net_profit_cost

, supportingEmployeeCostEffectDollarNetProfitQuantile2015[3], supportingEmployeeCostEffectDollarNetProfitQuantile2015[2], supportingEmployeeCostEffectDollarNetProfitQuantile2015[1], supportingEmployeeCostEffectDollarNetProfitMean2015, supportingEmployeeCostEffectDollarNetProfitCurCompany2015$supporting_employee_dollar_net_profit_cost

, supportingEmployeeCostEffectDollarNetProfitQuantile2016[3], supportingEmployeeCostEffectDollarNetProfitQuantile2016[2], supportingEmployeeCostEffectDollarNetProfitQuantile2016[1], supportingEmployeeCostEffectDollarNetProfitMean2016, supportingEmployeeCostEffectDollarNetProfitCurCompany2016$supporting_employee_dollar_net_profit_cost)

#Transition
plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj10,1,1,1000,1000)

#Formula 44
#Page 80 - Cost of Field Project Management Personnel per Hours of Field Project Management Personnel Plot
returnGraph9<-plotGraphType1("Cost.of.Field.Project.Management.Personnel.per.Hours.of.Field.Project.Management.Personnel", "Cost of Field Project Management Personnel \nper Hours of Field Project Management Personnel")
plot(returnGraph9)
#Page 81 - Cost of Field Project Management Personnel per Hours of Field Project Management Personnel Data
plotData("Cost of Field Project Management Personnel", "per Hours of Field Project Management Personnel", webCompanyName, 
costFieldProjManagementQuantile2011[3], costFieldProjManagementQuantile2011[2], costFieldProjManagementQuantile2011[1], costFieldProjManagementMean2011, costFieldProjManagementCurCompany2011$cost_field_project_management_personnel, 

costFieldProjManagementQuantile2012[3], costFieldProjManagementQuantile2012[2], costFieldProjManagementQuantile2012[1], costFieldProjManagementMean2012, costFieldProjManagementCurCompany2012$cost_field_project_management_personnel

, costFieldProjManagementQuantile2013[3], costFieldProjManagementQuantile2013[2], costFieldProjManagementQuantile2013[1], costFieldProjManagementMean2013, costFieldProjManagementCurCompany2013$cost_field_project_management_personnel

, costFieldProjManagementQuantile2014[3], costFieldProjManagementQuantile2014[2], costFieldProjManagementQuantile2014[1], costFieldProjManagementMean2014, costFieldProjManagementCurCompany2014$cost_field_project_management_personnel

, costFieldProjManagementQuantile2015[3], costFieldProjManagementQuantile2015[2], costFieldProjManagementQuantile2015[1], costFieldProjManagementMean2015, costFieldProjManagementCurCompany2015$cost_field_project_management_personnel

, costFieldProjManagementQuantile2016[3], costFieldProjManagementQuantile2016[2], costFieldProjManagementQuantile2016[1], costFieldProjManagementMean2016, costFieldProjManagementCurCompany2016$cost_field_project_management_personnel)


#Formula 45
#Page 82 - Cost of Bargaining Unit Employees per Expended Man Hours of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Cost.of.Bargaining.Unit.Employees.per.Expended.Man.Hours.of.Bargaining.Unit.Employees", "Cost of Bargaining Unit Employees \nper Expended Man Hours of Bargaining Unit Employees")
plot(returnGraph9)
#Page 83 - Cost of Bargaining Unit Employees per Expended Man Hours of Bargaining Unit Employees Data
plotData("Cost of Bargaining Unit Employees", "per Expended Man Hours of Bargaining Unit Employees", webCompanyName, 
costBargainingUnitEmployeeQuantile2011[3], costBargainingUnitEmployeeQuantile2011[2], costBargainingUnitEmployeeQuantile2011[1], costBargainingUnitEmployeeMean2011, costBargainingUnitEmployeeCurCompany2011$cost_bargaining_unit_employee_expended, 

costBargainingUnitEmployeeQuantile2012[3], costBargainingUnitEmployeeQuantile2012[2], costBargainingUnitEmployeeQuantile2012[1], costBargainingUnitEmployeeMean2012, costBargainingUnitEmployeeCurCompany2012$cost_bargaining_unit_employee_expended

, costBargainingUnitEmployeeQuantile2013[3], costBargainingUnitEmployeeQuantile2013[2], costBargainingUnitEmployeeQuantile2013[1], costBargainingUnitEmployeeMean2013, costBargainingUnitEmployeeCurCompany2013$cost_bargaining_unit_employee_expended

, costBargainingUnitEmployeeQuantile2014[3], costBargainingUnitEmployeeQuantile2014[2], costBargainingUnitEmployeeQuantile2014[1], costBargainingUnitEmployeeMean2014, costBargainingUnitEmployeeCurCompany2014$cost_bargaining_unit_employee_expended

, costBargainingUnitEmployeeQuantile2015[3], costBargainingUnitEmployeeQuantile2015[2], costBargainingUnitEmployeeQuantile2015[1], costBargainingUnitEmployeeMean2015, costBargainingUnitEmployeeCurCompany2015$cost_bargaining_unit_employee_expended

, costBargainingUnitEmployeeQuantile2016[3], costBargainingUnitEmployeeQuantile2016[2], costBargainingUnitEmployeeQuantile2016[1], costBargainingUnitEmployeeMean2016, costBargainingUnitEmployeeCurCompany2016$cost_bargaining_unit_employee_expended)


#Formula 46
#Page 84 - Cost of Supporting Employees per Hours of Supporting Employees Plot
returnGraph9<-plotGraphType1("Cost.of.Supporting.Employees.per.Hours.of.Supporting.Employees", "Cost of Supporting Employees \nper Hours of Supporting Employees")
plot(returnGraph9)
#Page 85 - Cost of Supporting Employees per Hours of Supporting Employees Data
plotData("Cost of Supporting Employees", "per Hours of Supporting Employees", webCompanyName, 
costSupportingEmployeesQuantile2011[3], costSupportingEmployeesQuantile2011[2], costSupportingEmployeesQuantile2011[1], costSupportingEmployeesMean2011, costSupportingEmployeesCurCompany2011$cost_supporting_employee_per_hour, 

costSupportingEmployeesQuantile2012[3], costSupportingEmployeesQuantile2012[2], costSupportingEmployeesQuantile2012[1], costSupportingEmployeesMean2012, costSupportingEmployeesCurCompany2012$cost_supporting_employee_per_hour

, costSupportingEmployeesQuantile2013[3], costSupportingEmployeesQuantile2013[2], costSupportingEmployeesQuantile2013[1], costSupportingEmployeesMean2013, costSupportingEmployeesCurCompany2013$cost_supporting_employee_per_hour

, costSupportingEmployeesQuantile2014[3], costSupportingEmployeesQuantile2014[2], costSupportingEmployeesQuantile2014[1], costSupportingEmployeesMean2014, costSupportingEmployeesCurCompany2014$cost_supporting_employee_per_hour

, costSupportingEmployeesQuantile2015[3], costSupportingEmployeesQuantile2015[2], costSupportingEmployeesQuantile2015[1], costSupportingEmployeesMean2015, costSupportingEmployeesCurCompany2015$cost_supporting_employee_per_hour

, costSupportingEmployeesQuantile2016[3], costSupportingEmployeesQuantile2016[2], costSupportingEmployeesQuantile2016[1], costSupportingEmployeesMean2016, costSupportingEmployeesCurCompany2016$cost_supporting_employee_per_hour)


#Transition
plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj9,1,1,1000,1000)


#Formula 47
#Page 86 - Cost of Field Project Management Personnel per Cost of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Cost.of.Field.Project.Management.Personnel.per.Cost.of.Bargaining.Unit.Employees", "Cost of Field Project Management Personnel \nper Cost of Bargaining Unit Employees")
plot(returnGraph9)
#Page 87 - Cost of Field Project Management Personnel per Cost of Bargaining Unit Employees Data
plotData("Cost of Field Project Management Personnel", "per Cost of Bargaining Unit Employees", webCompanyName, 
costFieldProjManagementPersonnelQuantile2011[3], costFieldProjManagementPersonnelQuantile2011[2], costFieldProjManagementPersonnelQuantile2011[1], costFieldProjManagementPersonnelMean2011, costFieldProjManagementPersonnelCurCompany2011$cost_field_project_management_personnel_cost, 

costFieldProjManagementPersonnelQuantile2012[3], costFieldProjManagementPersonnelQuantile2012[2], costFieldProjManagementPersonnelQuantile2012[1], costFieldProjManagementPersonnelMean2012, costFieldProjManagementPersonnelCurCompany2012$cost_field_project_management_personnel_cost

, costFieldProjManagementPersonnelQuantile2013[3], costFieldProjManagementPersonnelQuantile2013[2], costFieldProjManagementPersonnelQuantile2013[1], costFieldProjManagementPersonnelMean2013, costFieldProjManagementPersonnelCurCompany2013$cost_field_project_management_personnel_cost

, costFieldProjManagementPersonnelQuantile2014[3], costFieldProjManagementPersonnelQuantile2014[2], costFieldProjManagementPersonnelQuantile2014[1], costFieldProjManagementPersonnelMean2014, costFieldProjManagementPersonnelCurCompany2014$cost_field_project_management_personnel_cost

, costFieldProjManagementPersonnelQuantile2015[3], costFieldProjManagementPersonnelQuantile2015[2], costFieldProjManagementPersonnelQuantile2015[1], costFieldProjManagementPersonnelMean2015, costFieldProjManagementPersonnelCurCompany2015$cost_field_project_management_personnel_cost

, costFieldProjManagementPersonnelQuantile2016[3], costFieldProjManagementPersonnelQuantile2016[2], costFieldProjManagementPersonnelQuantile2016[1], costFieldProjManagementPersonnelMean2016, costFieldProjManagementPersonnelCurCompany2016$cost_field_project_management_personnel_cost)


#Formula 48
#Page 88 - Cost of Supporting Employees per Cost of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Cost.of.Supporting.Employees.per.Cost.of.Bargaining.Unit.Employees", "Cost of Supporting Employees \nper Cost of Bargaining Unit Employees")
plot(returnGraph9)
#Page 89 - Cost of Supporting Employees per Cost of Bargaining Unit Employees Data
plotData("Cost of Supporting Employees", "per Cost of Bargaining Unit Employees", webCompanyName, 
costSupportingEmployeeCostBargainingQuantile2011[3], costSupportingEmployeeCostBargainingQuantile2011[2], costSupportingEmployeeCostBargainingQuantile2011[1], costSupportingEmployeeCostBargainingMean2011, costSupportingEmployeeCostBargainingCurCompany2011$cost_supp_employee_cost, 

costSupportingEmployeeCostBargainingQuantile2012[3], costSupportingEmployeeCostBargainingQuantile2012[2], costSupportingEmployeeCostBargainingQuantile2012[1], costSupportingEmployeeCostBargainingMean2012, costSupportingEmployeeCostBargainingCurCompany2012$cost_supp_employee_cost

, costSupportingEmployeeCostBargainingQuantile2013[3], costSupportingEmployeeCostBargainingQuantile2013[2], costSupportingEmployeeCostBargainingQuantile2013[1], costSupportingEmployeeCostBargainingMean2013, costSupportingEmployeeCostBargainingCurCompany2013$cost_supp_employee_cost

, costSupportingEmployeeCostBargainingQuantile2014[3], costSupportingEmployeeCostBargainingQuantile2014[2], costSupportingEmployeeCostBargainingQuantile2014[1], costSupportingEmployeeCostBargainingMean2014, costSupportingEmployeeCostBargainingCurCompany2014$cost_supp_employee_cost

, costSupportingEmployeeCostBargainingQuantile2015[3], costSupportingEmployeeCostBargainingQuantile2015[2], costSupportingEmployeeCostBargainingQuantile2015[1], costSupportingEmployeeCostBargainingMean2015, costSupportingEmployeeCostBargainingCurCompany2015$cost_supp_employee_cost

, costSupportingEmployeeCostBargainingQuantile2016[3], costSupportingEmployeeCostBargainingQuantile2016[2], costSupportingEmployeeCostBargainingQuantile2016[1], costSupportingEmployeeCostBargainingMean2016, costSupportingEmployeeCostBargainingCurCompany2016$cost_supp_employee_cost)


#Transition
plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj7,1,1,1000,1000)


#Formula 49
#Page 90 - Hours of Field Project Management Personnel per Hours of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Hours.of.Field.Project.Management.Personnel.per.Expended.Man.Hours.of.Bargaining.Unit.Employees", "Hours of Field Project Management Personnel \nper Hours of Bargaining Unit Employees")
plot(returnGraph9)
#Page 91 - Hours of Field Project Management Personnel per Hours of Bargaining Unit Employees Data
plotData("Hours of Field Project Management Personnel", "per Hours of Bargaining Unit Employees", webCompanyName, 
hoursFieldProjectManagementQuantile2011[3], hoursFieldProjectManagementQuantile2011[2], hoursFieldProjectManagementQuantile2011[1], hoursFieldProjectManagementMean2011, hoursFieldProjectManagementCurCompany2011$hours_field_project_management_personnel, 

hoursFieldProjectManagementQuantile2012[3], hoursFieldProjectManagementQuantile2012[2], hoursFieldProjectManagementQuantile2012[1], hoursFieldProjectManagementMean2012, hoursFieldProjectManagementCurCompany2012$hours_field_project_management_personnel

, hoursFieldProjectManagementQuantile2013[3], hoursFieldProjectManagementQuantile2013[2], hoursFieldProjectManagementQuantile2013[1], hoursFieldProjectManagementMean2013, hoursFieldProjectManagementCurCompany2013$hours_field_project_management_personnel

, hoursFieldProjectManagementQuantile2014[3], hoursFieldProjectManagementQuantile2014[2], hoursFieldProjectManagementQuantile2014[1], hoursFieldProjectManagementMean2014, hoursFieldProjectManagementCurCompany2014$hours_field_project_management_personnel

, hoursFieldProjectManagementQuantile2015[3], hoursFieldProjectManagementQuantile2015[2], hoursFieldProjectManagementQuantile2015[1], hoursFieldProjectManagementMean2015, hoursFieldProjectManagementCurCompany2015$hours_field_project_management_personnel

, hoursFieldProjectManagementQuantile2016[3], hoursFieldProjectManagementQuantile2016[2], hoursFieldProjectManagementQuantile2016[1], hoursFieldProjectManagementMean2016, hoursFieldProjectManagementCurCompany2016$hours_field_project_management_personnel)



#Formula 50
#Page 92 - Hours of Supporting Employees per Hours of Bargaining Unit Employees Plot
returnGraph9<-plotGraphType1("Hours.of.Supporting.Employees.per.Expended.Man.Hours.of.Bargaining.Unit.Employees", "Hours of Supporting Employees \nper Hours of Bargaining Unit Employees")
plot(returnGraph9)
#Page 93 - Hours of Supporting Employees per Hours of Bargaining Unit Employees Data
plotData("Hours of Supporting Employees", "per Hours of Bargaining Unit Employees", webCompanyName, 
hoursSupportingEmployeeQuantile2011[3], hoursSupportingEmployeeQuantile2011[2], hoursSupportingEmployeeQuantile2011[1], hoursSupportingEmployeeMean2011, hoursSupportingEmployeeCurCompany2011$hours_supporting_employee_per_hour, 

hoursSupportingEmployeeQuantile2012[3], hoursSupportingEmployeeQuantile2012[2], hoursSupportingEmployeeQuantile2012[1], hoursSupportingEmployeeMean2012, hoursSupportingEmployeeCurCompany2012$hours_supporting_employee_per_hour

, hoursSupportingEmployeeQuantile2013[3], hoursSupportingEmployeeQuantile2013[2], hoursSupportingEmployeeQuantile2013[1], hoursSupportingEmployeeMean2013, hoursSupportingEmployeeCurCompany2013$hours_supporting_employee_per_hour

, hoursSupportingEmployeeQuantile2014[3], hoursSupportingEmployeeQuantile2014[2], hoursSupportingEmployeeQuantile2014[1], hoursSupportingEmployeeMean2014, hoursSupportingEmployeeCurCompany2014$hours_supporting_employee_per_hour

, hoursSupportingEmployeeQuantile2015[3], hoursSupportingEmployeeQuantile2015[2], hoursSupportingEmployeeQuantile2015[1], hoursSupportingEmployeeMean2015, hoursSupportingEmployeeCurCompany2015$hours_supporting_employee_per_hour

, hoursSupportingEmployeeQuantile2016[3], hoursSupportingEmployeeQuantile2016[2], hoursSupportingEmployeeQuantile2016[1], hoursSupportingEmployeeMean2016, hoursSupportingEmployeeCurCompany2016$hours_supporting_employee_per_hour)

#end
plot(c(1, 1000), c(1, 1000), type = "n", xaxt="n", yaxt="n", bty="n", xlab = "", ylab = "")
rasterImage(jj11,1,1,1000,1000)

dev.off()

options(warn = oldw)









