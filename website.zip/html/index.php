<?php

header("Location: landing/index.html");
exit();


?>
