<?php

define("MIN_YEAR_NUM", 2011);
define("MAX_YEAR_NUM", 2018);

include_once 'includes/db_connect.php';
include_once 'includes/functions.php';


	$db = $mysqli;
   // Calculates Result fields for the given Company and pushes to database.
   function calculateResults($row, $db) 
   {		
		updateCompanyNameToOther($row, $db);
		addMissingYears($row, $db);
		setCurCompanyName($row, $db);
		
		$id = $row['id'];
		
		for ($year = MIN_YEAR_NUM; $year <= MAX_YEAR_NUM; $year++) {
			$sqlGetDataRow = "SELECT * FROM Year WHERE Year.company_id ={$id} AND year ={$year} LIMIT 1";
			$dataRowResult = mysqli_query($db, $sqlGetDataRow);
			$dataRow = mysqli_fetch_array($dataRowResult, MYSQLI_ASSOC);
			
			//Formula 1-10
			netProfitPercentageEntry($dataRow, $db);
			costOfPurchasedMaterialsEntry($dataRow, $db);
			paymentsDispursedToSubcontractors($dataRow, $db);
			overallProductivityMeasurementDollarRevenue($dataRow, $db);
			overallProductivityMeasurementDollarValueAdded($dataRow, $db);
			overallProductivityMeasurementDollarNetProfit($dataRow, $db);
			
			//Formula 11-19
			projectManagementDollarRevenue($dataRow, $db);
			projectManagementDollarValueAdded($dataRow, $db);
			projectManagementDollarNetProfit($dataRow, $db);
			craftWorkerDollarRevenue($dataRow, $db);
			craftWorkerDollarValueAdded($dataRow, $db);
			craftWorkerDollarNetProfit($dataRow, $db);
			supportingEmployeeDollarRevenue($dataRow, $db);
			supportingEmployeeDollarValueAdded($dataRow, $db);
			supportingEmployeeDollarNetProfit($dataRow, $db);
			
			//Formula 20-31
			overallProductivityDollarRevenueFte($dataRow, $db);
			overallProductivityDollarValueAddedFte($dataRow, $db);
			overallProductivityDollarNetProfitFte($dataRow, $db);
			projectManagementDollarRevenueFte($dataRow, $db);
			projectManagementDollarValueAddedFte($dataRow, $db);
			projectManagementDollarNetProfitFte($dataRow, $db);
			craftWorkerDollarRevenueFte($dataRow, $db);
			craftWorkerDollarValueAddedFte($dataRow, $db);
			craftWorkerDollarNetProfitFte($dataRow, $db);
			supportingEmployeeDollarRevenueFte($dataRow, $db);
			supportingEmployeeDollarValueAddedFte($dataRow, $db);
			supportingEmployeeDollarNetProfitFte($dataRow, $db);
			
			//Formula 32 - 40
			overallCostDollarRevenueCost($dataRow, $db);
			overallCostDollarValueAddedCost($dataRow, $db);
			overallCostDollarNetProfitCost($dataRow, $db);
			projectManagementDollarRevenueCost($dataRow, $db);
			projectManagementDollarValueAddedCost($dataRow, $db);
			projectManagementDollarNetProfitCost($dataRow, $db);
			craftWorkerDollarRevenueCost($dataRow, $db);
			craftWorkerDollarValueAddedCost($dataRow, $db);
			craftWorkerDollarNetProfitCost($dataRow, $db);
			
			//Formula 41-50
			supportingEmployeeDollarRevenueCost($dataRow, $db);
			supportingEmployeeDollarValueAddedCost($dataRow, $db);
			supportingEmployeeDollarNetProfitCost($dataRow, $db);
			costFieldProjectManagementPersonnel($dataRow, $db);
			costBargainingUnitEmployeeExpended($dataRow, $db);
			costSupportingEmployeePerHour($dataRow, $db);
			costFieldProjectManagementPersonnelPerCost($dataRow, $db);
			costSupportingEmployeePerCost($dataRow, $db);
			hoursFieldProjectManagementPersonnel($dataRow, $db);
			hoursSupportingEmployeePerHour($dataRow, $db);

			//New Functions
			grossProfitPercentageEntry($dataRow, $db);
			overheadPercentageEntry($dataRow, $db);
			copyMiscYearData($dataRow, $db);
		}
		
		
		$user_id = $_SESSION['user_id'];
		$sql99 = "UPDATE Company SET step_one='yes' WHERE id={$row['id']}";
		$db->query($sql99);

   }

	// Do not display point if NULL.
   function divideEdgeCases($num, $den)
   {
	   if($num == 0)
		   $returnDivide = 0;
	   else if($den == 0)
		   $returnDivide = NULL;
	   else
		   $returnDivide = $num / $den;
	   return $returnDivide;
   }
   
   function netProfitPercentageEntry($row, $db)
   {
	   if($row['net_profit'] != NULL && $row['revenue'] != NULL) 
	   { 
		   $NetProfitPercentage = divideEdgeCases($row['net_profit'],$row['revenue']);
		   $sql2 = "UPDATE adminresults SET net_profit_percentage={$NetProfitPercentage} WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
	   else
	   {
		   $sql2 = "UPDATE adminresults SET net_profit_percentage=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
	   $db->query($sql2);
   }
   
   function costOfPurchasedMaterialsEntry($row, $db)
   {
	   if($row['cost_materials'] != NULL && $row['revenue'] != NULL) 
	   { 
		   $costOfPurchasedMaterials = divideEdgeCases(($row['cost_materials']),($row['revenue']));
		   $sql3 = "UPDATE adminresults SET cost_purchased_materials={$costOfPurchasedMaterials} WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
	   else
	   {
		   $sql3 = "UPDATE adminresults SET cost_purchased_materials=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
       $db->query($sql3);
   }
   
   function paymentsDispursedToSubcontractors($row, $db)
   {
	   if($row['pay_disbursed_subcontr'] != NULL && $row['revenue'] != NULL) 
	   { 
		   $paymentsDispursedToSubcontractors = divideEdgeCases(($row['pay_disbursed_subcontr']),($row['revenue']));
		   $sql4 = "UPDATE adminresults SET pay_disbursed_subcontr={$paymentsDispursedToSubcontractors} WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
	   else
	   {
		   $sql4 = "UPDATE adminresults SET pay_disbursed_subcontr=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
       $db->query($sql4);
   }
   
   function overallProductivityMeasurementDollarRevenue($row, $db)
   {
	   if($row['revenue'] != NULL && $row['hours_bargain_employee'] != NULL && $row['hours_proj_manag_peson'] != NULL && $row['hours_supp_employee'] != NULL) 
	   { 
			$overallProductivityMeasurementDollarRevenue = divideEdgeCases(($row['revenue'])*1000000,(($row['hours_bargain_employee']) + ($row['hours_proj_manag_peson']) + ($row['hours_supp_employee']) )  );
			$sql5 = "UPDATE adminresults SET overall_productivity_measurement_dollar_revenue={$overallProductivityMeasurementDollarRevenue} WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
	   else
	   {
			$sql5 = "UPDATE adminresults SET overall_productivity_measurement_dollar_revenue=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
       $db->query($sql5);
   }

   function overallProductivityMeasurementDollarValueAdded($row, $db)
   {
	   if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['hours_bargain_employee'] != NULL && $row['hours_proj_manag_peson'] != NULL && $row['hours_supp_employee'] != NULL) 
	   { 
		   $overallProductivityMeasurementDollarValueAdded = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - (($row['pay_disbursed_subcontr']) ))*1000000,(($row['hours_bargain_employee']) + ($row['hours_proj_manag_peson']) + ($row['hours_supp_employee']) )  );
		   $sql6 = "UPDATE adminresults SET overall_productivity_measurement_dollar_value_added={$overallProductivityMeasurementDollarValueAdded} WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
	   else
	   {
			$sql6 = "UPDATE adminresults SET overall_productivity_measurement_dollar_value_added=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
       $db->query($sql6);
   }
   
   function overallProductivityMeasurementDollarNetProfit($row, $db)
   {
	   if($row['net_profit'] != NULL && $row['hours_bargain_employee'] != NULL && $row['hours_proj_manag_peson'] != NULL && $row['hours_supp_employee'] != NULL) 
	   { 
		   $overallProductivityMeasurementDollarNetProfit = divideEdgeCases(($row['net_profit'])*1000000,(($row['hours_bargain_employee']) + ($row['hours_proj_manag_peson']) + ($row['hours_supp_employee']) )  );
		   $sql7 = "UPDATE adminresults SET overall_productivity_measurement_dollar_net_profit={$overallProductivityMeasurementDollarNetProfit} WHERE year={$row['year']} AND company_id={$row['company_id']}";	   
	   }
	   else
	   {
			$sql7 = "UPDATE adminresults SET overall_productivity_measurement_dollar_net_profit=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";	   
	   }
       $db->query($sql7);
   }
   
   // Formula 11-19
   function projectManagementDollarRevenue($row, $db)
   {
	   if($row['revenue'] != NULL && $row['hours_proj_manag_peson'] != NULL) 
	   { 
		   $projectManagementDollarRevenue = divideEdgeCases(($row['revenue'])*1000000,($row['hours_proj_manag_peson']) );
		   $sql7 = "UPDATE adminresults SET project_management_dollar_revenue={$projectManagementDollarRevenue} WHERE year={$row['year']} AND company_id={$row['company_id']}";
	   }
	   else
	   {
			$sql7 = "UPDATE adminresults SET project_management_dollar_revenue=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";   
	   }
       $db->query($sql7);
   }
   
   function projectManagementDollarValueAdded($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['hours_proj_manag_peson'] != NULL) 
	    { 
		   $projectManagementDollarValueAdded = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr']) )*1000000,($row['hours_proj_manag_peson']) );
		   $sql8 = "UPDATE adminresults SET project_management_dollar_value_added={$projectManagementDollarValueAdded} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			 $sql8 = "UPDATE adminresults SET project_management_dollar_value_added=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}"; 
	    } 
       $db->query($sql8);
   }
   
   function projectManagementDollarNetProfit($row, $db)
   {
		if($row['net_profit'] != NULL && $row['hours_proj_manag_peson'] != NULL ) 
	    { 
		   $projectManagementDollarNetProfit = divideEdgeCases(($row['net_profit'])*1000000,($row['hours_proj_manag_peson']) );
		   $sql9 = "UPDATE adminresults SET project_management_dollar_net_profit={$projectManagementDollarNetProfit} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			 $sql9 = "UPDATE adminresults SET project_management_dollar_net_profit=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql9);
   }
   
   function craftWorkerDollarRevenue($row, $db)
   {
		if($row['revenue'] != NULL && $row['hours_bargain_employee'] != NULL ) 
	    { 
		   $craftWorkerDollarRevenue = divideEdgeCases(($row['revenue'])*1000000,($row['hours_bargain_employee']) );
		   $sql10 = "UPDATE adminresults SET craft_worker_dollar_revenue={$craftWorkerDollarRevenue} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql10 = "UPDATE adminresults SET craft_worker_dollar_revenue=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql10);
   }
   
   function craftWorkerDollarValueAdded($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['hours_bargain_employee'] != NULL) 
	    { 
		   $craftWorkerDollarValueAdded = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr']) )*1000000,($row['hours_bargain_employee']) );
		   $sql11 = "UPDATE adminresults SET craft_worker_dollar_value_added={$craftWorkerDollarValueAdded} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql11 = "UPDATE adminresults SET craft_worker_dollar_value_added=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql11);
   }
   
   function craftWorkerDollarNetProfit($row, $db)
   {
		if($row['net_profit'] != NULL && $row['hours_bargain_employee'] != NULL) 
	    { 
		   $craftWorkerDollarNetProfit = divideEdgeCases(($row['net_profit'])*1000000,($row['hours_bargain_employee']) );
		   $sql12 = "UPDATE adminresults SET craft_worker_dollar_net_profit={$craftWorkerDollarNetProfit} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql12 = "UPDATE adminresults SET craft_worker_dollar_net_profit=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql12);
   }

   function supportingEmployeeDollarRevenue($row, $db)
   {
		if($row['revenue'] != NULL && $row['hours_supp_employee'] != NULL) 
	    { 
		   $supportingEmployeeDollarRevenue = divideEdgeCases(($row['revenue'])*1000000,($row['hours_supp_employee']) );
		   $sql13 = "UPDATE adminresults SET supporting_employee_dollar_revenue={$supportingEmployeeDollarRevenue} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql13 = "UPDATE adminresults SET supporting_employee_dollar_revenue=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql13);
   }
   
   function supportingEmployeeDollarValueAdded($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['hours_supp_employee'] != NULL) 
	    { 
		   $supportingEmployeeDollarValueAdded = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr']) )*1000000,($row['hours_supp_employee']) );
		   $sql14 = "UPDATE adminresults SET supporting_employee_dollar_value_added={$supportingEmployeeDollarValueAdded} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql14 = "UPDATE adminresults SET supporting_employee_dollar_value_added=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql14);
   }
   
   function supportingEmployeeDollarNetProfit($row, $db)
   {
		if($row['net_profit'] != NULL && $row['hours_supp_employee'] != NULL) 
	    { 
		   $supportingEmployeeDollarNetProfit = divideEdgeCases(($row['net_profit'])*1000000,($row['hours_supp_employee']) );
		   $sql14 = "UPDATE adminresults SET supporting_employee_dollar_net_profit={$supportingEmployeeDollarNetProfit} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql14 = "UPDATE adminresults SET supporting_employee_dollar_net_profit=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql14);
   }
   
   
   // Formula 20-31
   function overallProductivityDollarRevenueFte($row, $db)
   {
		if($row['revenue'] != NULL && $row['fte_bargain_employee'] != NULL && $row['fte_proj_manag_peson'] != NULL && $row['fte_supp_employee'] != NULL) 
	    { 
		   $overallProductivityDollarRevenueFte = divideEdgeCases(($row['revenue'])*1000000,(($row['fte_bargain_employee']) + ($row['fte_proj_manag_peson']) + ($row['fte_supp_employee']) ) );
		   $sql20 = "UPDATE adminresults SET overall_productivity_dollar_revenue_fte={$overallProductivityDollarRevenueFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql20 = "UPDATE adminresults SET overall_productivity_dollar_revenue_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql20);
   }
   
   function overallProductivityDollarValueAddedFte($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['fte_bargain_employee'] != NULL && $row['fte_proj_manag_peson'] != NULL && $row['hours_supp_employee'] != NULL) 
	    { 
		   $overallProductivityDollarValueAddedFte = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr']))*1000000,(($row['fte_bargain_employee']) + ($row['fte_proj_manag_peson']) + ($row['hours_supp_employee']) ) );
		   $sql21 = "UPDATE adminresults SET overall_productivity_dollar_value_added_fte={$overallProductivityDollarValueAddedFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql21 = "UPDATE adminresults SET overall_productivity_dollar_value_added_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql21);
   }
   
   function overallProductivityDollarNetProfitFte($row, $db)
   {
		if($row['net_profit'] != NULL && $row['fte_bargain_employee'] != NULL && $row['fte_proj_manag_peson'] != NULL && $row['fte_supp_employee'] != NULL) 
	    { 
		   $overallProductivityDollarNetProfitFte = divideEdgeCases(($row['net_profit'])*1000000,(($row['fte_bargain_employee']) + ($row['fte_proj_manag_peson']) + ($row['fte_supp_employee']) ) );
		   $sql22 = "UPDATE adminresults SET overall_productivity_dollar_net_profit_fte={$overallProductivityDollarNetProfitFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql22 = "UPDATE adminresults SET overall_productivity_dollar_net_profit_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql22);
   }
   
   function projectManagementDollarRevenueFte($row, $db)
   {
		if($row['revenue'] != NULL && $row['fte_proj_manag_peson'] != NULL) 
	    { 
		   $projectManagementDollarRevenueFte = divideEdgeCases(($row['revenue'])*1000000,($row['fte_proj_manag_peson']) );
		   $sql23 = "UPDATE adminresults SET project_management_dollar_revenue_fte={$projectManagementDollarRevenueFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql23 = "UPDATE adminresults SET project_management_dollar_revenue_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql23);
   }
   
   function projectManagementDollarValueAddedFte($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['fte_proj_manag_peson'] != NULL) 
	    { 
		   $projectManagementDollarValueAddedFte = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr']))*1000000,($row['fte_proj_manag_peson']) );
		   $sql24 = "UPDATE adminresults SET project_management_dollar_value_added_fte={$projectManagementDollarValueAddedFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql24 = "UPDATE adminresults SET project_management_dollar_value_added_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql24);
   }
   
   function projectManagementDollarNetProfitFte($row, $db)
   {
		if($row['net_profit'] != NULL && $row['fte_proj_manag_peson'] != NULL) 
	    { 
		   $projectManagementDollarNetProfitFte = divideEdgeCases(($row['net_profit'])*1000000,($row['fte_proj_manag_peson']) );
		   $sql25 = "UPDATE adminresults SET project_management_dollar_net_profit_fte={$projectManagementDollarNetProfitFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql25 = "UPDATE adminresults SET project_management_dollar_net_profit_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql25);
   }
   
   function craftWorkerDollarRevenueFte($row, $db)
   {
		if($row['revenue'] != NULL && $row['fte_bargain_employee'] != NULL) 
	    { 
		   $craftWorkerDollarRevenueFte = divideEdgeCases(($row['revenue'])*1000000,($row['fte_bargain_employee']) );
		   $sql26 = "UPDATE adminresults SET craft_worker_dollar_revenue_fte={$craftWorkerDollarRevenueFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql26 = "UPDATE adminresults SET craft_worker_dollar_revenue_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    }  
       $db->query($sql26);
   }
   
   function craftWorkerDollarValueAddedFte($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['fte_bargain_employee'] != NULL) 
	    { 
		   $craftWorkerDollarValueAddedFte = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr']))*1000000,($row['fte_bargain_employee']) );
		   $sql27 = "UPDATE adminresults SET craft_worker_dollar_value_added_fte={$craftWorkerDollarValueAddedFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql27 = "UPDATE adminresults SET craft_worker_dollar_value_added_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    }  
       $db->query($sql27);
   }
   
   function craftWorkerDollarNetProfitFte($row, $db)
   {
		if($row['net_profit'] != NULL && $row['fte_bargain_employee'] != NULL) 
	    { 
		   $craftWorkerDollarNetProfitFte = divideEdgeCases(($row['net_profit'])*1000000,($row['fte_bargain_employee']) );
		   $sql28 = "UPDATE adminresults SET craft_worker_dollar_net_profit_fte={$craftWorkerDollarNetProfitFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql28 = "UPDATE adminresults SET craft_worker_dollar_net_profit_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    }  
       $db->query($sql28);
   }
   
   function supportingEmployeeDollarRevenueFte($row, $db)
   {
		if($row['revenue'] != NULL && $row['fte_supp_employee'] != NULL) 
	    { 
		   $supportingEmployeeDollarRevenueFte = divideEdgeCases(($row['revenue'])*1000000,($row['fte_supp_employee']) );
		   $sql29 = "UPDATE adminresults SET supporting_employee_dollar_revenue_fte={$supportingEmployeeDollarRevenueFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql29 = "UPDATE adminresults SET supporting_employee_dollar_revenue_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql29);
   }
   
   function supportingEmployeeDollarValueAddedFte($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['fte_supp_employee'] != NULL) 
	    { 
		   $supportingEmployeeDollarValueAddedFte = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr']))*1000000,($row['fte_supp_employee']) );
		   $sql30 = "UPDATE adminresults SET supporting_employee_dollar_value_added_fte={$supportingEmployeeDollarValueAddedFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql30 = "UPDATE adminresults SET supporting_employee_dollar_value_added_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql30);
   }
   
   function supportingEmployeeDollarNetProfitFte($row, $db)
   {
		if($row['net_profit'] != NULL && $row['fte_supp_employee'] != NULL) 
	    { 
		   $supportingEmployeeDollarNetProfitFte = divideEdgeCases(($row['net_profit'])*1000000,($row['fte_supp_employee']) );
		   $sql31 = "UPDATE adminresults SET supporting_employee_dollar_net_profit_added_fte={$supportingEmployeeDollarNetProfitFte} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql31 = "UPDATE adminresults SET supporting_employee_dollar_net_profit_added_fte=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql31);
   }
   
   //Formula 32 - 40
   function overallCostDollarRevenueCost($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_bargain_employee'] != NULL && $row['cost_proj_manag_peson'] != NULL && $row['cost_supp_employee'] != NULL) 
	    { 
		   $overallCostDollarRevenueCost = divideEdgeCases(($row['revenue']),( ($row['cost_bargain_employee']) + ($row['cost_proj_manag_peson']) + ($row['cost_supp_employee']) ) );
		   $sql32 = "UPDATE adminresults SET overall_cost_dollar_revenue_cost={$overallCostDollarRevenueCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql32 = "UPDATE adminresults SET overall_cost_dollar_revenue_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql32);
   }
   
   function overallCostDollarValueAddedCost($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['cost_bargain_employee'] != NULL && $row['cost_proj_manag_peson'] != NULL && $row['cost_supp_employee'] != NULL) 
	    { 
		   $overallCostDollarValueAddedCost = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr'])),( ($row['cost_bargain_employee']) + ($row['cost_proj_manag_peson']) + ($row['cost_supp_employee']) ) );
		   $sql33 = "UPDATE adminresults SET overall_cost_dollar_value_added_cost={$overallCostDollarValueAddedCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql33 = "UPDATE adminresults SET overall_cost_dollar_value_added_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql33);
   }
   
   function overallCostDollarNetProfitCost($row, $db)
   {
		if($row['net_profit'] != NULL && $row['cost_bargain_employee'] != NULL && $row['cost_proj_manag_peson'] != NULL && $row['cost_supp_employee'] != NULL) 
	    { 
		   $overallCostDollarNetProfitCost = divideEdgeCases(($row['net_profit']),( ($row['cost_bargain_employee']) + ($row['cost_proj_manag_peson']) + ($row['cost_supp_employee']) ) );
		   $sql34 = "UPDATE adminresults SET overall_cost_dollar_net_profit_cost={$overallCostDollarNetProfitCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql34 = "UPDATE adminresults SET overall_cost_dollar_net_profit_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql34);
   }

   function projectManagementDollarRevenueCost($row, $db)
   {
		if($row['revenue'] != NULL && $row['cost_proj_manag_peson'] != NULL) 
	    { 
		   $projectManagementDollarRevenueCost = divideEdgeCases(($row['revenue']),($row['cost_proj_manag_peson']) );
		   $sql35 = "UPDATE adminresults SET project_management_dollar_revenue_cost={$projectManagementDollarRevenueCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql35 = "UPDATE adminresults SET project_management_dollar_revenue_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql35);
   } 
   
   function projectManagementDollarValueAddedCost($row, $db)
   {
	   	if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['cost_proj_manag_peson'] != NULL) 
	    { 
		   $projectManagementDollarValueAddedCost = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr'])),($row['cost_proj_manag_peson']) );
		   $sql36 = "UPDATE adminresults SET project_management_dollar_value_added_cost={$projectManagementDollarValueAddedCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			 $sql36 = "UPDATE adminresults SET project_management_dollar_value_added_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql36);
   } 
   
   function projectManagementDollarNetProfitCost($row, $db)
   {
	   	if($row['net_profit'] != NULL && $row['cost_proj_manag_peson'] != NULL) 
	    { 
		   $projectManagementDollarNetProfitCost = divideEdgeCases(($row['net_profit']),($row['cost_proj_manag_peson']) );
		   $sql37 = "UPDATE adminresults SET project_management_dollar_net_profit_cost={$projectManagementDollarNetProfitCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			 $sql37 = "UPDATE adminresults SET project_management_dollar_net_profit_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql37);
   } 
   
   function craftWorkerDollarRevenueCost($row, $db)
   {
	   	if($row['revenue'] != NULL && $row['cost_bargain_employee'] != NULL) 
	    { 
		   $craftWorkerDollarRevenueCost = divideEdgeCases(($row['revenue']),($row['cost_bargain_employee']) );
		   $sql38 = "UPDATE adminresults SET craft_worker_dollar_revenue_cost={$craftWorkerDollarRevenueCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			 $sql38 = "UPDATE adminresults SET craft_worker_dollar_revenue_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql38);
   } 
   
   function craftWorkerDollarValueAddedCost($row, $db)
   {
	   	if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['cost_bargain_employee'] != NULL) 
	    { 
		   $craftWorkerDollarValueAddedCost = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr'])),($row['cost_bargain_employee']) );
		   $sql39 = "UPDATE adminresults SET craft_worker_dollar_value_added_cost={$craftWorkerDollarValueAddedCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql39 = "UPDATE adminresults SET craft_worker_dollar_value_added_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql39);
   } 
   
   function craftWorkerDollarNetProfitCost($row, $db)
   {
	   	if($row['net_profit'] != NULL && $row['cost_bargain_employee'] != NULL) 
	    { 
		   $craftWorkerDollarNetProfitCost = divideEdgeCases(($row['net_profit']),($row['cost_bargain_employee']) );
		   $sql40 = "UPDATE adminresults SET craft_worker_dollar_net_profit_cost={$craftWorkerDollarNetProfitCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql40 = "UPDATE adminresults SET craft_worker_dollar_net_profit_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql40);
   } 
   
   //Formula 41-50
   function supportingEmployeeDollarRevenueCost($row, $db)
   {
	   	if($row['revenue'] != NULL && $row['cost_supp_employee'] != NULL) 
	    { 
		   $supportingEmployeeDollarRevenueCost = divideEdgeCases(($row['revenue']),($row['cost_supp_employee']) );
		   $sql41 = "UPDATE adminresults SET supporting_employee_dollar_revenue_cost={$supportingEmployeeDollarRevenueCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql41 = "UPDATE adminresults SET supporting_employee_dollar_revenue_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql41);
   } 
   
   function supportingEmployeeDollarValueAddedCost($row, $db)
   {
	   	if($row['revenue'] != NULL && $row['cost_materials'] != NULL && $row['pay_disbursed_subcontr'] != NULL && $row['cost_supp_employee'] != NULL) 
	    { 
		   $supportingEmployeeDollarValueAddedCost = divideEdgeCases((($row['revenue']) - ($row['cost_materials']) - ($row['pay_disbursed_subcontr'])),($row['cost_supp_employee']) );
		   $sql42 = "UPDATE adminresults SET supporting_employee_dollar_value_added_cost={$supportingEmployeeDollarValueAddedCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql42 = "UPDATE adminresults SET supporting_employee_dollar_value_added_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql42);
   } 
   
   function supportingEmployeeDollarNetProfitCost($row, $db)
   {
	   	if($row['net_profit'] != NULL && $row['cost_supp_employee'] != NULL) 
	    { 
		   $supportingEmployeeDollarNetProfitCost = divideEdgeCases(($row['net_profit']),($row['cost_supp_employee']) );
		   $sql43 = "UPDATE adminresults SET supporting_employee_dollar_net_profit_cost={$supportingEmployeeDollarNetProfitCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql43 = "UPDATE adminresults SET supporting_employee_dollar_net_profit_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql43);
   } 
   
   // Personal Cost per hour
   function costFieldProjectManagementPersonnel($row, $db)
   {
	   	if($row['cost_proj_manag_peson'] != NULL && $row['hours_proj_manag_peson'] != NULL) 
	    { 
		   $costFieldProjectManagementPersonnel = divideEdgeCases(($row['cost_proj_manag_peson'])*1000000,($row['hours_proj_manag_peson']) );
		   $sql44 = "UPDATE adminresults SET cost_field_project_management_personnel={$costFieldProjectManagementPersonnel} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql44 = "UPDATE adminresults SET cost_field_project_management_personnel=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql44);
   }
   // Personal Cost per hour
   function costBargainingUnitEmployeeExpended($row, $db)
   {
	   	if($row['cost_bargain_employee'] != NULL && $row['hours_bargain_employee'] != NULL) 
	    { 
		   $costBargainingUnitEmployeeExpended = divideEdgeCases(($row['cost_bargain_employee'])*1000000,($row['hours_bargain_employee']) );
		   $sql45 = "UPDATE adminresults SET cost_bargaining_unit_employee_expended={$costBargainingUnitEmployeeExpended} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql45 = "UPDATE adminresults SET cost_bargaining_unit_employee_expended=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql45);
   }
   // Personal Cost per hour
   function costSupportingEmployeePerHour($row, $db)
   {
	   	if($row['cost_supp_employee'] != NULL && $row['hours_supp_employee'] != NULL) 
	    { 
		   $costSupportingEmployeePerHour = divideEdgeCases(($row['cost_supp_employee'])*1000000,($row['hours_supp_employee']) );
		   $sql46 = "UPDATE adminresults SET cost_supporting_employee_per_hour={$costSupportingEmployeePerHour} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql46 = "UPDATE adminresults SET cost_supporting_employee_per_hour=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql46);
   }
   
   // Staffing by Cost
   function costFieldProjectManagementPersonnelPerCost($row, $db)
   {
	   	if($row['cost_proj_manag_peson'] != NULL && $row['cost_bargain_employee'] != NULL) 
	    { 
		   $costFieldProjectManagementPersonnelPerCost = divideEdgeCases(($row['cost_proj_manag_peson']),($row['cost_bargain_employee']) );
		   $sql47 = "UPDATE adminresults SET cost_field_project_management_personnel_cost={$costFieldProjectManagementPersonnelPerCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql47 = "UPDATE adminresults SET cost_field_project_management_personnel_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql47);
   }
   
   // Staffing by Cost
   function costSupportingEmployeePerCost($row, $db)
   {
	   	if($row['cost_supp_employee'] != NULL && $row['cost_bargain_employee'] != NULL) 
	    { 
		   $costSupportingEmployeePerCost = divideEdgeCases(($row['cost_supp_employee']),($row['cost_bargain_employee']) );
		   $sql48 = "UPDATE adminresults SET cost_supp_employee_cost={$costSupportingEmployeePerCost} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql48 = "UPDATE adminresults SET cost_supp_employee_cost=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql48);
   }
   
   
   
   //Staffing hours by hours.
   function hoursFieldProjectManagementPersonnel($row, $db)
   {
	   	if($row['hours_proj_manag_peson'] != NULL && $row['hours_bargain_employee'] != NULL) 
	    { 
		   $hoursFieldProjectManagementPersonnel = divideEdgeCases(($row['hours_proj_manag_peson']),($row['hours_bargain_employee']) );
		   $sql49 = "UPDATE adminresults SET hours_field_project_management_personnel={$hoursFieldProjectManagementPersonnel} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql49 = "UPDATE adminresults SET hours_field_project_management_personnel=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql49);
   }
   
   //Staffing hours by hours.
   function hoursSupportingEmployeePerHour($row, $db)
   {
	   	if($row['hours_supp_employee'] != NULL && $row['hours_bargain_employee'] != NULL) 
	    { 
		   $hoursSupportingEmployeePerHour = divideEdgeCases(($row['hours_supp_employee']),($row['hours_bargain_employee']) );
		   $sql50 = "UPDATE adminresults SET hours_supporting_employee_per_hour={$hoursSupportingEmployeePerHour} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
	    else
	    {
			$sql50 = "UPDATE adminresults SET hours_supporting_employee_per_hour=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
	    } 
       $db->query($sql50);
   	}

	function grossProfitPercentageEntry($row, $db)
	{
		if ($row['gross_profit'] != NULL && $row['revenue'] != NULL) {
			$GrossProfitPercentage = divideEdgeCases($row['gross_profit'], $row['revenue']);
			$sqlUpdate = "UPDATE adminresults SET gross_profit_percentage={$GrossProfitPercentage} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
		else
		{
			$sqlUpdate = "UPDATE adminresults SET gross_profit_percentage=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
		$db->query($sqlUpdate);
	}
	
	function overheadPercentageEntry($row, $db)
	{
		if ($row['fixed_overhead'] != NULL && $row['variable_overhead'] != NULL && $row['revenue'] != NULL) {
			$OverheadPercentage = divideEdgeCases(($row['fixed_overhead'] + $row['variable_overhead']), $row['revenue']);
			$sqlUpdate = "UPDATE adminresults SET overhead_percentage={$OverheadPercentage} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
		elseif ($row['fixed_overhead'] != NULL && $row['variable_overhead'] = NULL && $row['revenue'] != NULL) {
			$OverheadPercentage = divideEdgeCases($row['fixed_overhead'], $row['revenue']);
			$sqlUpdate = "UPDATE adminresults SET overhead_percentage={$OverheadPercentage} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
		elseif ($row['fixed_overhead'] = NULL && $row['variable_overhead'] != NULL && $row['revenue'] != NULL) {
			$OverheadPercentage = divideEdgeCases($row['variable_overhead'], $row['revenue']);
			$sqlUpdate = "UPDATE adminresults SET overhead_percentage={$OverheadPercentage} WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
		else
		{
			$sqlUpdate = "UPDATE adminresults SET overhead_percentage=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
		}
		$db->query($sqlUpdate);  
	}

	function copyMiscYearData($row, $db)
	{
		$fieldsToCopy = array('hit_rate', 'turnover_rate_bargaining_perc', 'absenteeism_perc', 'osha_incident_rate', 'emr', 'repeat_customer_perc');
		foreach($fieldsToCopy as $fieldName)
		{
			if($row[$fieldName] != NULL) 
			{ 
				$fieldValue = $row[$fieldName];
				$sqlUpdate = "UPDATE adminresults SET {$fieldName}={$fieldValue} WHERE year={$row['year']} AND company_id={$row['company_id']}";
			}
			else
			{
				$sqlUpdate = "UPDATE adminresults SET {$fieldName}=NULL WHERE year={$row['year']} AND company_id={$row['company_id']}";
			} 
			$db->query($sqlUpdate);
		}
	}

   
   
   
   
   
   
   function updateCompanyNameToOther($row, $db)
   {
	   $sql51 = "UPDATE adminresults SET company_name='Other'";
       $db->query($sql51);
   }
   
   function setCurCompanyName($row, $db)
   {
	   $sql52 = "UPDATE adminresults SET company_name='{$row['company_name']}' WHERE company_id={$row['id']}";
       $db->query($sql52);
 
   }
   
   function addMissingYears($row, $db)
   {	   
		$company_id = $row['id'];
		$company_name = $row['company_name'];

		for ($year = MIN_YEAR_NUM; $year <= MAX_YEAR_NUM; $year++)
		{
			$sql0 = "SELECT uniqueid FROM adminresults WHERE year={$year} AND company_id={$row['id']}";
			$result = mysqli_query($db, $sql0);
			$count = mysqli_num_rows($result);
			if ($count == 0)
			{
				$sql1 = "INSERT INTO adminresults (company_id, company_name, year) VALUES ('$company_id', '$company_name', '$year')";
				$db->query($sql1);
			}
		}
   }


?>