<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';
include 'processForms.php';
 
sec_session_start();

   $count = 0;
   $errorMsgAdmin = " ";
   
   if ($_SERVER["REQUEST_METHOD"] == "POST") 
   {
	   	if (isset($_POST['adminCalculateResults'])) 
		{ 
			if (isset($_POST['admin_company_id'])) {

				$myCompId = mysqli_real_escape_string($mysqli, $_POST['admin_company_id']);
				$sql = "SELECT * FROM Company WHERE id = '$myCompId' LIMIT 1";
				$result = mysqli_query($mysqli, $sql);
				$row = mysqli_fetch_array($result, MYSQLI_ASSOC);

				$count = mysqli_num_rows($result);
				// If result matched $myusername and $mypassword, table row must be 1 row

				if ($count == 1) {
					calculateResults($row, $mysqli);
				} else {
					$errorMsgAdmin = "Please enter a valid Company ID";
				}
			} 
		}
		
   }

   
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Electrical Contractors Productivity and Profitability</title>
        <link rel="stylesheet" href="styles/main.css" />
        <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script> 
		<link href="styles/style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
	
    <body class="landingPageBody">
	
			<!-- Multistep form -->
			<!-- Top gradient header-->
			<div id="bottomGradientLanding">
				<label class="viewPageHeader">Electrical Contractors Productivity and Profitability - ADMIN</label>
			</div>
			<br><br>
			
			<?php if (login_check($mysqli) == true) : ?>		
			<!-- Content Area -->
			<!--Form -->
			<div id="msform">
			<div style="width: 100%;">
			<!--Section 1-->
			<fieldset id="fieldset1">
				<br><br>
				<?php

				if ($count != 1) {
					echo '<p class="error">'.$errorMsgAdmin.'</p>';
				}
				?>
				<br><br>
				<!--Bottom buttons-->
				<form action="" method="post">
					<!-- Input text -->
					<label class="viewHeader">Please type the <b>ID</b> of the Company you want to Calculate Results of:</label>
					<label class="viewSubHeader">(A list of Ids are displayed below)</</label>
					
					<input required type="text" name="admin_company_id" class="form-control" onkeypress='return (event.charCode == 00) || (event.charCode >= 48 && event.charCode <= 57)'/>
					<input type="submit" name="adminCalculateResults" class="buttonClass" value=" Step 1: Calculate "/>
				</form>

				
				<div>
					<br><br>
					<label class="viewHeader"><u>Please follow the below steps to generate PDF report.</u></label>
					<label class="viewSubHeader">Click on the "Step 2: Click Me" button that will take you to: http://ec2-18-224-8-51.us-east-2.compute.amazonaws.com:8787/auth-sign-in<br><br> Login with the following credentials: <br>Username: hcgwayadmin <br> Password: yH2vtDcfGK21 <br><br>On the R console enter: system("Rscript sol.R {enter company ID}") <br> Ex: system("Rscript sol.R 12") <br>You can then download the report on to your browser!</label>
					
				
					
					<a href="http://ec2-18-224-8-51.us-east-2.compute.amazonaws.com:8787/auth-sign-in" target="_blank">
					   <input type="button" class="buttonClass" value="Step 2: Click Me" />
					</a>

				
				</div>
				
				<a href="includes/logout.php">
					   <input type="button" class="buttonClass" value="Logout" />
				</a>
				<br><br>
			
				
				<?php
					$sql = "SELECT id, company_name, submit, step_one FROM Company";
					$sql1 = "SELECT email FROM members";
					$result = mysqli_query($mysqli, $sql);
					$result1 = mysqli_query($mysqli, $sql1);
					
					// Success
					if (mysqli_num_rows($result) > 0 && mysqli_num_rows($result1) > 0) 
					{
						echo "<table class='hoverTable'><tr><td><b>ID:</b></td><td><b>Company Name:</b></td><td><b>Email:</b></td><td><b>Form Submitted:</b></td><td><b>Step-1 Completed:</b></td></tr>";
						// output data of each row
						while($row = mysqli_fetch_assoc($result)) {
							$row1 = mysqli_fetch_assoc($result1);
							echo "<tr><td>" . $row["id"]. "</td><td>" . $row["company_name"]. " " . "</td><td>" . $row1["email"]. " " . "</td><td>" . $row["submit"]. " " . "</td><td>" . $row["step_one"]. " " . "</td></tr>";
						}
						echo "</table>";
					} else {
						$errorLogin = "No Data retrieved";
					}

				?>  
			</fieldset>
			</div>
			</div>
			
			
        <?php else : ?>
            <p>
                <span class="error">You are not authorized to access this page.</span> Please <a href="index.php">login</a>.
            </p>
        <?php endif; ?>
    </body>
</html>
