<?php

include_once 'includes/register.inc.php';
include_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
		<title>Electrical Contractors Productivity and Profitability</title>
        <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script>
        <link rel="stylesheet" href="styles/main.css" />
		
		<link href="styles/style.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	
	<body class="landingPageBody">
	
		<div id="bottomGradientLanding">
			<label class="viewPageHeader">Electrical Contractors Productivity and Profitability</label>
		</div>
			
			
		<br><br><br><br><br><br><br><br>
		<!-- Content Area -->
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-md-offset-4">
					<div class="login-panel panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title">Please Sign Up</h3>
						</div>
						<div class="panel-body">
							<form method="post" name="registration_form" action="<?php echo esc_url($_SERVER['PHP_SELF']); ?>">
							
									<div class="form-group">
										<table class="registerTable" ><tr>
											<td><input class="form-control" placeholder="Username" name="username" id="username" type="text" autofocus></td>
											<td><div class="help-tip-reg"><p>Usernames may contain only digits, upper and lower case letters and underscores</p></div></td>
										</tr></table>
									</div>
									
									<div class="form-group">
									<table class="registerTable" ><tr>
										<td><input class="form-control" placeholder="E-mail" name="email" id="email" type="email" autofocus></td>
										<td><div class="help-tip-reg"><p>Emails must have a valid email format</p></div></td>
										</tr></table>
									</div>
									
									<div class="form-group">
									<table class="registerTable" ><tr>
										<td><input class="form-control" placeholder="Password" id="password" name="password" type="password" value=""></td>
										<td><div class="help-tip-reg">
											<p>Passwords must be at least 6 characters long<br>Passwords must contain<br>At least one upper case letter (A..Z)<br>At least one lower case letter (a..z)<br>At least one number (0..9)</p></div></td>
										</tr></table>
									</div>
									
									<div class="form-group">
									<table class="registerTable" ><tr>
										<td><input class="form-control" placeholder="Confirm Password" id="confirmpwd" name="confirmpwd" type="password" value=""></td>
										<td><div class="help-tip-reg"><p>Your password and confirmation must match exactly</p></div></td>
										</tr></table>
									</div>
								
									<!-- Add link to to go back to sign-in -->
									<div class="errorText">
									Already have an account?
									<a href="index.php">Sign In</a>
									</div>
									
									
									<input type="button" name="signupButton" class="buttonClass" value=" Sign Up " onclick="return regformhash(this.form, this.form.username, this.form.email,this.form.password, this.form.confirmpwd);"/>
									<br>
									<div class="errorText">
									<?php
										if (!empty($error_msg)) {
											echo $error_msg;
										}
									?>
									</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
    </body>
</html>
